# REPRODUCIBILITY.md

Every quantitative claim in the manuscript traces to one of the sources
below. Nothing marked "real" in the table below was hand-typed; each such
number is copied directly from a JSON log produced by running the listed
command in this repository (environment: Python 3.12, numpy 2.4.4, scipy
1.17.1, scikit-image 0.26.0, scikit-learn 1.8.0, matplotlib 3.10.8,
CPU-only, single-threaded, no GPU). Items marked "pending" are explicit
placeholders in the manuscript; see `EXPERIMENT_PROTOCOL.md` Sec. 0 for
the full figure/table status map.

## Revision history

**Round 1 (initial submission):** core method, theory, from-scratch
persistence engine, synthetic sanity-check suite (Tables 2-3 at the time).

**Round 2:** in response to reviewer concern about the photometric
failure and runtime, (a) optimized the persistence engine (caching +
vectorization, `code/phdesc/persistence.py`), re-verified against the
full correctness test suite before generating any new numbers; (b) added
PW-Desc-rank (`code/phdesc/descriptor.py::rank_normalize_patch`), proved
and tested its exact-invariance property (`code/tests/test_descriptor.py`,
new in this round), and re-ran the full sanity-check suite.

**Round 3 (this revision):** restructured the manuscript into the
standard per-dataset table/figure layout expected for local-feature-
descriptor papers (12 figures, 12 tables total). Added: a descriptor-
dimensionality table and a memory-footprint table (both factual/derived,
no experiments required); real figures for the filtration process and the
persistence-image vectorization (built from the same verified engine); a
real illustrative figure of the Oxford-Affine distortion types on our own
synthetic scene; a real runtime bar chart; and explicit, clearly-labeled
placeholder figures/tables for everything that genuinely requires the four
public datasets and/or GPU-run learned baselines. During this
restructuring, two figure-generation scripts (`make_figure3_qualitative_
matches.py`, `make_figure4_quantitative.py`) still targeted the OLD
filenames (`figure3.pdf`, `figure4.pdf`), which by this round held
different content (the new topological-evolution and HPatches-placeholder
figures) -- rerunning them would have silently overwritten the current
figures. This was caught before packaging; the scripts were renamed to
`make_figure11_qualitative_matches.py` / `make_figure12_quantitative.py`
and repointed to `figure11.pdf` / `figure12.pdf` (their actual current
position in the manuscript), then re-run to confirm they still execute
correctly.

## Figure/table source map

| Item in paper | Status | Source file | Command | Seed(s) |
|---|---|---|---|---|
| Sec. 6, persistence-engine correctness claims | Real | `code/tests/test_persistence.py` | `python code/tests/test_persistence.py` | 0, 1 (fixed in test file) |
| Prop. 4 (rank-normalization exact invariance) | Real | `code/tests/test_descriptor.py` | `python code/tests/test_descriptor.py` | 0, 1, 2 (fixed in test file) |
| Table 1 (dataset summary) | Real (public facts) | -- | manually transcribed from the cited original dataset papers (Balntas et al. 2017; Li & Snavely 2018; Dai et al. 2017; Mikolajczyk et al. 2005) | n/a |
| Table 2 (dimensionality) | Real (public facts / this repo) | `code/phdesc/descriptor.py` | manually transcribed from cited papers + `DescriptorConfig` | n/a |
| Table 3 (HPatches results) | **Pending** | -- | see `EXPERIMENT_PROTOCOL.md` Sec. 4 | n/a |
| Table 4 (MegaDepth results) | **Pending** | -- | see `EXPERIMENT_PROTOCOL.md` Sec. 4 | n/a |
| Table 5 (ScanNet results) | **Pending** | -- | see `EXPERIMENT_PROTOCOL.md` Sec. 4 | n/a |
| Table 6 (Oxford-Affine results) | **Pending** | -- | see `EXPERIMENT_PROTOCOL.md` Sec. 4 | n/a |
| Table 7 (ablation, HPatches) | **Pending** (rank-normalization row's synthetic-suite result already known, see Tables 11-12) | -- | see `EXPERIMENT_PROTOCOL.md` Sec. 5 | n/a |
| Table 8 (runtime) | Partially real | `code/scripts/synthetic_validation_results.json` | PW-Desc/RawPatch/GradHist rows: `python code/scripts/synthetic_validation.py`; other rows pending (`EXPERIMENT_PROTOCOL.md` Sec. 6) | scene seeds 0-3 (fixed in script) |
| Table 9 (memory) | Real (derived) | -- | derived from Table 2 dimensionality x published element type | n/a |
| Table 10 (statistical significance) | Partially real | `code/phdesc/stats_tests.py` output | synthetic-suite rows: `python code/scripts/synthetic_validation.py`; benchmark rows pending | scene seeds 0-3 |
| Table 11 (synthetic sanity check) | Real | `code/scripts/synthetic_validation_results.json` | `python code/scripts/synthetic_validation.py` | scene seeds 0-3; homography seeds 100-103; elastic-deform seeds 200-203 (all fixed in script) |
| Table 12 (photometric stress test) | Real | `code/scripts/photometric_robustness_results.json` | `python code/scripts/photometric_robustness.py` | scene seeds 0-3 (fixed in script) |
| Figure 1 (framework) | Real (schematic, not data-derived) | -- | `python code/scripts/make_figure1_architecture.py` | n/a |
| Figure 2 (PH pipeline flowchart) | Real (schematic, not data-derived) | -- | `python code/scripts/make_figure2_pipeline_flowchart.py` | n/a |
| Figure 3 (topological evolution) | Real (actual computed output) | `phdesc.persistence` | `python code/scripts/make_figure3_topological_evolution.py` | annulus: deterministic construction |
| Figure 4 (HPatches qualitative) | **Pending** (explicit placeholder) | -- | `python code/scripts/make_pending_placeholder_figures.py`; real version per `EXPERIMENT_PROTOCOL.md` Sec. 4 | n/a |
| Figure 5 (MegaDepth qualitative) | **Pending** (explicit placeholder) | -- | same script; real version per `EXPERIMENT_PROTOCOL.md` Sec. 4 | n/a |
| Figure 6 (ScanNet qualitative) | **Pending** (explicit placeholder) | -- | same script; real version per `EXPERIMENT_PROTOCOL.md` Sec. 4 | n/a |
| Figure 7 (Oxford distortion illustration) | Real, but illustrative (own synthetic scene, not the real dataset) | -- | `python code/scripts/make_figure7_distortion_illustration.py` | scene seed 7 (fixed in script) |
| Figure 8 (persistence image visualization) | Real (actual computed output) | `phdesc.persistence`, `phdesc.descriptor` | `python code/scripts/make_figure8_persistence_image_viz.py` | annulus: deterministic; patch: scene seed 3, location (y=64,x=96) |
| Figure 9 (runtime comparison) | Partially real | same source as Table 8 | `python code/scripts/make_figure9_runtime_comparison.py` | n/a (reads hardcoded real values matching Table 8) |
| Figure 10 (cross-dataset accuracy) | **Pending** (explicit placeholder, axes/legend only, no data plotted) | -- | `python code/scripts/make_pending_placeholder_figures.py`; real version per `EXPERIMENT_PROTOCOL.md` Sec. 4 | n/a |
| Figure 11 (qualitative synthetic matches) | Real | actual matching-pipeline output | `python code/scripts/make_figure11_qualitative_matches.py` | scene seed 2, homography seed 102, elastic-deform seed 202; RANSAC uses skimage's internal RNG (not separately seeded), so the exact inlier/outlier split (23/3 in the current figure) can vary by +/-1-2 across reruns |
| Figure 12 (quantitative synthetic + photometric) | Real | re-plots Tables 11-12 JSON | `python code/scripts/make_figure12_quantitative.py` | (reads the two JSON files above) |

## Full raw output logs

The exact stdout of the two experiment scripts (including per-scene
timing and the full JSON dump) is reproduced in full in:
- `code/scripts/synthetic_validation_results.json` (Table 11 / Figures 11, 12a)
- `code/scripts/photometric_robustness_results.json` (Table 12 / Figure 12b)

## Note on numerical determinism

All random number generation uses `numpy.random.default_rng(seed)` with
explicit, fixed integer seeds (never the global numpy random state), so
every "real" number in this package is exactly reproducible on any machine
with the pinned package versions above, with one documented exception:
`skimage.measure.ransac` (used only for post-hoc geometric verification in
the qualitative Figure 11, not for any reported accuracy metric) uses its
own internal random state, which was not separately seeded; this affects
only the exact inlier/outlier split shown in Figure 11, not any number in
Tables 8-12. Minor floating-point differences across BLAS backends may
affect the last 1-2 significant digits of aggregated means; this does not
affect any qualitative claim made in the manuscript.
