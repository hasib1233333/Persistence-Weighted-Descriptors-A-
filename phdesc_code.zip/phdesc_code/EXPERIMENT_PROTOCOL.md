# EXPERIMENT_PROTOCOL.md

This document specifies, precisely and executably, the experiments needed
to populate Tables 3-6 (per-dataset main results), Table 7 (ablations),
and Figures 4-6 and 10 (qualitative/cross-dataset) in the manuscript.
Nothing in this file is a result — it is a protocol.

## 0. Figure and table map (status at time of writing)

| # | Content | Status |
|---|---|---|
| Table 1 | Dataset summary | Real (public facts) |
| Table 2 | Descriptor dimensionality | Real (public facts / this repo's code) |
| Table 3 | HPatches results | **Pending** — needs Sec. 2-4 below |
| Table 4 | MegaDepth results | **Pending** |
| Table 5 | ScanNet results | **Pending** |
| Table 6 | Oxford-Affine results | **Pending** |
| Table 7 | Ablation study (HPatches) | **Pending** (rank-normalization row's synthetic-suite result already known, Table 11) |
| Table 8 | Runtime comparison | Partially real (PW-Desc/RawPatch/GradHist rows measured; others pending Sec. 6) |
| Table 9 | Memory footprint | Real (derived from Table 2) |
| Table 10 | Statistical significance | Partially real (synthetic-suite rows measured; benchmark rows pending) |
| Table 11 | Synthetic sanity-check results | Real (measured in this repo) |
| Table 12 | Photometric stress test | Real (measured in this repo) |
| Figure 1 | Framework overview | Real (schematic) |
| Figure 2 | PH pipeline flowchart | Real (schematic) |
| Figure 3 | Topological evolution of a patch | Real (computed from actual code) |
| Figure 4 | HPatches qualitative matching | **Pending** — explicit placeholder in this package |
| Figure 5 | MegaDepth qualitative matching | **Pending** — explicit placeholder |
| Figure 6 | ScanNet qualitative matching | **Pending** — explicit placeholder |
| Figure 7 | Oxford-Affine distortion-type illustration | Real, but illustrative (own synthetic scene, not the real dataset) |
| Figure 8 | Persistence image visualization | Real (computed from actual code) |
| Figure 9 | Runtime comparison (bar chart) | Partially real (same status as Table 8) |
| Figure 10 | Cross-dataset accuracy comparison | **Pending** — explicit placeholder (axes/legend only, no data) |
| Figure 11 | Qualitative synthetic matches | Real |
| Figure 12 | Quantitative synthetic + photometric results | Real |

Six items remain genuinely pending and are the reason this manuscript is
not yet submission-ready: Tables 3-7, Figures 4-6 and 10. All require
either the real dataset downloads (Tables 3-6, Figures 4-6), a GPU with
the official baseline checkpoints (rows for SuperPoint/DISK/LoFTR
throughout, and SIFT/ORB via an OpenCV build), or both. None of this can
be produced by further work inside the sandboxed, network-restricted,
CPU-only environment used to prepare this package.

## 1. Environment

- Python >= 3.10, packages in `requirements.txt`.
- A CUDA GPU is required for the learned baselines (SuperPoint, DISK,
  LoFTR); the PW-Desc and classical-baseline code in this repository is
  CPU-only (see complexity note in the manuscript, Sec. 5.2).
- Fixed random seed = 0 for all stochastic components (metric-learning
  initialization, RANSAC) unless stated otherwise; report mean +/- std over
  3 seeds {0, 1, 2} for any learned component.

## 2. Datasets: download and layout

| Dataset | Official source | Expected local path |
|---|---|---|
| HPatches | https://github.com/hpatches/hpatches-dataset | `data/hpatches/hpatches-sequences-release/` |
| MegaDepth | https://www.cs.cornell.edu/projects/megadepth/ | `data/megadepth/` (+ `test_pairs.txt` from the SuperGlue/LoFTR release) |
| ScanNet | http://www.scan-net.org/ (requires signing the ScanNet ToU) | `data/scannet/` (+ `test_pairs.txt` from the SuperGlue/LoFTR release) |
| Oxford-Affine | https://www.robots.ox.ac.uk/~vgg/research/affine/ | `data/oxford_affine/<scene>/` |

Exact on-disk layout expected by each loader is documented in the
docstring of `code/phdesc/datasets.py` (one class per dataset).

`test_pairs.txt` format for MegaDepth/ScanNet (one pair per line):
```
<image_a_relative_path> <image_b_relative_path> <fx_a> <fy_a> <cx_a> <cy_a> <fx_b> <fy_b> <cx_b> <cy_b> <R (9 floats, row-major)> <t (3 floats)>
```
matching the format released alongside SuperGlue (Sarlin et al., 2020) and
commonly reused by LoFTR (Sun et al., 2021); download their released
`test_pairs.txt` rather than regenerating it, to keep numbers comparable
to prior work.

## 3. Baselines: installation

- SIFT, ORB: `opencv-contrib-python` (`cv2.SIFT_create()`, `cv2.ORB_create()`).
- SuperPoint: official repo (github.com/magicleap/SuperPointPretrainedNetwork)
  or the MagicLeap-released checkpoint.
- DISK: official repo + released checkpoint (github.com/cvlab-epfl/disk).
- LoFTR: official repo + released outdoor/indoor checkpoints
  (github.com/zju3dv/LoFTR).
- PH-keypoints (Barbarani et al., 2024): official repo if released, else
  reimplement the differentiable persistent-homology keypoint scorer
  per the paper and pair with PW-Desc for description.
- RawPatch, GradHist, PW-Desc: this repository (`code/phdesc/`).

## 4. Main comparison (Tables 3-6, Figures 4-6 and 10)

Command (to be run once datasets/baselines are installed):
```bash
python code/scripts/run_full_benchmark_suite.py \
    --datasets hpatches oxford_affine megadepth scannet \
    --methods sift orb superpoint disk loftr ph_keypoints_pwdesc pwdesc pwdesc_rank \
    --detector harris \
    --out results/main_results_raw.json
python code/scripts/format_per_dataset_tables.py results/main_results_raw.json \
    --out-dir paper/  # writes table3.tex (HPatches), table4.tex (MegaDepth),
                        # table5.tex (ScanNet), table6.tex (Oxford-Affine)

# qualitative figures (real matching examples, replacing the explicit
# placeholders currently in figure4.pdf/figure5.pdf/figure6.pdf):
python code/scripts/run_full_benchmark_suite.py --datasets hpatches --qualitative \
    --out-fig paper/figure4.pdf
python code/scripts/run_full_benchmark_suite.py --datasets megadepth --qualitative \
    --out-fig paper/figure5.pdf
python code/scripts/run_full_benchmark_suite.py --datasets scannet --qualitative \
    --out-fig paper/figure6.pdf

# cross-dataset accuracy summary (replacing the explicit placeholder in figure10.pdf):
python code/scripts/plot_cross_dataset_accuracy.py results/main_results_raw.json \
    --out paper/figure10.pdf
```
(`run_full_benchmark_suite.py`, `format_per_dataset_tables.py`, and
`plot_cross_dataset_accuracy.py` are thin orchestration scripts to be
written against the baseline codebases listed above once network/GPU
access is available; the metrics, matching, and statistical testing code
they call — `code/phdesc/metrics.py`, `code/phdesc/matching.py`,
`code/phdesc/stats_tests.py` — is already implemented and tested in this
repository.)

Protocol notes:
- **Shared-detector run** (primary): all methods use Harris keypoints
  (`code/phdesc/matching.py::harris_keypoints`), isolating descriptor
  quality.
- **Native-detector run** (secondary, Appendix A): each method uses its own
  detector (DoG for SIFT, FAST for ORB, the learned detection head for
  SuperPoint/DISK, dense for LoFTR).
- Metrics: MMA@{1,3,5,10}px (HPatches, Oxford-Affine, via
  `mean_matching_accuracy`); pose AUC@{5,10,20} deg (MegaDepth, ScanNet, via
  `homography_estimation_auc` adapted to essential-matrix pose error);
  repeatability (`repeatability`); precision/recall/F1 of the putative-match
  set against ground truth; RANSAC inlier ratio; number of correct
  correspondences.
- Statistical testing: paired bootstrap CI + Wilcoxon signed-rank
  (`code/phdesc/stats_tests.py`) between PW-Desc and each baseline, per
  dataset, over per-image-pair scores -> populates Table 10's benchmark rows.

## 5. Ablations (Table 7)

```bash
python code/scripts/run_ablations.py --dataset hpatches --out results/ablation_raw.json
python code/scripts/format_table.py results/ablation_raw.json --template table7.tex > paper/table7.tex
```
Ablation grid (each row changes exactly one factor from the full
configuration): H0-only, H1-only; single-scale (16px, 32px);
no learned projection; unconstrained (non-spectrally-normalized) learned
projection (tests whether Prop. 2's theoretical requirement also matters
empirically); rank-normalized birth coordinate (the fix proposed in
Sec. 7.3 of the manuscript, currently untested); persistence-image
resolution in {4, 8, 16}.

## 6. Robustness / sensitivity / generalization studies

1. **Common corruptions**: apply the ImageNet-C corruption bank (Gaussian
   noise/blur, brightness, JPEG, fog) at 2 severities to HPatches/Oxford-
   Affine test images (as in Kamann & Rother, 2020's Cityscapes adaptation,
   applied here to matching benchmarks); re-run MMA. Reuse
   `code/scripts/synthetic_validation.py::elastic_deform` as a template for
   adding the non-rigid variant.
2. **Non-rigid deformation magnitude sweep**: repeat
   `code/scripts/synthetic_validation.py`'s elastic-deformation regime at
   benchmark scale (real HPatches images) across alpha in
   {1, 2, 4, 8, 16} pixels, plotting MMA vs. deformation magnitude.
3. **Cross-dataset generalization**: train the metric-learning projection
   $W$ on HPatches, evaluate zero-shot on Oxford-Affine and vice versa;
   compare to $W$ trained and tested on the same dataset.
4. **Computational complexity**: wall-clock ms/keypoint for each method at
   3 patch-size configurations, on both CPU and (where applicable) GPU;
   extend the measurement already produced in Table 2's last column.

## 7. Reporting standard

Every populated number in Tables 3-7 must be traceable to a raw JSON log
file committed alongside the paper update (following the pattern of
`code/scripts/synthetic_validation_results.json` /
`photometric_robustness_results.json` in this package), with the exact
command and seed recorded in `REPRODUCIBILITY.md`.
