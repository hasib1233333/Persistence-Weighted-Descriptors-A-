"""
phdesc.pose_estimation
========================

Relative-pose estimation and pose-error AUC, the standard evaluation
protocol for wide-baseline benchmarks (MegaDepth, ScanNet) where a
homography does not hold (non-planar scenes, large baseline) and MMA is
not the right metric -- distinct from phdesc.metrics, which implements
the homography/MMA protocol used for Oxford-Affine and HPatches
elsewhere in this codebase.

From-scratch relative-pose-error computation; essential-matrix estimation
and pose recovery use OpenCV's standard cv2.findEssentialMat /
cv2.recoverPose (RANSAC), the same standard evaluation infrastructure
used by SuperGlue/LoFTR/DKM-style papers, not a contribution of this
work.
"""
import numpy as np
import cv2


def relative_pose_error(R_gt: np.ndarray, t_gt: np.ndarray,
                         R_est: np.ndarray, t_est: np.ndarray) -> tuple:
    """
    Angular error (degrees) between ground-truth and estimated relative
    rotation, and between ground-truth and estimated relative translation
    *direction* (translation scale is unobservable from two uncalibrated
    images, so only direction is compared -- standard convention).
    """
    # rotation error: angle of R_gt^T @ R_est
    cos_r = (np.trace(R_gt.T @ R_est) - 1) / 2
    cos_r = np.clip(cos_r, -1.0, 1.0)
    r_err = np.degrees(np.arccos(cos_r))

    # translation direction error
    t_gt_n = t_gt.ravel() / (np.linalg.norm(t_gt) + 1e-12)
    t_est_n = t_est.ravel() / (np.linalg.norm(t_est) + 1e-12)
    cos_t = np.clip(np.abs(np.dot(t_gt_n, t_est_n)), -1.0, 1.0)  # sign-ambiguous
    t_err = np.degrees(np.arccos(cos_t))

    return r_err, t_err


def estimate_relative_pose(pts_a: np.ndarray, pts_b: np.ndarray,
                            K_a: np.ndarray, K_b: np.ndarray,
                            ransac_thresh_px: float = 1.0):
    """
    Estimate relative pose (R, t) from matched pixel coordinates and
    known camera intrinsics, via essential-matrix RANSAC + pose recovery
    (cv2.findEssentialMat, cv2.recoverPose -- standard evaluation
    infrastructure).

    Returns (R_est, t_est, inlier_mask) or (None, None, None) if
    estimation failed (too few matches, degenerate configuration).
    """
    if len(pts_a) < 8:
        return None, None, None
    # normalize threshold by focal length (approx, using K_a's fx)
    focal = (K_a[0, 0] + K_a[1, 1]) / 2
    thresh_norm = ransac_thresh_px / focal

    pts_a_h = cv2.undistortPoints(pts_a.reshape(-1, 1, 2), K_a, None).reshape(-1, 2)
    pts_b_h = cv2.undistortPoints(pts_b.reshape(-1, 1, 2), K_b, None).reshape(-1, 2)

    E, mask = cv2.findEssentialMat(pts_a_h, pts_b_h, focal=1.0, pp=(0, 0),
                                    method=cv2.RANSAC, prob=0.999999, threshold=thresh_norm)
    if E is None or E.shape != (3, 3):
        return None, None, None
    n_inliers, R_est, t_est, mask_pose = cv2.recoverPose(E, pts_a_h, pts_b_h, mask=mask)
    if n_inliers < 5:
        return None, None, None
    return R_est, t_est, mask.ravel().astype(bool)


def pose_auc(errors: list, thresholds=(5, 10, 20)) -> dict:
    """
    Area-under-curve of the fraction of pairs with pose error below each
    threshold, standard metric (SuperGlue/LoFTR convention): errors are
    max(rotation_error_deg, translation_error_deg) per pair, with a
    failed/unestimated pair scored as error=180 (worst case, not
    dropped -- consistent with the standard protocol, which penalizes
    estimation failure rather than ignoring it).
    """
    errors = np.array(errors)
    aucs = {}
    for t in thresholds:
        ys = []
        for e in np.sort(errors):
            ys.append(np.mean(errors <= e) if e <= t else None)
        # standard trapezoidal AUC over [0, t], step function of sorted errors
        sorted_err = np.sort(np.clip(errors, 0, t))
        recall = np.arange(1, len(sorted_err) + 1) / len(sorted_err)
        sorted_err = np.concatenate([[0], sorted_err])
        recall = np.concatenate([[0], recall])
        aucs[t] = float(np.trapezoid(recall, sorted_err) / t)
    return aucs
