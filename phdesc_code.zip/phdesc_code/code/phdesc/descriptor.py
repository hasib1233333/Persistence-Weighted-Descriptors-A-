"""
phdesc.descriptor
==================

Builds the Persistence-Weighted Descriptor (PW-Desc) for a local image
patch: (1) compute multi-scale sublevel-set persistence diagrams
(phdesc.persistence), (2) vectorize each diagram into a fixed-length
"persistence image" (Adams et al., 2017, JMLR -- a stable, differentiable
vectorization of a persistence diagram), (3) concatenate across scales and
homological dimensions, (4) optionally apply a learned linear metric
projection (phdesc.metric_learning) for discriminative compactness.

Persistence image construction (Adams et al., 2017):
    1. Map each (birth, death) point to (birth, persistence) = (b, d - b).
    2. Weight each point by a weighting function w(b, p) that vanishes at
       p = 0 (guaranteeing stability: near-zero-persistence points, which
       are the most sensitive to perturbation, contribute negligibly).
    3. Place a Gaussian of bandwidth sigma at each weighted point and
       accumulate on a regular grid over the (birth, persistence) plane.
The resulting image is a fixed-size vector, stable in L2/L-infinity norm
with respect to the 1-Wasserstein distance between diagrams (Adams et al.,
2017, Theorem 3), which combined with the Cohen-Steiner-Edelsbrunner-Harer
stability theorem for the diagrams themselves gives our end-to-end
stability guarantee (see manuscript Sec. 3.3 / Proposition 1).
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import List, Sequence, Tuple

from .persistence import compute_persistence_diagrams, PersistenceDiagram


# --------------------------------------------------------------------------
# Persistence image vectorization
# --------------------------------------------------------------------------
def _linear_ramp_weight(persistence: np.ndarray, p_max: float) -> np.ndarray:
    """
    Weighting function w(p) used in Adams et al. (2017): 0 at p=0, linearly
    increasing to 1 at p=p_max, capped at 1 beyond. Vanishing at p=0 is the
    property that makes the resulting image stable (Adams et al., Thm 3).
    """
    w = np.clip(persistence / max(p_max, 1e-12), 0.0, 1.0)
    return w


def persistence_image(pd: PersistenceDiagram,
                       birth_range: Tuple[float, float],
                       pers_range: Tuple[float, float],
                       resolution: int = 8,
                       sigma: float = None) -> np.ndarray:
    """
    Vectorize a persistence diagram into a `resolution x resolution`
    persistence image over the given (birth, persistence) window.

    Parameters
    ----------
    pd : PersistenceDiagram
    birth_range, pers_range : (min, max) windows used for ALL patches, so
        that descriptors from different patches live in a common,
        comparable coordinate system (fixed a priori from the expected
        pixel-intensity range, NOT fit per-patch, to avoid leaking
        patch-specific normalization that would break stability guarantees).
    resolution : grid side length (image is resolution x resolution)
    sigma : Gaussian bandwidth; defaults to one grid cell width.

    Returns
    -------
    image : np.ndarray, shape (resolution, resolution), flattened by caller.
    """
    finite = pd.finite()
    b0, b1 = birth_range
    p0, p1 = pers_range
    grid_b = np.linspace(b0, b1, resolution)
    grid_p = np.linspace(p0, p1, resolution)
    GB, GP = np.meshgrid(grid_b, grid_p, indexing="xy")

    if sigma is None:
        sigma = max((b1 - b0) / resolution, (p1 - p0) / resolution, 1e-6)

    img = np.zeros((resolution, resolution), dtype=np.float64)
    if len(finite) == 0:
        return img

    births = finite[:, 0]
    persistences = finite[:, 1] - finite[:, 0]
    weights = _linear_ramp_weight(persistences, p_max=max(p1, 1e-12))

    # accumulate Gaussians (vectorized over all diagram points at once)
    for b, p, w in zip(births, persistences, weights):
        if w <= 0:
            continue
        img += w * np.exp(-((GB - b) ** 2 + (GP - p) ** 2) / (2 * sigma ** 2))

    return img


def rank_normalize_patch(patch: np.ndarray) -> np.ndarray:
    """
    Replace each pixel's intensity with its normalized RANK within the
    patch (rank / (N-1), in [0,1]), breaking ties by average rank.

    Motivation (addresses the photometric-robustness limitation identified
    empirically in Sec. 8.2 / Table 3 of the manuscript): for any strictly
    monotonic increasing transform phi (e.g. gamma correction, any tone
    curve), rank(phi(v)) == rank(v) for every pixel, EXACTLY, by
    definition of rank. Therefore the rank-normalized patch -- and hence
    every downstream quantity computed from it (filtration values,
    persistence diagrams, persistence images, the descriptor) -- is
    IDENTICAL whether or not phi was applied, not merely Lipschitz-close.
    This is a strictly stronger, exact invariance property, complementary
    to (not a replacement for) the sup-norm Lipschitz bound of
    Proposition 1, which covers small perturbations of any kind
    (monotonic or not) whereas rank-normalization covers perturbations of
    any size that happen to be monotonic.

    Implemented via scipy.stats.rankdata (average-rank tie handling),
    normalized to [0, 1].
    """
    from scipy.stats import rankdata
    flat = patch.reshape(-1).astype(np.float64)
    ranks = rankdata(flat, method="average") - 1.0  # in [0, N-1]
    n = len(flat)
    if n > 1:
        ranks = ranks / (n - 1)
    return ranks.reshape(patch.shape)


@dataclass
class DescriptorConfig:
    scales: Sequence[int] = (16, 24, 32)     # patch side lengths, pixels
    resolution: int = 8                       # persistence-image grid side
    birth_range: Tuple[float, float] = (0.0, 1.0)   # assumes patch intensities normalized to [0,1]
    pers_range: Tuple[float, float] = (0.0, 1.0)
    rank_normalize: bool = False              # exact monotonic-transform invariance (see rank_normalize_patch)
    use_dims: Tuple[int, ...] = (0, 1)        # ablation: which homological dimensions to include (0, 1, or both)
    backend: str = "bitpacked"                # "bitpacked" (default, from-scratch) or "gudhi" (optional, ~7.7x faster on the PH step alone, requires `pip install gudhi`)

    @property
    def dim(self) -> int:
        # len(use_dims) homological dimensions x len(scales) x resolution^2
        return len(self.use_dims) * len(self.scales) * self.resolution * self.resolution


def extract_patch(image: np.ndarray, y: int, x: int, size: int) -> np.ndarray:
    """Extract a `size x size` patch centred at (y, x), zero-padded at borders."""
    half = size // 2
    H, W = image.shape
    y0, y1 = y - half, y - half + size
    x0, x1 = x - half, x - half + size
    patch = np.zeros((size, size), dtype=image.dtype)
    sy0, sy1 = max(y0, 0), min(y1, H)
    sx0, sx1 = max(x0, 0), min(x1, W)
    if sy1 <= sy0 or sx1 <= sx0:
        return patch
    py0, px0 = sy0 - y0, sx0 - x0
    patch[py0:py0 + (sy1 - sy0), px0:px0 + (sx1 - sx0)] = image[sy0:sy1, sx0:sx1]
    return patch


def compute_pw_descriptor(image: np.ndarray, y: int, x: int,
                           cfg: DescriptorConfig = DescriptorConfig()) -> np.ndarray:
    """
    Compute the full multi-scale Persistence-Weighted Descriptor for a
    single keypoint (y, x) in a grayscale image normalized to [0, 1].

    Returns a flat vector of length `cfg.dim`.
    """
    assert image.ndim == 2
    assert image.min() >= -1e-6 and image.max() <= 1.0 + 1e-6, \
        "compute_pw_descriptor expects intensities normalized to [0, 1]"

    vecs = []
    for size in cfg.scales:
        patch = extract_patch(image, y, x, size)
        if cfg.rank_normalize:
            patch = rank_normalize_patch(patch)
        pd0, pd1 = compute_persistence_diagrams(patch, backend=cfg.backend)
        if 0 in cfg.use_dims:
            img0 = persistence_image(pd0, cfg.birth_range, cfg.pers_range, cfg.resolution)
            vecs.append(img0.reshape(-1))
        if 1 in cfg.use_dims:
            img1 = persistence_image(pd1, cfg.birth_range, cfg.pers_range, cfg.resolution)
            vecs.append(img1.reshape(-1))
    desc = np.concatenate(vecs)
    norm = np.linalg.norm(desc)
    if norm > 1e-12:
        desc = desc / norm
    return desc


def compute_pw_descriptors_batch(image: np.ndarray, keypoints: np.ndarray,
                                  cfg: DescriptorConfig = DescriptorConfig()) -> np.ndarray:
    """
    keypoints: (N, 2) array of (y, x) integer pixel coordinates.
    Returns: (N, cfg.dim) descriptor matrix.
    """
    out = np.zeros((len(keypoints), cfg.dim), dtype=np.float64)
    for i, (y, x) in enumerate(keypoints):
        out[i] = compute_pw_descriptor(image, int(y), int(x), cfg)
    return out
