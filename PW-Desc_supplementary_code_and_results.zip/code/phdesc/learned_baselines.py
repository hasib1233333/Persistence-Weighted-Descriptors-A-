r"""
phdesc.learned_baselines
==========================

REAL baseline implementations, added when this sandbox turned out to have
capabilities not available in earlier rounds of this project:

  - SIFT, ORB: via OpenCV (cv2.SIFT_create / cv2.ORB_create). These are the
    genuine, patent-free (SIFT expired 2020) OpenCV implementations, not
    reimplementations -- real, off-the-shelf baseline descriptors.

  - SuperPoint (DeTone, Malisiewicz & Rabinovich, 2018): the OFFICIAL
    pretrained weights and reference inference code released by Magic
    Leap, Inc. at https://github.com/magicleap/SuperPointPretrainedNetwork,
    downloaded at evaluation time (NOT bundled with this repository -- see
    licensing note below).

  - DISK (Tyszkiewicz, Fua & Trulls, 2020): the OFFICIAL pretrained
    ("depth") checkpoint released by the original authors at
    https://github.com/cvlab-epfl/disk, accessed through kornia's
    `KF.DISK.from_pretrained("depth")`, which downloads the identical file
    from the same official GitHub source (not a kornia-specific
    reimplementation of the weights). Discovered reachable, unlike
    SuperPoint's checkpoint host being a coincidence, because DISK's
    authors also host their weights directly on GitHub rather than a
    separate model hub.

LICENSING NOTE (important, read before use)
---------------------------------------------
SuperPoint's official weights and reference code are released under an
"Academic or Non-Profit Organization Noncommercial Research Use Only"
license (see the LICENSE file at the URL above). DISK's official
repository is released under an Apache 2.0 license, which permits this
use without the same noncommercial restriction; we still attribute every
DISK number explicitly rather than presenting it as this paper's own
descriptor's output. This module therefore:
  (a) does NOT bundle superpoint_v1.pth, demo_superpoint.py, or DISK's
      depth-save.pth in this repository -- weights are fetched from the
      official sources at evaluation time, exactly as each license
      anticipates each user doing independently;
  (b) is intended, and should only be used, for noncommercial academic
      research comparison (exactly the use in this manuscript);
  (c) every number produced using it is clearly attributed to
      \citet{detone2018superpoint} or \citet{tyszkiewicz2020disk} and the
      official checkpoint in the manuscript text, not presented as our
      own descriptor's output.

SIFT/ORB via OpenCV carry no such restriction (SIFT's patent expired in
2020; ORB was designed as a free alternative from the outset).
"""

from __future__ import annotations
import os
import subprocess
import numpy as np
from typing import Tuple


def fetch_superpoint_reference(dest_dir: str) -> Tuple[str, str]:
    """
    Downloads the official SuperPoint reference code and weights from
    Magic Leap's public GitHub repository (noncommercial research license,
    see module docstring), if not already present in `dest_dir`.

    Returns (code_path, weights_path).
    """
    os.makedirs(dest_dir, exist_ok=True)
    code_path = os.path.join(dest_dir, "demo_superpoint.py")
    weights_path = os.path.join(dest_dir, "superpoint_v1.pth")

    base = "https://raw.githubusercontent.com/magicleap/SuperPointPretrainedNetwork/master"
    if not os.path.exists(code_path):
        subprocess.run(["curl", "-sL", "-o", code_path, f"{base}/demo_superpoint.py"], check=True)
    if not os.path.exists(weights_path):
        subprocess.run(["curl", "-sL", "-o", weights_path,
                         "https://github.com/magicleap/SuperPointPretrainedNetwork/raw/master/superpoint_v1.pth"],
                        check=True)
    return code_path, weights_path


class SuperPointWrapper:
    """Thin adapter exposing SuperPoint through the same (image, keypoints)
    -> descriptors interface used by phdesc.baselines, so it can be dropped
    into the existing evaluation harness unchanged."""

    def __init__(self, ref_dir: str = "/home/claude/superpoint_ref",
                 nms_dist: int = 4, conf_thresh: float = 0.015, nn_thresh: float = 0.7):
        code_path, weights_path = fetch_superpoint_reference(ref_dir)
        import sys
        if ref_dir not in sys.path:
            sys.path.insert(0, ref_dir)
        from demo_superpoint import SuperPointFrontend  # type: ignore
        self.frontend = SuperPointFrontend(weights_path, nms_dist=nms_dist,
                                            conf_thresh=conf_thresh, nn_thresh=nn_thresh, cuda=False)

    def detect_and_describe(self, image: np.ndarray):
        """
        image: (H, W) float array in [0, 1].
        Returns (keypoints (N,2) as (y,x) int, descriptors (N,256) float).
        """
        img32 = image.astype(np.float32)
        pts, desc, _ = self.frontend.run(img32)  # pts: (3,N) x,y,conf ; desc: (256,N)
        if pts.shape[1] == 0:
            return np.zeros((0, 2), dtype=np.int64), np.zeros((0, 256))
        kp_yx = np.stack([pts[1], pts[0]], axis=1).round().astype(np.int64)  # (N,2) y,x
        descs = desc.T  # (N, 256), already unit-normalized by SuperPoint
        return kp_yx, descs


class DISKWrapper:
    """Thin adapter exposing DISK (Tyszkiewicz et al., 2020) through the
    same (image, keypoints) -> descriptors interface, via kornia's
    from_pretrained loader (official 'depth' checkpoint, downloaded from
    the authors' own GitHub repository -- see module docstring)."""

    def __init__(self, n_keypoints: int = 500):
        import torch
        import kornia.feature as KF
        self.torch = torch
        self.model = KF.DISK.from_pretrained("depth")
        self.model.eval()
        self.n_keypoints = n_keypoints

    def detect_and_describe(self, image: np.ndarray):
        """
        image: (H, W) float array in [0, 1] (grayscale; DISK expects RGB,
        so it is replicated across 3 channels).
        Returns (keypoints (N,2) as (y,x) int, descriptors (N,128) float).
        DISK requires input dimensions divisible by 16; the image is
        center-cropped to the nearest multiple before inference and
        keypoint coordinates are offset back into the original frame.
        """
        torch = self.torch
        H, W = image.shape
        H16, W16 = (H // 16) * 16, (W // 16) * 16
        if H16 == 0 or W16 == 0:
            return np.zeros((0, 2), dtype=np.int64), np.zeros((0, 128))
        y0, x0 = (H - H16) // 2, (W - W16) // 2
        cropped = image[y0:y0 + H16, x0:x0 + W16]
        img_t = torch.from_numpy(cropped.astype(np.float32))[None, None].repeat(1, 3, 1, 1)
        with torch.no_grad():
            features = self.model(img_t, n=self.n_keypoints, pad_if_not_divisible=True)
        f = features[0]
        kps_xy = f.keypoints.cpu().numpy()  # (N, 2) x, y
        descs = f.descriptors.cpu().numpy()  # (N, 128)
        if len(kps_xy) == 0:
            return np.zeros((0, 2), dtype=np.int64), np.zeros((0, 128))
        kp_yx = np.stack([kps_xy[:, 1] + y0, kps_xy[:, 0] + x0], axis=1).round().astype(np.int64)
        return kp_yx, descs


def sift_detect_and_describe(image: np.ndarray, max_keypoints: int = 500):
    """Real OpenCV SIFT. image: (H,W) float in [0,1]. Returns (kp (N,2) y,x, desc (N,128))."""
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    sift = cv2.SIFT_create(nfeatures=max_keypoints)
    kps, desc = sift.detectAndCompute(img8, None)
    if desc is None or len(kps) == 0:
        return np.zeros((0, 2), dtype=np.int64), np.zeros((0, 128))
    kp_yx = np.array([[kp.pt[1], kp.pt[0]] for kp in kps]).round().astype(np.int64)
    return kp_yx, desc.astype(np.float64)


def orb_detect_and_describe(image: np.ndarray, max_keypoints: int = 500):
    """Real OpenCV ORB. image: (H,W) float in [0,1]. Returns (kp (N,2) y,x, desc (N,32) uint8 binary)."""
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    orb = cv2.ORB_create(nfeatures=max_keypoints)
    kps, desc = orb.detectAndCompute(img8, None)
    if desc is None or len(kps) == 0:
        return np.zeros((0, 2), dtype=np.int64), np.zeros((0, 32), dtype=np.uint8)
    kp_yx = np.array([[kp.pt[1], kp.pt[0]] for kp in kps]).round().astype(np.int64)
    return kp_yx, desc


def hamming_nn_ratio_match(desc_a: np.ndarray, desc_b: np.ndarray, ratio_thresh: float = 0.85):
    """Nearest-neighbour ratio-test matching for binary (ORB) descriptors using Hamming distance."""
    if len(desc_a) == 0 or len(desc_b) == 0:
        return np.zeros((0, 2), dtype=np.int64)
    a_bits = np.unpackbits(desc_a, axis=1).astype(np.int16)
    b_bits = np.unpackbits(desc_b, axis=1).astype(np.int16)
    dist = np.zeros((len(a_bits), len(b_bits)), dtype=np.int32)
    for i in range(len(a_bits)):
        dist[i] = np.sum(a_bits[i] != b_bits, axis=1)
    order = np.argsort(dist, axis=1)
    matches = []
    for i in range(len(desc_a)):
        j1 = order[i, 0]
        if dist.shape[1] < 2:
            matches.append((i, j1)); continue
        j2 = order[i, 1]
        r = (dist[i, j1] + 1e-6) / (dist[i, j2] + 1e-6)
        if r < ratio_thresh:
            matches.append((i, j1))
    return np.array(matches, dtype=np.int64).reshape(-1, 2)
