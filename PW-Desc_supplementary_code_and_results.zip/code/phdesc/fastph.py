"""
fastph.py -- fast persistent homology of a 2-D grayscale patch under the
vertex (lower-star) cubical filtration, compiled with Numba.

H0: union-find over pixels in increasing order of value, 4-connectivity,
    elder rule (the younger component dies when two meet).
H1: by duality. For the vertex construction a cell of the sublevel complex
    X_t is missing exactly when one of its corner pixels exceeds t, so the
    bounded holes of X_t are the 8-connected components of {P > t} that do
    not contain a border pixel. A hole is therefore born when such a
    component separates from the border region and dies when its last pixel
    (its maximum) enters X_t. We run union-find over pixels in decreasing
    order with 8-connectivity and a virtual border node of value +inf; a
    component born at its maximum m that merges at level s gives the H1 pair
    (s, m).
Only pairs with death > birth are returned (the off-diagonal diagram used
by PW-Desc). Checked against GUDHI's cubical complex (vertices=...) by
scripts/verify_fastph.py.
"""
import numpy as np
from numba import njit


@njit(cache=True)
def _find(parent, i):
    r = i
    while parent[r] != r:
        r = parent[r]
    while parent[i] != r:
        nxt = parent[i]
        parent[i] = r
        i = nxt
    return r


@njit(cache=True)
def _h0(flat, h, w, order):
    n = h * w
    parent = np.full(n, -1, np.int64)
    birth = np.zeros(n, np.float64)
    out = np.empty((n, 2), np.float64)
    k = 0
    for idx in range(n):
        v = order[idx]
        t = flat[v]
        parent[v] = v
        birth[v] = t
        y, x = v // w, v % w
        for d in range(4):
            if d == 0:
                yy, xx = y - 1, x
            elif d == 1:
                yy, xx = y + 1, x
            elif d == 2:
                yy, xx = y, x - 1
            else:
                yy, xx = y, x + 1
            if yy < 0 or yy >= h or xx < 0 or xx >= w:
                continue
            u = yy * w + xx
            if parent[u] < 0:
                continue
            ru, rv = _find(parent, u), _find(parent, v)
            if ru == rv:
                continue
            # elder rule: older (smaller birth) survives
            if birth[ru] < birth[rv] or (birth[ru] == birth[rv] and ru < rv):
                old, young = ru, rv
            else:
                old, young = rv, ru
            if t > birth[young]:
                out[k, 0] = birth[young]; out[k, 1] = t; k += 1
            parent[young] = old
    return out[:k]


@njit(cache=True)
def _h1(flat, h, w, order_desc):
    n = h * w
    B = n                                   # virtual border node
    parent = np.full(n + 1, -1, np.int64)
    birth = np.zeros(n + 1, np.float64)
    parent[B] = B
    birth[B] = np.inf
    out = np.empty((n, 2), np.float64)
    k = 0
    for idx in range(n):
        v = order_desc[idx]
        t = flat[v]
        parent[v] = v
        birth[v] = t
        y, x = v // w, v % w
        for d in range(9):
            if d == 4:
                continue
            dy, dx = d // 3 - 1, d % 3 - 1
            yy, xx = y + dy, x + dx
            if yy < 0 or yy >= h or xx < 0 or xx >= w:
                u = B
            else:
                u = yy * w + xx
                if parent[u] < 0:
                    continue
            ru, rv = _find(parent, u), _find(parent, v)
            if ru == rv:
                continue
            # elder rule for superlevel sets: larger birth survives
            if birth[ru] > birth[rv] or (birth[ru] == birth[rv] and ru > rv):
                old, young = ru, rv
            else:
                old, young = rv, ru
            if birth[young] > t:
                out[k, 0] = t; out[k, 1] = birth[young]; k += 1
            parent[young] = old
    return out[:k]


def diagrams(patch):
    """Return (D0, D1) as float64 arrays of (birth, death) with death > birth."""
    P = np.ascontiguousarray(patch, dtype=np.float64)
    h, w = P.shape
    flat = P.ravel()
    order = np.argsort(flat, kind="stable")
    return _h0(flat, h, w, order), _h1(flat, h, w, order[::-1].copy())


# --------------------------------------------------------------------------
# Whole-descriptor batch path (same output as descriptor.compute_pw_descriptors_batch)
@njit(cache=True)
def _avg_rank(flat):
    n = flat.size
    order = np.argsort(flat, kind="mergesort")
    r = np.empty(n, np.float64)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and flat[order[j + 1]] == flat[order[i]]:
            j += 1
        avg = 0.5 * (i + j)
        for k in range(i, j + 1):
            r[order[k]] = avg
        i = j + 1
    if n > 1:
        r /= (n - 1)
    return r


@njit(cache=True)
def _pi_accumulate(D, out, off, grid, sigma, pmax, tau):
    r = grid.size
    for u in range(D.shape[0]):
        b = D[u, 0]; p = D[u, 1] - D[u, 0]
        w = (p - tau) / max(pmax - tau, 1e-12)
        if w <= 0.0:
            continue
        if w > 1.0:
            w = 1.0
        for i in range(r):
            gp = np.exp(-(grid[i] - p) ** 2 / (2 * sigma * sigma)) * w
            for j in range(r):
                out[off + i * r + j] += gp * np.exp(-(grid[j] - b) ** 2 / (2 * sigma * sigma))


@njit(cache=True)
def _batch(image, kps, scales, r, sigma, pmax, tau, rank):
    H, W = image.shape
    n = kps.shape[0]
    dim = 2 * scales.size * r * r
    X = np.zeros((n, dim), np.float64)
    grid = np.linspace(0.0, 1.0, r)
    for q in range(n):
        y, x = kps[q, 0], kps[q, 1]
        off = 0
        for si in range(scales.size):
            s = scales[si]
            half = s // 2
            P = np.zeros((s, s), np.float64)
            for a in range(s):
                yy = y - half + a
                if yy < 0 or yy >= H:
                    continue
                for c in range(s):
                    xx = x - half + c
                    if 0 <= xx < W:
                        P[a, c] = image[yy, xx]
            flat = P.ravel().copy()
            if rank:
                flat = _avg_rank(flat)
            order = np.argsort(flat, kind="mergesort")
            D0 = _h0(flat, s, s, order)
            D1 = _h1(flat, s, s, order[::-1].copy())
            _pi_accumulate(D0, X[q], off, grid, sigma, pmax, tau); off += r * r
            _pi_accumulate(D1, X[q], off, grid, sigma, pmax, tau); off += r * r
        nr = np.sqrt(np.sum(X[q] ** 2))
        if nr > 1e-12:
            X[q] /= nr
    return X


def pw_desc_batch(image, keypoints, scales=(16, 24, 32), resolution=8, tau=0.0, rank=False, p_max=1.0):
    """Compiled PW-Desc for many keypoints; numerically identical to the reference path."""
    return _batch(np.ascontiguousarray(image, np.float64), np.ascontiguousarray(keypoints, np.int64),
                  np.array(scales, np.int64), int(resolution), 1.0 / resolution, float(p_max), float(tau), bool(rank))
