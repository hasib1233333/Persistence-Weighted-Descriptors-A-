"""
phdesc.matching
================

Standard infrastructure surrounding the descriptor: keypoint detection
(Harris corners -- NOT a contribution of this work, used only as a
detector-agnostic front end so PW-Desc can be evaluated against baseline
descriptors under identical keypoint locations, isolating the effect of
description from detection), nearest-neighbour + mutual/ratio-test
matching, and RANSAC-based geometric verification.

The Harris corner response and non-maximum suppression are implemented
from scratch (no cv2 dependency); RANSAC model fitting reuses
scikit-image's general-purpose `skimage.measure.ransac` with a projective
(homography) model, which is standard third-party evaluation
infrastructure (not part of the descriptor contribution) and is exactly
the protocol used across the image-matching benchmark literature (e.g.
SuperGlue, LoFTR) to keep numbers comparable.
"""

from __future__ import annotations
import numpy as np
from scipy import ndimage as ndi
from typing import Tuple


def harris_keypoints(image: np.ndarray, max_keypoints: int = 500,
                      k: float = 0.04, sigma: float = 1.5,
                      min_distance: int = 8) -> np.ndarray:
    """
    From-scratch Harris corner detector.

    image: 2D float array normalized to [0, 1].
    Returns: (N, 2) array of (y, x) integer keypoint coordinates, sorted by
             decreasing corner response, N <= max_keypoints.
    """
    gy, gx = np.gradient(image)
    Ixx = ndi.gaussian_filter(gx * gx, sigma)
    Iyy = ndi.gaussian_filter(gy * gy, sigma)
    Ixy = ndi.gaussian_filter(gx * gy, sigma)

    det = Ixx * Iyy - Ixy * Ixy
    trace = Ixx + Iyy
    response = det - k * (trace ** 2)

    # non-maximum suppression via local maximum filter
    local_max = ndi.maximum_filter(response, size=min_distance) == response
    H, W = image.shape
    margin = min_distance
    mask = np.zeros_like(response, dtype=bool)
    mask[margin:H - margin, margin:W - margin] = True
    candidates = np.argwhere(local_max & mask & (response > 0))

    if len(candidates) == 0:
        return np.zeros((0, 2), dtype=np.int64)

    scores = response[candidates[:, 0], candidates[:, 1]]
    order = np.argsort(-scores)[:max_keypoints]
    return candidates[order]


def nn_ratio_match(desc_a: np.ndarray, desc_b: np.ndarray,
                    ratio_thresh: float = 0.85, mutual: bool = True) -> np.ndarray:
    """
    Lowe's ratio-test nearest-neighbour matching between two descriptor
    sets, with optional mutual-nearest-neighbour consistency check.

    Returns: (M, 2) array of matched index pairs (i in A, j in B).
    """
    if len(desc_a) == 0 or len(desc_b) == 0:
        return np.zeros((0, 2), dtype=np.int64)

    d2 = (np.sum(desc_a ** 2, axis=1, keepdims=True)
          + np.sum(desc_b ** 2, axis=1)[None, :]
          - 2 * desc_a @ desc_b.T)
    d2 = np.maximum(d2, 0.0)

    order = np.argsort(d2, axis=1)
    matches = []
    for i in range(len(desc_a)):
        j1 = order[i, 0]
        if d2.shape[1] < 2:
            matches.append((i, j1))
            continue
        j2 = order[i, 1]
        r = np.sqrt(d2[i, j1] + 1e-12) / np.sqrt(d2[i, j2] + 1e-12)
        if r < ratio_thresh:
            matches.append((i, j1))

    if mutual and len(matches) > 0:
        order_b = np.argsort(d2, axis=0)
        best_a_for_b = order_b[0, :]
        matches = [(i, j) for (i, j) in matches if best_a_for_b[j] == i]

    return np.array(matches, dtype=np.int64).reshape(-1, 2)


def geometric_verify_homography(pts_a: np.ndarray, pts_b: np.ndarray,
                                 residual_threshold: float = 3.0,
                                 max_trials: int = 2000) -> Tuple[np.ndarray, np.ndarray]:
    """
    RANSAC homography fit for geometric verification of matches. Standard
    evaluation infrastructure (skimage.measure.ransac), not a contribution
    of this work.

    pts_a, pts_b: (M, 2) arrays of (x, y) matched keypoint coordinates.

    Returns
    -------
    H : (3, 3) homography matrix or None if fit failed.
    inlier_mask : (M,) boolean array.
    """
    from skimage.measure import ransac
    from skimage.transform import ProjectiveTransform

    if len(pts_a) < 4:
        return None, np.zeros(len(pts_a), dtype=bool)

    try:
        model, inliers = ransac((pts_a, pts_b), ProjectiveTransform,
                                 min_samples=4, residual_threshold=residual_threshold,
                                 max_trials=max_trials)
        if model is None:
            return None, np.zeros(len(pts_a), dtype=bool)
        return model.params, inliers
    except Exception:
        return None, np.zeros(len(pts_a), dtype=bool)
