"""
phdesc.datasets
=================

Loader interfaces for the four public, real-world, citable benchmarks used
in the experimental protocol (Sec. 5 of the manuscript):

  1. HPatches      (Balntas, Lenc, Vedaldi & Mikolajczyk, CVPR 2017)
     "HPatches: A benchmark and evaluation of handcrafted and learned local
     descriptors." 116 planar scenes, viewpoint + illumination sequences.
     https://github.com/hpatches/hpatches-dataset

  2. MegaDepth      (Li & Snavely, CVPR 2018)
     "MegaDepth: Learning Single-View Depth Prediction from Internet
     Photos." Large-scale outdoor wide-baseline image pairs with
     SfM-derived depth/pose, used as the de facto standard outdoor
     wide-baseline matching benchmark (test split as used by SuperGlue /
     LoFTR / DISK).
     https://www.cs.cornell.edu/projects/megadepth/

  3. ScanNet        (Dai et al., CVPR 2017)
     "ScanNet: Richly-annotated 3D Reconstructions of Indoor Scenes."
     Indoor RGB-D wide-baseline image pairs with ground-truth pose, used
     as the standard indoor matching benchmark (test split as used by
     SuperGlue / LoFTR).
     http://www.scan-net.org/

  4. Oxford-Affine / VGG Affine Covariant Regions dataset
     (Mikolajczyk & Schmid, IJCV 2005 / Mikolajczyk et al., IJCV 2005)
     "A comparison of affine region detectors." 8 scenes with known
     homographies under viewpoint, scale, blur, JPEG compression and
     illumination changes.
     https://www.robots.ox.ac.uk/~vgg/research/affine/

IMPORTANT / HONESTY NOTE
-------------------------
This module provides the LOADER INTERFACE and the exact expected on-disk
layout for each dataset -- it does NOT ship the datasets themselves (they
are large, license-restricted downloads and this development sandbox has
no network access to their hosts). Running `code/scripts/run_full_
benchmark_suite.py` after populating `data/<dataset_name>/` following the
layout below (see EXPERIMENT_PROTOCOL.md) will produce the real Table
2-5 numbers reported in the manuscript's Results section placeholders.
No numbers from these four datasets are asserted anywhere in the
manuscript text or LaTeX tables in this submission package; they are left
as explicit placeholders for the user to fill in after running this code.
"""

from __future__ import annotations
import os
import numpy as np
from dataclasses import dataclass
from typing import List, Tuple, Optional


@dataclass
class ImagePairSample:
    image_a: np.ndarray          # (H, W) float32, normalized [0, 1]
    image_b: np.ndarray
    H_gt: Optional[np.ndarray]   # (3, 3) ground-truth homography, if planar
    pose_gt: Optional[dict]      # {'R':.., 't':.., 'K_a':.., 'K_b':..}, if 3D scene
    pair_id: str


class HPatchesLoader:
    """
    Expected layout: data/hpatches/hpatches-sequences-release/<seq_name>/
        {1,2,3,4,5,6}.ppm   -- 6 images per sequence (1 = reference)
        H_1_2.txt ... H_1_6.txt   -- ground-truth homographies to image 1
    Sequence folders prefixed 'i_' = illumination change, 'v_' = viewpoint.
    """
    def __init__(self, root: str):
        self.root = root

    def list_sequences(self) -> List[str]:
        if not os.path.isdir(self.root):
            return []
        return sorted([d for d in os.listdir(self.root)
                        if os.path.isdir(os.path.join(self.root, d))])

    def iter_pairs(self):
        from skimage.io import imread
        from skimage.color import rgb2gray
        for seq in self.list_sequences():
            seq_dir = os.path.join(self.root, seq)
            ref = rgb2gray(imread(os.path.join(seq_dir, "1.ppm"))).astype(np.float64)
            for k in range(2, 7):
                img_path = os.path.join(seq_dir, f"{k}.ppm")
                h_path = os.path.join(seq_dir, f"H_1_{k}")
                if not (os.path.exists(img_path) and os.path.exists(h_path)):
                    continue
                other = rgb2gray(imread(img_path)).astype(np.float64)
                H_gt = np.loadtxt(h_path)
                yield ImagePairSample(ref, other, H_gt, None, f"{seq}_1_{k}")


class MegaDepthLoader:
    """
    Expected layout (the real, official LoFTR-released MegaDepth-1500 test
    split -- verified against real uploaded data, 2026-08-06; an earlier
    version of this loader assumed a test_pairs.txt format that does not
    match the real release and has been replaced):
        data/megadepth_test_1500/scene_info/<scene>_<range>.npz
            -- image_paths, depth_paths, intrinsics, poses, pair_infos
        data/megadepth_test_1500/Undistorted_SfM/<scene>/images/*.jpg
    Depth maps are NOT required for the pose-estimation evaluation
    protocol (rotation/translation AUC): intrinsics and absolute poses
    are already precomputed in the scene_info files, so relative pose is
    computed directly from those rather than from depth.
    """
    def __init__(self, root: str):
        self.root = root
        self.scene_info_dir = os.path.join(root, "scene_info")
        self.image_root = os.path.join(root, "Undistorted_SfM")

    def list_scene_info_files(self):
        if not os.path.isdir(self.scene_info_dir):
            return []
        return sorted(f for f in os.listdir(self.scene_info_dir) if f.endswith(".npz"))

    def iter_pairs(self, max_pairs_per_file: int = None):
        """Yields PoseSample objects (see below), one per pair_infos entry
        in each scene_info .npz file, skipping any pair whose image file
        is not present on disk (real uploads may be a scene subset)."""
        from skimage.io import imread
        from skimage.color import rgb2gray
        for fname in self.list_scene_info_files():
            data = np.load(os.path.join(self.scene_info_dir, fname), allow_pickle=True)
            image_paths = data["image_paths"]
            intrinsics = data["intrinsics"]
            poses = data["poses"]
            pair_infos = data["pair_infos"]
            n_yielded = 0
            for (idx0, idx1), overlap, _ in pair_infos:
                if max_pairs_per_file is not None and n_yielded >= max_pairs_per_file:
                    break
                p0, p1 = image_paths[idx0], image_paths[idx1]
                if p0 is None or p1 is None:
                    continue
                full0 = os.path.join(self.image_root, p0.replace("Undistorted_SfM/", "", 1))
                full1 = os.path.join(self.image_root, p1.replace("Undistorted_SfM/", "", 1))
                if not (os.path.exists(full0) and os.path.exists(full1)):
                    continue
                img0 = rgb2gray(imread(full0)).astype(np.float64)
                img1 = rgb2gray(imread(full1)).astype(np.float64)
                yield PoseSample(
                    image_a=img0, image_b=img1,
                    K_a=intrinsics[idx0].astype(np.float64),
                    K_b=intrinsics[idx1].astype(np.float64),
                    pose_a=poses[idx0].astype(np.float64),
                    pose_b=poses[idx1].astype(np.float64),
                    overlap=float(overlap),
                    pair_id=f"{fname[:-4]}_{idx0}_{idx1}",
                )
                n_yielded += 1


@dataclass
class PoseSample:
    """A real image pair with ground-truth absolute poses and intrinsics,
    for relative-pose (essential-matrix) evaluation -- MegaDepth/ScanNet
    protocol, distinct from ImagePairSample's homography-based protocol
    (Oxford-Affine/HPatches)."""
    image_a: np.ndarray
    image_b: np.ndarray
    K_a: np.ndarray       # (3,3) intrinsics
    K_b: np.ndarray       # (3,3) intrinsics
    pose_a: np.ndarray    # (4,4) world-to-camera (or camera-to-world; see relative_pose())
    pose_b: np.ndarray    # (4,4)
    overlap: float
    pair_id: str

    def relative_pose(self):
        """Returns (R, t) such that X_b = R @ X_a + t (world-to-camera
        convention, the standard MegaDepth/LoFTR release format: pose_a,
        pose_b are each [R|t] world-to-camera extrinsics, so the relative
        transform is R = R_b @ R_a.T, t = t_b - R @ t_a)."""
        R_a, t_a = self.pose_a[:3, :3], self.pose_a[:3, 3]
        R_b, t_b = self.pose_b[:3, :3], self.pose_b[:3, 3]
        R = R_b @ R_a.T
        t = t_b - R @ t_a
        return R, t


class ScanNetLoader:
    """
    Expected layout (SuperGlue/LoFTR-style indoor test split):
        data/scannet/test_pairs.txt
        data/scannet/scans_test/<scene_id>/color/*.jpg
        data/scannet/scans_test/<scene_id>/pose/*.txt
        data/scannet/scans_test/<scene_id>/intrinsic/intrinsic_color.txt
    """
    def __init__(self, root: str, pairs_file: str = "test_pairs.txt"):
        self.root = root
        self.pairs_file = os.path.join(root, pairs_file)

    def iter_pairs(self):
        if not os.path.exists(self.pairs_file):
            return
        from skimage.io import imread
        from skimage.color import rgb2gray
        with open(self.pairs_file) as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) < 2:
                    continue
                scene, ia, ib = parts[0], parts[1], parts[2]
                base = os.path.join(self.root, "scans_test", scene)
                img_a = rgb2gray(imread(os.path.join(base, "color", f"{ia}.jpg")))
                img_b = rgb2gray(imread(os.path.join(base, "color", f"{ib}.jpg")))
                yield ImagePairSample(img_a.astype(np.float64), img_b.astype(np.float64),
                                        None, {"scene": scene}, f"{scene}_{ia}_{ib}")


class OxfordAffineLoader:
    """
    Expected layout: data/oxford_affine/<scene_name>/
        img{1..6}.ppm or img{1..6}.pgm
        H1to{2..6}p
    Scenes: bark, bikes, boat, graf, leuven, trees, ubc, wall.

    Note: the 'boat' scene ships as grayscale .pgm in the real Oxford
    dataset, not .ppm like the other seven scenes -- discovered when this
    loader was first run against real, uploaded data (2026-08-02); the
    original version hardcoded .ppm and would have silently skipped
    'boat' entirely (empty iteration, no error). Both extensions are now
    checked explicitly.
    """
    def __init__(self, root: str):
        self.root = root

    def list_scenes(self) -> List[str]:
        if not os.path.isdir(self.root):
            return []
        return sorted([d for d in os.listdir(self.root)
                        if os.path.isdir(os.path.join(self.root, d))])

    def _find_image(self, scene_dir: str, k: int):
        for ext in ("ppm", "pgm"):
            p = os.path.join(scene_dir, f"img{k}.{ext}")
            if os.path.exists(p):
                return p
        return None

    def iter_pairs(self):
        from skimage.io import imread
        from skimage.color import rgb2gray
        for scene in self.list_scenes():
            scene_dir = os.path.join(self.root, scene)
            ref_path = self._find_image(scene_dir, 1)
            if ref_path is None:
                continue
            ref_raw = imread(ref_path)
            ref = rgb2gray(ref_raw).astype(np.float64) if ref_raw.ndim == 3 else ref_raw.astype(np.float64) / 255.0
            for k in range(2, 7):
                img_path = self._find_image(scene_dir, k)
                h_path = os.path.join(scene_dir, f"H1to{k}p")
                if img_path is None or not os.path.exists(h_path):
                    continue
                other_raw = imread(img_path)
                other = rgb2gray(other_raw).astype(np.float64) if other_raw.ndim == 3 else other_raw.astype(np.float64) / 255.0
                H_gt = np.loadtxt(h_path)
                yield ImagePairSample(ref, other, H_gt, None, f"{scene}_1_{k}")
