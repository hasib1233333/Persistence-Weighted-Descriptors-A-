"""
phdesc.metric_learning
=======================

A lightweight, dependency-free linear metric-learning stage that projects
the (potentially high-dimensional, sparse) persistence-image descriptor
into a compact, discriminative Euclidean space, trained with a standard
contrastive loss via plain numpy gradient descent (no PyTorch/TensorFlow
dependency -- keeps the entire pipeline "from scratch" and runnable on any
machine, including the CPU-only environment used for algorithm
development in this repository).

We deliberately keep this stage LINEAR (a single projection matrix W):
    z = W x / ||W x||
This is an intentional design choice, not a limitation of convenience --
Proposition 2 in the manuscript shows that composing our descriptor with
a linear, non-expansive (operator-norm <= 1) projection preserves the
Lipschitz stability guarantee of Proposition 1 with the same constant
scaled by ||W||_2. A nonlinear (e.g. deep) projection head would forfeit
this closed-form guarantee unless explicitly constrained to be Lipschitz,
which is exactly why we constrain W: after each gradient step we project
W back onto the operator-norm-<=1 ball (a "spectral normalization" step,
implemented explicitly below via SVD), preserving the guarantee at every
step of training, not just at initialization.
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass


def _spectral_normalize(W: np.ndarray, max_norm: float = 1.0) -> np.ndarray:
    """Project W onto the set of matrices with operator (spectral) norm <= max_norm."""
    # power-iteration-free exact projection via SVD (cheap for the small
    # projection matrices used here, e.g. (d_out=128) x (d_in<=1024))
    U, S, Vt = np.linalg.svd(W, full_matrices=False)
    S_clipped = np.clip(S, 0, max_norm)
    return (U * S_clipped) @ Vt


@dataclass
class ContrastiveProjectionConfig:
    out_dim: int = 128
    lr: float = 0.05
    epochs: int = 200
    margin: float = 0.3
    weight_decay: float = 1e-4
    seed: int = 0


class ContrastiveLinearProjection:
    """
    Trains W in R^{out_dim x in_dim} to pull together descriptors of
    corresponding (matching) keypoints and push apart non-corresponding
    ones, using a standard hinge-based contrastive loss:

        L = sum_{(i,j) match}      max(0, d(z_i, z_j) - m_pos)^2
          + sum_{(i,k) non-match}  max(0, m_neg - d(z_i, z_k))^2

    with z = W x / ||W x||_2 (unit-normalized projected descriptors) and
    d(.,.) the Euclidean distance. W is spectrally re-normalized after
    every gradient step (see module docstring) to preserve the formal
    stability guarantee of Proposition 2.
    """

    def __init__(self, cfg: ContrastiveProjectionConfig = ContrastiveProjectionConfig()):
        self.cfg = cfg
        self.W = None

    def fit(self, X_a: np.ndarray, X_b: np.ndarray, labels: np.ndarray) -> "ContrastiveLinearProjection":
        """
        X_a, X_b: (N, d) descriptor pairs.
        labels:   (N,) in {1 (matching pair), 0 (non-matching pair)}.
        """
        rng = np.random.default_rng(self.cfg.seed)
        N, d = X_a.shape
        out_dim = min(self.cfg.out_dim, d)
        W = rng.normal(scale=1.0 / np.sqrt(d), size=(out_dim, d))
        W = _spectral_normalize(W, 1.0)

        m_pos = self.cfg.margin
        m_neg = 2 * self.cfg.margin

        for epoch in range(self.cfg.epochs):
            Za = (W @ X_a.T).T
            Zb = (W @ X_b.T).T
            na = np.linalg.norm(Za, axis=1, keepdims=True) + 1e-9
            nb = np.linalg.norm(Zb, axis=1, keepdims=True) + 1e-9
            Za_n, Zb_n = Za / na, Zb / nb

            diff = Za_n - Zb_n
            dist = np.linalg.norm(diff, axis=1)

            grad_W = np.zeros_like(W)
            for i in range(N):
                if labels[i] == 1:
                    if dist[i] > m_pos:
                        coeff = 2 * (dist[i] - m_pos)
                        direction = diff[i] / (dist[i] + 1e-9)
                        grad_z = coeff * direction
                        grad_W += np.outer(grad_z, X_a[i]) - np.outer(grad_z, X_b[i])
                else:
                    if dist[i] < m_neg:
                        coeff = -2 * (m_neg - dist[i])
                        direction = diff[i] / (dist[i] + 1e-9)
                        grad_z = coeff * direction
                        grad_W += np.outer(grad_z, X_a[i]) - np.outer(grad_z, X_b[i])

            grad_W /= max(N, 1)
            grad_W += self.cfg.weight_decay * W
            W = W - self.cfg.lr * grad_W
            W = _spectral_normalize(W, 1.0)   # preserve Lipschitz guarantee every step

        self.W = W
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        assert self.W is not None, "call fit() first"
        Z = (self.W @ X.T).T
        norm = np.linalg.norm(Z, axis=1, keepdims=True) + 1e-9
        return Z / norm
