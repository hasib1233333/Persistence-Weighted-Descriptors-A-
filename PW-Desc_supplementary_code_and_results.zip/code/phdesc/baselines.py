"""
phdesc.baselines
=================

Reference descriptors used as comparison points in the experimental
protocol. These are standard, well-known constructions reimplemented
lightly from scratch (no proprietary/learned weights, so every baseline
here is exactly reproducible without network access):

    - RawPatch     : flattened, mean/contrast-normalized raw intensity
                     patch (the simplest possible descriptor; a sanity
                     lower bound).
    - GradHist     : a SIFT-like descriptor -- local gradient-orientation
                     histograms pooled over a 4x4 spatial grid of cells,
                     8 orientation bins each (Lowe, 2004 construction,
                     reimplemented from scratch; NOT the patented DoG
                     detector, only the descriptor pooling scheme, which
                     has long been a standard, freely reimplementable
                     baseline in the literature).

Real, published *learned* baselines (SuperPoint, DISK, ALIKED, LoFTR,
etc.) are NOT reimplemented here -- the experimental protocol (Sec. 5 of
the manuscript) calls for evaluating against their PUBLISHED official
codebases/checkpoints on the four benchmarks, which requires network and
GPU resources unavailable in this development environment. RawPatch and
GradHist give a meaningful, fully-reproducible classical baseline pair for
in-repository sanity checks (Sec. 6.1, synthetic validation) while the
learned SOTA comparison is executed by the user following
`code/scripts/run_full_benchmark_suite.py` and `EXPERIMENT_PROTOCOL.md`.
"""

from __future__ import annotations
import numpy as np
from scipy import ndimage as ndi

from .descriptor import extract_patch


def raw_patch_descriptor(image: np.ndarray, y: int, x: int, size: int = 16) -> np.ndarray:
    patch = extract_patch(image, y, x, size).astype(np.float64)
    patch = patch - patch.mean()
    std = patch.std()
    if std > 1e-8:
        patch = patch / std
    v = patch.reshape(-1)
    n = np.linalg.norm(v)
    return v / n if n > 1e-12 else v


def gradient_histogram_descriptor(image: np.ndarray, y: int, x: int,
                                   size: int = 16, cells: int = 4, bins: int = 8) -> np.ndarray:
    patch = extract_patch(image, y, x, size).astype(np.float64)
    gy, gx = np.gradient(patch)
    mag = np.sqrt(gx ** 2 + gy ** 2)
    ang = (np.arctan2(gy, gx) + np.pi) % (2 * np.pi)  # in [0, 2*pi)

    cell_size = max(size // cells, 1)
    desc = []
    for cy in range(cells):
        for cx in range(cells):
            y0, y1 = cy * cell_size, min((cy + 1) * cell_size, size)
            x0, x1 = cx * cell_size, min((cx + 1) * cell_size, size)
            m = mag[y0:y1, x0:x1].reshape(-1)
            a = ang[y0:y1, x0:x1].reshape(-1)
            hist, _ = np.histogram(a, bins=bins, range=(0, 2 * np.pi), weights=m)
            desc.append(hist)
    v = np.concatenate(desc)
    n = np.linalg.norm(v)
    return v / n if n > 1e-12 else v


def batch_descriptor(fn, image: np.ndarray, keypoints: np.ndarray, **kwargs) -> np.ndarray:
    if len(keypoints) == 0:
        return np.zeros((0, 1))
    first = fn(image, int(keypoints[0][0]), int(keypoints[0][1]), **kwargs)
    out = np.zeros((len(keypoints), len(first)))
    out[0] = first
    for i in range(1, len(keypoints)):
        out[i] = fn(image, int(keypoints[i][0]), int(keypoints[i][1]), **kwargs)
    return out
