"""
phdesc.stats_tests
====================

From-scratch statistical significance testing utilities used throughout
the experimental protocol: paired bootstrap confidence intervals and a
Wilcoxon signed-rank test (used because per-image-pair matching-accuracy
differences are typically non-Gaussian and paired by construction --
every method is evaluated on the SAME set of image pairs / keypoints).

We deliberately reimplement the Wilcoxon signed-rank statistic and its
normal approximation rather than importing scipy.stats.wilcoxon, so that
the exact test is auditable end-to-end as part of this from-scratch
codebase.
"""

from __future__ import annotations
import numpy as np
from typing import Tuple


def paired_bootstrap_ci(scores_a: np.ndarray, scores_b: np.ndarray,
                         n_boot: int = 10000, alpha: float = 0.05,
                         seed: int = 0) -> Tuple[float, float, float]:
    """
    Bootstrap CI for the mean paired difference (a - b), resampling image
    pairs / keypoints with replacement (standard paired bootstrap).

    Returns (mean_diff, ci_low, ci_high).
    """
    assert len(scores_a) == len(scores_b)
    rng = np.random.default_rng(seed)
    n = len(scores_a)
    diffs = scores_a - scores_b
    mean_diff = float(np.mean(diffs))
    boot_means = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, n, size=n)
        boot_means[b] = np.mean(diffs[idx])
    lo = float(np.percentile(boot_means, 100 * alpha / 2))
    hi = float(np.percentile(boot_means, 100 * (1 - alpha / 2)))
    return mean_diff, lo, hi


def wilcoxon_signed_rank(scores_a: np.ndarray, scores_b: np.ndarray) -> Tuple[float, float]:
    """
    Two-sided Wilcoxon signed-rank test (normal approximation, with
    continuity correction and tie handling via average ranks), computed
    from scratch.

    Returns (z_statistic, two_sided_p_value_normal_approx).
    """
    diffs = scores_a - scores_b
    nz = diffs[diffs != 0]
    n = len(nz)
    if n == 0:
        return 0.0, 1.0

    abs_diffs = np.abs(nz)
    order = np.argsort(abs_diffs, kind="stable")
    ranks = np.empty(n)
    sorted_abs = abs_diffs[order]
    i = 0
    while i < n:
        j = i
        while j + 1 < n and sorted_abs[j + 1] == sorted_abs[i]:
            j += 1
        avg_rank = (i + 1 + j + 1) / 2.0
        ranks[order[i:j + 1]] = avg_rank
        i = j + 1

    signed_ranks = ranks * np.sign(nz)
    W = float(np.sum(signed_ranks[signed_ranks > 0]))
    mean_W = n * (n + 1) / 4.0
    # tie correction for variance
    _, counts = np.unique(sorted_abs, return_counts=True)
    tie_correction = np.sum(counts ** 3 - counts) / 48.0
    var_W = n * (n + 1) * (2 * n + 1) / 24.0 - tie_correction
    var_W = max(var_W, 1e-12)
    std_W = np.sqrt(var_W)

    cc = 0.5 if W > mean_W else (-0.5 if W < mean_W else 0.0)
    z = (W - mean_W - cc) / std_W

    # two-sided p-value via normal CDF (erf-based, no scipy dependency)
    from math import erf
    p = 2 * (1 - 0.5 * (1 + erf(abs(z) / np.sqrt(2))))
    p = float(np.clip(p, 0.0, 1.0))
    return float(z), p
