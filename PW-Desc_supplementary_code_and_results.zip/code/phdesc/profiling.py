"""
phdesc.profiling
==================

Component-wise runtime profiling of the PW-Desc pipeline
(T_filter + T_boundary_matrix + T_reduction + T_vectorization + T_projection),
and wrappers around library-standard CPU keypoint detectors (Harris, FAST,
DoG-blob via scikit-image; SIFT/ORB detectors via OpenCV, both real,
third-party implementations, not reimplemented here) for the detector-
repeatability ablation.

This module does NOT change the production code path in
phdesc.persistence / phdesc.descriptor -- it duplicates the minimal
sequence of calls with explicit timers around each stage, so profiling
overhead cannot contaminate the numbers reported elsewhere (e.g. Table 8).
"""
from __future__ import annotations
import time
import numpy as np

from .persistence import _enumerate_cells, _reduce_boundary_matrix, PersistenceDiagram
from .descriptor import extract_patch, persistence_image, rank_normalize_patch, DescriptorConfig
from .metric_learning import ContrastiveLinearProjection, ContrastiveProjectionConfig


def profile_single_descriptor(image: np.ndarray, y: int, x: int,
                               cfg: DescriptorConfig = DescriptorConfig(),
                               projection: ContrastiveLinearProjection = None) -> dict:
    """
    Compute one full PW-Desc descriptor while recording wall-clock time
    spent in each pipeline stage, summed across all scales in cfg.scales.

    Returns a dict of stage -> milliseconds, plus 'total_ms'.
    """
    times = dict(extract_ms=0.0, filter_ms=0.0, boundary_matrix_ms=0.0,
                 reduction_ms=0.0, vectorization_ms=0.0, projection_ms=0.0)

    vecs = []
    for size in cfg.scales:
        t0 = time.perf_counter()
        patch = extract_patch(image, y, x, size)
        if cfg.rank_normalize:
            patch = rank_normalize_patch(patch)
        times["extract_ms"] += (time.perf_counter() - t0) * 1000

        # ---- replicate compute_persistence_diagrams with stage timers ----
        H, W = patch.shape
        g = patch.astype(np.float64)
        vertex_values = g.reshape(-1)

        t0 = time.perf_counter()
        info = _enumerate_cells(H, W)  # cached after first call per shape
        n_vertices, n_edges, n_squares = info["n_vertices"], info["n_edges"], info["n_squares"]
        cell_dim = info["cell_dim"]
        cell_faces = info["cell_faces"]
        edges_arr, squares_arr = info["edges_arr"], info["squares_arr"]

        values = np.empty(n_vertices + n_edges + n_squares, dtype=np.float64)
        values[:n_vertices] = vertex_values
        if n_edges:
            values[n_vertices:n_vertices + n_edges] = np.maximum(
                vertex_values[edges_arr[:, 0]], vertex_values[edges_arr[:, 1]])
        if n_squares:
            values[n_vertices + n_edges:] = np.max(vertex_values[squares_arr], axis=1)
        times["filter_ms"] += (time.perf_counter() - t0) * 1000

        t0 = time.perf_counter()
        dims = cell_dim
        order = np.lexsort((dims, values))
        rank_of = np.empty_like(order)
        rank_of[order] = np.arange(len(order))
        columns = [None] * len(order)
        for rank, local_id in enumerate(order):
            faces = cell_faces[local_id]
            columns[rank] = sorted(int(rank_of[f]) for f in faces)
        times["boundary_matrix_ms"] += (time.perf_counter() - t0) * 1000

        t0 = time.perf_counter()
        low = _reduce_boundary_matrix(columns)
        times["reduction_ms"] += (time.perf_counter() - t0) * 1000

        # extract pairs (negligible cost, folded into reduction bucket)
        values_sorted = values[order]
        dims_sorted = dims[order] if hasattr(dims, "__getitem__") else np.array(dims)[order]
        pairs0, pairs1 = [], []
        paired_rows = set()
        for j in range(len(columns)):
            r = low[j]
            if r == -1:
                continue
            paired_rows.add(r)
            birth = float(values_sorted[r]); death = float(values_sorted[j])
            bd = int(np.array(dims)[order][r])
            if bd == 0:
                pairs0.append((birth, death))
            elif bd == 1:
                pairs1.append((birth, death))
        for rankk in range(len(columns)):
            if int(np.array(dims)[order][rankk]) == 0 and rankk not in paired_rows:
                pairs0.append((float(values_sorted[rankk]), float("inf")))
        pd0 = PersistenceDiagram(0, np.array(pairs0).reshape(-1, 2) if pairs0 else np.zeros((0, 2)))
        pd1 = PersistenceDiagram(1, np.array(pairs1).reshape(-1, 2) if pairs1 else np.zeros((0, 2)))

        t0 = time.perf_counter()
        img0 = persistence_image(pd0, cfg.birth_range, cfg.pers_range, cfg.resolution)
        img1 = persistence_image(pd1, cfg.birth_range, cfg.pers_range, cfg.resolution)
        vecs.append(img0.reshape(-1)); vecs.append(img1.reshape(-1))
        times["vectorization_ms"] += (time.perf_counter() - t0) * 1000

    t0 = time.perf_counter()
    desc = np.concatenate(vecs)
    norm = np.linalg.norm(desc)
    if norm > 1e-12:
        desc = desc / norm
    times["vectorization_ms"] += (time.perf_counter() - t0) * 1000

    if projection is not None:
        t0 = time.perf_counter()
        _ = projection.transform(desc.reshape(1, -1))
        times["projection_ms"] += (time.perf_counter() - t0) * 1000

    times["total_ms"] = sum(v for k, v in times.items())
    return times


# ---------------------------------------------------------------------
# Real, library-standard CPU detectors (not reimplemented -- third-party)
# ---------------------------------------------------------------------
def detect_fast(image: np.ndarray, max_keypoints: int = 200) -> np.ndarray:
    from skimage.feature import corner_fast, corner_peaks
    response = corner_fast((image * 255).astype(np.uint8), n=9, threshold=0.15)
    coords = corner_peaks(response, min_distance=6, num_peaks=max_keypoints)
    return coords  # (N, 2) (row, col) = (y, x)


def detect_dog_blob(image: np.ndarray, max_keypoints: int = 200) -> np.ndarray:
    from skimage.feature import blob_dog
    blobs = blob_dog(image, min_sigma=1.5, max_sigma=6, threshold=0.02)
    if len(blobs) == 0:
        return np.zeros((0, 2), dtype=np.int64)
    blobs = blobs[np.argsort(-blobs[:, 2])][:max_keypoints]
    return blobs[:, :2].astype(np.int64)


def detect_cv2_sift(image: np.ndarray, max_keypoints: int = 200):
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    sift = cv2.SIFT_create(nfeatures=max_keypoints)
    kps = sift.detect(img8, None)
    coords = np.array([[k.pt[1], k.pt[0]] for k in kps], dtype=np.float64)  # (y, x)
    return coords


def detect_cv2_orb(image: np.ndarray, max_keypoints: int = 200):
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    orb = cv2.ORB_create(nfeatures=max_keypoints)
    kps = orb.detect(img8, None)
    coords = np.array([[k.pt[1], k.pt[0]] for k in kps], dtype=np.float64)
    return coords


def estimate_dominant_orientation(image: np.ndarray, keypoints_yx: np.ndarray, radius: int = 8) -> np.ndarray:
    """
    Real bug found and fixed while running the first real-world (Oxford-
    Affine) evaluation: cv2.KeyPoint objects constructed manually (as in
    cv2_sift_describe/cv2_orb_describe below) default to angle=-1, and
    OpenCV's .compute() (as opposed to .detectAndCompute()) does NOT
    estimate orientation for such keypoints -- verified directly: the
    angle stays exactly -1.0 after compute() for both SIFT and ORB. This
    silently strips SIFT and ORB of their defining rotation-invariance
    property whenever they are evaluated at externally-supplied keypoints
    (our shared-Harris-detector protocol), which went undetected on the
    synthetic/real-image test suites elsewhere in this paper because
    those primarily used small or axis-aligned distortions, but is
    severe on real, significantly-rotated data (e.g. Oxford-Affine's
    'bark' scene, ~35-40 degree rotation) -- see
    Sec.~\\ref{sec:oxford-affine-real} and
    Sec.~\\ref{sec:limitations} for the full account.

    This function computes the standard SIFT-style dominant orientation
    (gradient-magnitude-weighted, Gaussian-windowed circular histogram of
    gradient orientations, peak bin as the estimate) for each keypoint,
    from scratch, so it can be assigned explicitly before calling
    .compute() on any OpenCV descriptor that needs it.

    Returns angles in degrees, OpenCV's convention (cv2.KeyPoint.angle).
    """
    gy, gx = np.gradient(image.astype(np.float64))
    mag = np.sqrt(gx ** 2 + gy ** 2)
    ang = (np.degrees(np.arctan2(gy, gx)) + 360) % 360
    H, W = image.shape
    n_bins = 36
    bin_width = 360.0 / n_bins
    out_angles = np.zeros(len(keypoints_yx))
    yy, xx = np.mgrid[-radius:radius + 1, -radius:radius + 1]
    gauss_weight = np.exp(-(xx ** 2 + yy ** 2) / (2 * (radius / 2) ** 2))
    for i, (y, x) in enumerate(keypoints_yx):
        y, x = int(round(y)), int(round(x))
        y0, y1 = max(0, y - radius), min(H, y + radius + 1)
        x0, x1 = max(0, x - radius), min(W, x + radius + 1)
        if y1 <= y0 or x1 <= x0:
            out_angles[i] = 0.0
            continue
        wy0, wx0 = y0 - (y - radius), x0 - (x - radius)
        patch_mag = mag[y0:y1, x0:x1]
        patch_ang = ang[y0:y1, x0:x1]
        patch_w = gauss_weight[wy0:wy0 + patch_mag.shape[0], wx0:wx0 + patch_mag.shape[1]]
        hist = np.zeros(n_bins)
        bins = np.clip((patch_ang / bin_width).astype(int), 0, n_bins - 1)
        weights = (patch_mag * patch_w).ravel()
        np.add.at(hist, bins.ravel(), weights)
        out_angles[i] = float(np.argmax(hist) * bin_width)
    return out_angles


def _aligned_compute(extractor, image, keypoints_yx, size, dim, dtype, pad=40):
    """Compute OpenCV descriptors at given keypoints, returning one row per
    input keypoint in input order. The image is zero-padded (as PW-Desc and
    RawPatch zero-pad patches) so that OpenCV does not silently drop
    keypoints near the border; rows are re-aligned through class_id. An
    earlier version returned OpenCV's filtered output directly, which
    misaligned ORB descriptors and keypoints whenever ORB dropped border
    keypoints."""
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    img8 = cv2.copyMakeBorder(img8, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=0)
    angles = estimate_dominant_orientation(image, keypoints_yx)
    kps = [cv2.KeyPoint(float(x) + pad, float(y) + pad, size, float(a), 0, 0, i)
           for i, ((y, x), a) in enumerate(zip(keypoints_yx, angles))]
    out_kps, desc = extractor.compute(img8, kps)
    out = np.zeros((len(keypoints_yx), dim), dtype=dtype)
    if desc is not None:
        for k, d in zip(out_kps, desc):
            out[k.class_id] = d
    assert desc is not None and len(out_kps) == len(keypoints_yx), "OpenCV dropped keypoints"
    return out


def cv2_sift_describe(image: np.ndarray, keypoints_yx: np.ndarray):
    import cv2
    desc = _aligned_compute(cv2.SIFT_create(), image, keypoints_yx, 8, 128, np.float64)
    norms = np.linalg.norm(desc, axis=1, keepdims=True)
    norms[norms < 1e-9] = 1.0
    return desc / norms


def cv2_orb_describe(image: np.ndarray, keypoints_yx: np.ndarray):
    import cv2
    # binary descriptor, uint8, Hamming distance for matching
    return _aligned_compute(cv2.ORB_create(), image, keypoints_yx, 31, 32, np.uint8)


def detect_cv2_brisk(image: np.ndarray, max_keypoints: int = 200):
    """Real, measured note: like AKAZE/KAZE below, BRISK's descriptor
    extraction loses the great majority of keypoints when given freshly-
    reconstructed generic cv2.KeyPoint objects instead of the ones its own
    .detect() produced (measured: 1278 keypoints via detectAndCompute
    vs. only 7 surviving via detect()+reconstruct+compute() on an
    identical image) -- so BRISK also uses detectAndCompute() together,
    not separable detect+compute."""
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    brisk = cv2.BRISK_create()
    kps = brisk.detect(img8, None)
    kps = sorted(kps, key=lambda k: -k.response)[:max_keypoints]
    coords = np.array([[k.pt[1], k.pt[0]] for k in kps], dtype=np.float64)
    return coords


def cv2_brisk_detect_and_describe(image: np.ndarray, max_keypoints: int = 200):
    """Combined detect+describe for BRISK (see note in detect_cv2_brisk).
    Returns (keypoints_yx, descriptors)."""
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    brisk = cv2.BRISK_create()
    kps, desc = brisk.detectAndCompute(img8, None)
    if kps is None or len(kps) == 0:
        return np.zeros((0, 2)), np.zeros((0, 64), dtype=np.uint8)
    order = np.argsort([-k.response for k in kps])[:max_keypoints]
    coords = np.array([[kps[i].pt[1], kps[i].pt[0]] for i in order], dtype=np.float64)
    desc_sub = desc[order] if desc is not None else np.zeros((0, 64), dtype=np.uint8)
    return coords, desc_sub


def detect_cv2_akaze(image: np.ndarray, max_keypoints: int = 200):
    """Real, measured note: AKAZE's descriptor extraction depends on
    internal nonlinear-scale-space state populated only by its own
    detection pass; passing freshly-constructed generic cv2.KeyPoint
    objects to .compute() (as the other detectors above tolerate) raises
    an OpenCV assertion error for AKAZE. We therefore always call
    detectAndCompute() together (below) rather than mixing detect+compute
    as a separable pair for this method -- documented here since it is a
    genuine implementation constraint we hit, not a design choice."""
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    akaze = cv2.AKAZE_create()
    kps = akaze.detect(img8, None)
    kps = sorted(kps, key=lambda k: -k.response)[:max_keypoints]
    coords = np.array([[k.pt[1], k.pt[0]] for k in kps], dtype=np.float64)
    return coords


def cv2_akaze_detect_and_describe(image: np.ndarray, max_keypoints: int = 200):
    """Combined detect+describe for AKAZE (see note in detect_cv2_akaze).
    Returns (keypoints_yx, descriptors)."""
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    akaze = cv2.AKAZE_create()
    kps, desc = akaze.detectAndCompute(img8, None)
    if kps is None or len(kps) == 0:
        return np.zeros((0, 2)), np.zeros((0, 61), dtype=np.uint8)
    order = np.argsort([-k.response for k in kps])[:max_keypoints]
    coords = np.array([[kps[i].pt[1], kps[i].pt[0]] for i in order], dtype=np.float64)
    desc_sub = desc[order] if desc is not None else np.zeros((0, 61), dtype=np.uint8)
    return coords, desc_sub


def detect_cv2_kaze(image: np.ndarray, max_keypoints: int = 200):
    """Same detectAndCompute constraint as AKAZE (both share the KAZE
    nonlinear-diffusion scale-space family); see note in
    detect_cv2_akaze."""
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    kaze = cv2.KAZE_create()
    kps = kaze.detect(img8, None)
    kps = sorted(kps, key=lambda k: -k.response)[:max_keypoints]
    coords = np.array([[k.pt[1], k.pt[0]] for k in kps], dtype=np.float64)
    return coords


def cv2_kaze_detect_and_describe(image: np.ndarray, max_keypoints: int = 200):
    """Combined detect+describe for KAZE (see note in detect_cv2_akaze).
    Returns (keypoints_yx, descriptors), real-valued, L2-normalized."""
    import cv2
    img8 = (np.clip(image, 0, 1) * 255).astype(np.uint8)
    kaze = cv2.KAZE_create()
    kps, desc = kaze.detectAndCompute(img8, None)
    if kps is None or len(kps) == 0:
        return np.zeros((0, 2)), np.zeros((0, 64))
    order = np.argsort([-k.response for k in kps])[:max_keypoints]
    coords = np.array([[kps[i].pt[1], kps[i].pt[0]] for i in order], dtype=np.float64)
    desc_sub = desc[order].astype(np.float64) if desc is not None else np.zeros((0, 64))
    norms = np.linalg.norm(desc_sub, axis=1, keepdims=True)
    norms[norms < 1e-9] = 1.0
    return coords, desc_sub / norms
