"""
phdesc.bottleneck
===================

From-scratch bottleneck distance between two persistence diagrams,
implemented via the standard construction: augment each diagram with
"diagonal slots" for the other, then binary-search the smallest threshold
tau for which a perfect matching exists in the bipartite graph where an
edge (i, j) is present iff the L-infinity cost of matching i to j is
<= tau (a diagram point may match another diagram point directly, or to
the diagonal at cost = half its persistence). Feasibility at a fixed tau
is checked via a standard augmenting-path bipartite matching (Kuhn's
algorithm), which is more than fast enough for the small diagrams (tens of
points) produced by the patch sizes used in this paper.

This is NOT a reimplementation of any specific paper's optimized algorithm
(e.g. Kerber-Morozov-Nigmetov's near-linear method) -- it is a simpler,
textbook construction, correct but not asymptotically optimal. Adequate
for the diagram sizes here; documented as such rather than oversold.
"""
from __future__ import annotations
import numpy as np
from typing import List, Tuple


def _diag_dist(pt: np.ndarray) -> float:
    """L-infinity distance from a (birth, death) point to the diagonal."""
    b, d = pt[0], pt[1]
    return abs(d - b) / 2.0


def _kuhn_max_matching(adj: List[List[int]], n_left: int, n_right: int) -> int:
    """Standard augmenting-path bipartite maximum matching (Kuhn's algorithm),
    implemented iteratively (explicit stack) to avoid Python recursion-depth
    limits on the larger diagrams that arise from real image patches."""
    match_right = [-1] * n_right

    def try_kuhn_iterative(start):
        # DFS with explicit stack; visited is per-call (per augmenting attempt)
        visited = [False] * n_right
        stack = [(start, 0)]
        parent_of = {}  # nxt_left_node -> (prev_left_node, right_node_used)
        while stack:
            u, idx = stack[-1]
            if idx >= len(adj[u]):
                stack.pop()
                continue
            v = adj[u][idx]
            stack[-1] = (u, idx + 1)
            if visited[v]:
                continue
            visited[v] = True
            if match_right[v] == -1:
                # found an augmenting path ending at v; flip matches back to start
                match_right[v] = u
                cur = u
                while cur in parent_of:
                    pu, pv = parent_of[cur]
                    match_right[pv] = pu
                    cur = pu
                return True
            else:
                nxt = match_right[v]
                parent_of[nxt] = (u, v)
                stack.append((nxt, 0))
        return False

    result = 0
    for u in range(n_left):
        if try_kuhn_iterative(u):
            result += 1
    return result


def _significant_points(D: np.ndarray, min_persistence: float = 1e-3, max_points: int = 30) -> np.ndarray:
    """Filter a diagram to points with persistence above a small threshold
    (removing near-zero-persistence numerical/filtration artifacts, which
    carry negligible topological information but dominate raw point
    counts) and cap at max_points by persistence, for tractability of the
    exact bipartite-matching bottleneck computation. This is a standard,
    documented practice (not silently applied): both the threshold and cap
    are reported wherever this function is used.
    """
    D = np.asarray(D, dtype=np.float64).reshape(-1, 2)
    if len(D) == 0:
        return D
    pers = D[:, 1] - D[:, 0]
    D = D[pers > min_persistence]
    if len(D) > max_points:
        pers = D[:, 1] - D[:, 0]
        order = np.argsort(-pers)[:max_points]
        D = D[order]
    return D


def bottleneck_distance(D1: np.ndarray, D2: np.ndarray) -> float:
    """
    Exact (up to the candidate-value discretization, which is exact here
    since we enumerate all relevant candidate values) bottleneck distance
    between two finite persistence diagrams (arrays of shape (n, 2), each
    row a (birth, death) pair; only finite points -- filter out infinite
    pairs before calling).

    Returns 0.0 if both diagrams are empty.
    """
    D1 = np.asarray(D1, dtype=np.float64).reshape(-1, 2)
    D2 = np.asarray(D2, dtype=np.float64).reshape(-1, 2)
    n1, n2 = len(D1), len(D2)

    if n1 == 0 and n2 == 0:
        return 0.0
    if n1 == 0:
        return float(np.max([_diag_dist(p) for p in D2])) if n2 else 0.0
    if n2 == 0:
        return float(np.max([_diag_dist(p) for p in D1])) if n1 else 0.0

    # cost matrix between real points (L-infinity / Chebyshev distance)
    cost_real = np.max(np.abs(D1[:, None, :] - D2[None, :, :]), axis=2)  # (n1, n2)
    diag1 = np.array([_diag_dist(p) for p in D1])  # cost of D1[i] -> diagonal
    diag2 = np.array([_diag_dist(p) for p in D2])  # cost of D2[j] -> diagonal

    # candidate distances: all entries that could be the bottleneck value
    candidates = np.concatenate([cost_real.reshape(-1), diag1, diag2])
    candidates = np.unique(candidates)
    candidates.sort()

    # augmented bipartite sizes: n1 real D1 points + n2 diagonal-slots (for D2 points)
    # vs n2 real D2 points + n1 diagonal-slots (for D1 points)
    N = n1 + n2  # size of each side after augmentation

    def feasible(tau: float) -> bool:
        adj = [[] for _ in range(N)]
        # left 0..n1-1 = D1 real points; left n1..n1+n2-1 = diagonal slots (one per D2 point)
        # right 0..n2-1 = D2 real points; right n2..n2+n1-1 = diagonal slots (one per D1 point)
        for i in range(n1):
            for j in range(n2):
                if cost_real[i, j] <= tau:
                    adj[i].append(j)
            if diag1[i] <= tau:
                # D1 point i can match any diagonal slot on the right (n2 .. n2+n1-1);
                # matching to its OWN slot suffices since diagonal slots are interchangeable
                adj[i].append(n2 + i)
        for k in range(n2):
            # diagonal slot k (left side, index n1+k) can match D2 point k at cost diag2[k],
            # or any diagonal slot on the right (cost 0)
            left_idx = n1 + k
            if diag2[k] <= tau:
                adj[left_idx].append(k)
            adj[left_idx].append(n2 + 0 if n1 > 0 else k)  # placeholder; replaced below
        # diagonal-to-diagonal edges (cost 0, always feasible): connect every left
        # diagonal slot to every right diagonal slot
        for k in range(n2):
            left_idx = n1 + k
            adj[left_idx] = [e for e in adj[left_idx] if e != (n2 + 0 if n1 > 0 else k)]
            for m in range(n1):
                adj[left_idx].append(n2 + m)
        matching = _kuhn_max_matching(adj, N, N)
        return matching == N

    lo, hi = 0, len(candidates) - 1
    if not feasible(candidates[hi]):
        # should not happen (max candidate always feasible), but guard anyway
        return float(candidates[hi])
    while lo < hi:
        mid = (lo + hi) // 2
        if feasible(candidates[mid]):
            hi = mid
        else:
            lo = mid + 1
    return float(candidates[lo])
