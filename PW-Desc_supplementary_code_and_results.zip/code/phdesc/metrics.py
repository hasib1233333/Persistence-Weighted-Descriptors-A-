"""
phdesc.metrics
==============

Standard evaluation metrics for local feature matching, following the
protocols used across the HPatches / MegaDepth / ScanNet / Oxford-Affine
image-matching literature (e.g. Balntas et al. 2017 "HPatches"; Sarlin et
al. 2020 "SuperGlue"; Sun et al. 2021 "LoFTR"). These are NOT contributions
of this work -- reproduced here as plain, dependency-light implementations
so the full evaluation pipeline runs end-to-end without external
benchmark-suite installation.
"""

from __future__ import annotations
import numpy as np
from typing import Tuple


def mean_matching_accuracy(pts_a: np.ndarray, pts_b: np.ndarray,
                            H_gt: np.ndarray, thresholds=(1, 2, 3, 5, 10)) -> dict:
    """
    Mean Matching Accuracy (MMA): fraction of putative matches whose
    reprojection error under the GROUND-TRUTH homography is below a pixel
    threshold, evaluated at several thresholds (standard HPatches protocol).

    pts_a, pts_b : (M, 2) matched keypoint coordinates (x, y) in image A / B.
    H_gt         : (3, 3) ground-truth homography mapping A -> B.
    """
    if len(pts_a) == 0:
        return {t: 0.0 for t in thresholds}
    ones = np.ones((len(pts_a), 1))
    homog = np.concatenate([pts_a, ones], axis=1) @ H_gt.T
    homog = homog[:, :2] / (homog[:, 2:3] + 1e-12)
    err = np.linalg.norm(homog - pts_b, axis=1)
    return {t: float(np.mean(err <= t)) for t in thresholds}


def repeatability(kp_a: np.ndarray, kp_b: np.ndarray, H_gt: np.ndarray,
                   image_shape: Tuple[int, int], pixel_thresh: float = 3.0) -> float:
    """
    Fraction of keypoints in image A that have a corresponding detected
    keypoint in image B within `pixel_thresh` pixels after warping by the
    ground-truth homography (and vice versa), averaged -- the standard
    repeatability criterion (Mikolajczyk & Schmid, 2005 protocol family).

    kp_a, kp_b : (N, 2) arrays of (y, x) keypoint coordinates.
    """
    H, W = image_shape
    if len(kp_a) == 0 or len(kp_b) == 0:
        return 0.0
    pts_a_xy = kp_a[:, ::-1].astype(np.float64)
    ones = np.ones((len(pts_a_xy), 1))
    warped = np.concatenate([pts_a_xy, ones], axis=1) @ H_gt.T
    warped = warped[:, :2] / (warped[:, 2:3] + 1e-12)
    inside = (warped[:, 0] >= 0) & (warped[:, 0] < W) & (warped[:, 1] >= 0) & (warped[:, 1] < H)
    warped = warped[inside]
    if len(warped) == 0:
        return 0.0
    pts_b_xy = kp_b[:, ::-1].astype(np.float64)
    d = np.linalg.norm(warped[:, None, :] - pts_b_xy[None, :, :], axis=2)
    matched = np.any(d <= pixel_thresh, axis=1)
    return float(np.mean(matched))


def relative_pose_error(R_est, t_est, R_gt, t_gt):
    """
    Standard MegaDepth/ScanNet relative-pose error (as used by SuperGlue,
    LoFTR, and this paper's protocol): rotation error is the angular
    distance between R_est and R_gt (degrees); translation error is the
    angular distance between the *directions* of t_est and t_gt (degrees,
    since monocular relative pose only recovers translation up to an
    unknown scale, so only its direction is comparable to ground truth).
    Returns (rot_error_deg, trans_error_deg).
    """
    # rotation error via the trace of R_est^T @ R_gt
    cos_theta = (np.trace(R_est.T @ R_gt) - 1) / 2
    cos_theta = np.clip(cos_theta, -1.0, 1.0)
    rot_error = np.degrees(np.arccos(cos_theta))

    # translation direction error (t is only defined up to scale and sign)
    t_est_n = t_est.ravel() / (np.linalg.norm(t_est) + 1e-12)
    t_gt_n = t_gt.ravel() / (np.linalg.norm(t_gt) + 1e-12)
    cos_t = np.clip(np.abs(np.dot(t_est_n, t_gt_n)), -1.0, 1.0)
    trans_error = np.degrees(np.arccos(cos_t))
    return float(rot_error), float(trans_error)


def pose_auc(errors, thresholds=(5, 10, 20)) -> dict:
    """
    Standard pose-estimation AUC (area under the cumulative-error curve,
    normalized), exactly as used by SuperGlue/LoFTR for MegaDepth/ScanNet
    reporting. `errors` is the pose error per pair (max of rotation and
    translation error in degrees, or inf/nan for a failed estimate, which
    counts as maximally wrong). Returns {threshold: auc} for each
    threshold in `thresholds`.
    """
    errors = np.array(errors, dtype=np.float64)
    errors = np.nan_to_num(errors, nan=180.0, posinf=180.0)
    errors = np.sort(errors)
    n = len(errors)
    if n == 0:
        return {t: 0.0 for t in thresholds}
    recall = np.arange(1, n + 1) / n
    out = {}
    for t in thresholds:
        idx = np.searchsorted(errors, t, side="right")
        if idx == 0:
            out[t] = 0.0
            continue
        e = np.concatenate([[0.0], errors[:idx], [float(t)]])
        r = np.concatenate([[0.0], recall[:idx], [recall[idx - 1] if idx > 0 else 0.0]])
        out[t] = float(np.trapezoid(r, e) / t)
    return out


def homography_estimation_auc(errors_per_pair, thresholds=(3, 5, 10)) -> dict:
    """
    Area-under-curve of the cumulative distribution of homography corner-
    reprojection errors, the standard aggregate metric used by SuperGlue /
    LoFTR-style benchmarks.

    errors_per_pair: list of scalar corner errors (one per image pair; use
        e.g. max corner displacement between estimated vs GT homography
        applied to the 4 image corners).
    """
    errors = np.sort(np.array(errors_per_pair, dtype=np.float64))
    n = len(errors)
    out = {}
    for t in thresholds:
        if n == 0:
            out[t] = 0.0
            continue
        recall = np.searchsorted(errors, t) / n
        # trapezoidal AUC of the recall curve from 0 to t, normalized by t
        xs = np.concatenate([[0], errors[errors <= t], [t]])
        ys = np.concatenate([[0], np.arange(1, np.sum(errors <= t) + 1) / n,
                              [np.searchsorted(errors, t) / n]])
        auc = np.trapezoid(ys, xs) / t if t > 0 else 0.0
        out[t] = float(auc)
    return out
