import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np
from phdesc.bottleneck import bottleneck_distance


def test_identical_diagrams_zero_distance():
    D = np.array([[0.1, 0.5], [0.2, 0.9], [0.0, 0.3]])
    d = bottleneck_distance(D, D)
    assert abs(d) < 1e-9, f"expected 0, got {d}"
    print("test_identical_diagrams_zero_distance: PASSED")


def test_empty_vs_empty():
    D = np.zeros((0, 2))
    d = bottleneck_distance(D, D)
    assert d == 0.0
    print("test_empty_vs_empty: PASSED")


def test_empty_vs_single_point():
    D1 = np.zeros((0, 2))
    D2 = np.array([[0.2, 0.8]])
    d = bottleneck_distance(D1, D2)
    expected = (0.8 - 0.2) / 2.0
    assert abs(d - expected) < 1e-9, f"expected {expected}, got {d}"
    print(f"test_empty_vs_single_point: PASSED (d={d}, expected={expected})")


def test_uniform_shift_matches_shift_magnitude():
    """Shifting every point by (delta, delta) in a diagram far from the
    diagonal should give bottleneck distance exactly delta (direct
    matching is cheaper than routing through the diagonal, since points
    are far from the diagonal relative to delta)."""
    rng = np.random.default_rng(0)
    n = 5
    births = rng.uniform(0.0, 0.3, size=n)
    deaths = births + rng.uniform(0.4, 0.6, size=n)  # persistence 0.4-0.6, far from diagonal
    D1 = np.stack([births, deaths], axis=1)
    delta = 0.05
    D2 = D1 + delta  # shift both birth and death by delta
    d = bottleneck_distance(D1, D2)
    assert abs(d - delta) < 1e-9, f"expected {delta}, got {d}"
    print(f"test_uniform_shift_matches_shift_magnitude: PASSED (d={d}, expected={delta})")


def test_two_single_points_direct_vs_diagonal():
    """Two single-point diagrams: bottleneck distance should be the
    minimum of (a) matching them directly (L-inf distance) or (b) routing
    each through the diagonal (sum... no, max, of their diagonal
    distances, since matching happens independently: D1's point can go to
    a diagonal slot, D2's point can go to a diagonal slot, both at their
    own diagonal-distance cost, and the bottleneck is the MAX of the two
    edges used, not the sum)."""
    p1 = np.array([[0.0, 0.1]])   # tiny persistence, close to diagonal (diag dist 0.05)
    p2 = np.array([[0.9, 0.95]])  # far away point, tiny persistence too (diag dist 0.025)
    direct = max(abs(0.0 - 0.9), abs(0.1 - 0.95))
    via_diagonal = max(0.05, 0.025)
    expected = min(direct, via_diagonal)
    d = bottleneck_distance(p1, p2)
    assert abs(d - expected) < 1e-9, f"expected {expected}, got {d}"
    print(f"test_two_single_points_direct_vs_diagonal: PASSED (d={d}, expected={expected})")


if __name__ == "__main__":
    test_identical_diagrams_zero_distance()
    test_empty_vs_empty()
    test_empty_vs_single_point()
    test_uniform_shift_matches_shift_magnitude()
    test_two_single_points_direct_vs_diagonal()
    print("\nALL BOTTLENECK DISTANCE TESTS PASSED")
