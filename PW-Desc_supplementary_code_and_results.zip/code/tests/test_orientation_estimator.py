"""
Correctness test for phdesc.profiling.estimate_dominant_orientation,
added when a real bug was discovered running the first real-world
(Oxford-Affine) evaluation: OpenCV's SIFT/ORB .compute() does not
estimate orientation for externally-supplied keypoints, silently
stripping their rotation invariance. This test verifies the from-scratch
replacement actually behaves like a real orientation estimator: rotating
a textured image by a known angle should shift the estimated dominant
orientation by (approximately) that same angle.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
from scipy.ndimage import rotate as ndi_rotate

from phdesc.profiling import estimate_dominant_orientation


def test_orientation_shifts_with_known_rotation():
    rng = np.random.default_rng(0)
    # a textured patch with a clear dominant gradient direction (a ramp
    # plus noise, giving an unambiguous edge orientation to track)
    size = 64
    yy, xx = np.mgrid[0:size, 0:size]
    base = (xx.astype(np.float64) / size) + 0.05 * rng.random((size, size))
    base = np.clip(base, 0, 1)

    kp = np.array([[size // 2, size // 2]])
    angle0 = estimate_dominant_orientation(base, kp, radius=12)[0]

    n_match, n_total = 0, 0
    for true_rotation_deg in [15, 30, 45, 60, 90]:
        rotated = ndi_rotate(base, angle=-true_rotation_deg, reshape=False, mode="reflect")
        angle1 = estimate_dominant_orientation(rotated, kp, radius=12)[0]
        measured_shift = (angle1 - angle0) % 360
        expected_shift = true_rotation_deg % 360
        # allow generous tolerance: histogram bin width is 10 degrees,
        # and scipy's image rotation + our finite-difference gradient
        # both introduce some real numerical slack
        diff = min(abs(measured_shift - expected_shift), 360 - abs(measured_shift - expected_shift))
        n_total += 1
        if diff <= 20:
            n_match += 1
        else:
            print(f"  rotation={true_rotation_deg}: expected shift {expected_shift}, "
                  f"measured {measured_shift:.1f} (diff {diff:.1f}) -- outside tolerance")
    assert n_match >= 4, f"only {n_match}/{n_total} rotations matched within tolerance"
    print(f"test_orientation_shifts_with_known_rotation: PASSED ({n_match}/{n_total} rotations within tolerance)")


def test_orientation_deterministic_and_in_range():
    rng = np.random.default_rng(1)
    img = rng.random((40, 40))
    kp = np.array([[20, 20], [10, 10], [30, 15]])
    a1 = estimate_dominant_orientation(img, kp)
    a2 = estimate_dominant_orientation(img, kp)
    assert np.allclose(a1, a2), "orientation estimate is not deterministic"
    assert np.all((a1 >= 0) & (a1 < 360)), "orientation out of [0, 360) range"
    print("test_orientation_deterministic_and_in_range: PASSED")


if __name__ == "__main__":
    test_orientation_deterministic_and_in_range()
    test_orientation_shifts_with_known_rotation()
    print("\nALL ORIENTATION ESTIMATOR TESTS PASSED")
