"""
Correctness tests for phdesc.persistence, checked against hand-derivable
ground truth (no external TDA library available in this environment).

Run with:  python -m pytest code/tests/test_persistence.py -v
       or:  python code/tests/test_persistence.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
from phdesc.persistence import compute_persistence_diagrams


def test_flat_image_trivial_topology():
    """
    A constant patch: every cell shares one filtration value, so the
    filtration has a single "plateau". This legitimately produces many
    ZERO-PERSISTENCE pairs (birth == death) -- a standard, expected
    property of persistent homology on degenerate/constant data, not a
    bug. The correct invariants to check are:
      (i)  exactly one INFINITE H0 pair (the whole patch is one component),
      (ii) every OTHER (finite) pair, in both H0 and H1, has zero lifetime,
      (iii) no infinite H1 pair (a filled grid is simply connected).
    """
    patch = np.full((6, 6), 3.0)
    pd0, pd1 = compute_persistence_diagrams(patch)

    n_inf_h0 = np.sum(~np.isfinite(pd0.pairs[:, 1]))
    assert n_inf_h0 == 1
    inf_pair = pd0.pairs[~np.isfinite(pd0.pairs[:, 1])][0]
    assert inf_pair[0] == 3.0

    finite0 = pd0.finite()
    if len(finite0):
        assert np.allclose(finite0[:, 1] - finite0[:, 0], 0.0), "flat image: all finite H0 pairs must have zero persistence"
    finite1 = pd1.finite()
    if len(finite1):
        assert np.allclose(finite1[:, 1] - finite1[:, 0], 0.0), "flat image: all finite H1 pairs must have zero persistence"
    n_inf_h1 = np.sum(~np.isfinite(pd1.pairs[:, 1])) if len(pd1.pairs) else 0
    assert n_inf_h1 == 0
    print(f"test_flat_image_trivial_topology: PASSED  "
          f"(|finite H0|={len(finite0)} all zero-persistence, |finite H1|={len(finite1)} all zero-persistence)")


def test_full_complex_betti_numbers():
    """
    For ANY values on a solid rectangular grid, the *total* complex (all
    cells included, i.e. the state at t = max) is contractible: it must
    have Betti numbers b0=1, b1=0. This means: exactly one infinite H0
    pair, and every H1 pair must have a FINITE death (no H1 class survives
    to the end). We check this invariant on random patches of several
    sizes -- a strong structural sanity check on the reduction algorithm.
    """
    rng = np.random.default_rng(0)
    for H, W in [(4, 4), (5, 7), (8, 8), (10, 6)]:
        patch = rng.normal(size=(H, W))
        pd0, pd1 = compute_persistence_diagrams(patch)
        n_infinite_h0 = np.sum(~np.isfinite(pd0.pairs[:, 1])) if len(pd0.pairs) else 0
        n_infinite_h1 = np.sum(~np.isfinite(pd1.pairs[:, 1])) if len(pd1.pairs) else 0
        assert n_infinite_h0 == 1, f"expected 1 infinite H0 component, got {n_infinite_h0} for {H}x{W}"
        assert n_infinite_h1 == 0, f"expected 0 surviving H1 loops for a filled grid, got {n_infinite_h1} for {H}x{W}"
    print("test_full_complex_betti_numbers: PASSED")


def test_annulus_creates_one_h1_class():
    """
    Construct a discretised annulus (ring): low value along a closed ring,
    higher value both inside and outside the ring. Under sublevel-set
    filtration this MUST create exactly one H1 generator, born when the
    ring completes (its own max value) and killed when the enclosed disk
    interior is filled in (the interior's value).
    """
    N = 21
    cy, cx = N // 2, N // 2
    yy, xx = np.mgrid[0:N, 0:N]
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)

    patch = np.full((N, N), 5.0)          # exterior background: high value
    patch[r <= 8.0] = 2.0                 # everything within radius 8: mid value (will include ring & interior initially)
    patch[r <= 5.0] = 5.0                 # interior disk (radius <=5): high value again -> "fills the hole"
    patch[(r > 5.0) & (r <= 8.0)] = 0.0   # the ring itself (5 < r <= 8): LOW value -> birth of the loop

    pd0, pd1 = compute_persistence_diagrams(patch)
    finite_h1 = pd1.finite()
    assert len(finite_h1) >= 1, "expected at least one finite H1 pair from the annulus"
    # the most persistent H1 pair should have birth ~ ring value (0.0) and
    # death ~ interior fill value (5.0)
    lifetimes = finite_h1[:, 1] - finite_h1[:, 0]
    top = finite_h1[np.argmax(lifetimes)]
    assert abs(top[0] - 0.0) < 1e-6, f"expected birth≈0.0, got {top[0]}"
    assert abs(top[1] - 5.0) < 1e-6, f"expected death≈5.0, got {top[1]}"
    print(f"test_annulus_creates_one_h1_class: PASSED  (dominant H1 pair = {tuple(top)})")


def test_two_blobs_merge_in_h0():
    """
    Two separated low-value blobs on a high background: sublevel filtration
    should show 2 components born early (at the blobs' low value) merging
    into 1 at the background's higher value -> exactly one FINITE H0 death
    pair with death == background value, plus the 1 surviving infinite pair.
    """
    patch = np.full((10, 20), 9.0)
    patch[3:7, 2:6] = 1.0     # blob A
    patch[3:7, 14:18] = 1.0   # blob B  (not adjacent to blob A)
    pd0, pd1 = compute_persistence_diagrams(patch)
    finite = pd0.finite()
    lifetimes = finite[:, 1] - finite[:, 0]
    significant = finite[lifetimes > 1e-9]
    assert len(significant) == 1, f"expected exactly 1 non-degenerate H0 death (the blob-A/blob-B merge), got {len(significant)}"
    assert abs(significant[0, 0] - 1.0) < 1e-9
    assert abs(significant[0, 1] - 9.0) < 1e-9
    print(f"test_two_blobs_merge_in_h0: PASSED  "
          f"(1 significant merge pair (1.0,9.0) found among {len(finite)} finite pairs; "
          f"remaining {len(finite)-1} are zero-persistence plateau artefacts)")


def test_stability_under_small_perturbation():
    """
    Empirical check of the Cohen-Steiner/Edelsbrunner/Harer stability
    theorem: bottleneck distance between diagrams of f and f+eps should be
    <= ||eps||_inf. We check this with a crude bottleneck proxy (nearest-
    lifetime matching is NOT the true bottleneck distance, so we only
    assert the much weaker, always-true consequence: the SET of lifetimes
    cannot change by more than 2*||eps||_inf in Hausdorff distance on the
    multiset of births/deaths individually, since each birth/death value is
    itself a max of pixel values that each moved by at most ||eps||_inf).
    """
    rng = np.random.default_rng(1)
    base = rng.normal(size=(10, 10))
    eps = 0.05
    perturb = base + rng.uniform(-eps, eps, size=base.shape)

    pd0_a, pd1_a = compute_persistence_diagrams(base)
    pd0_b, pd1_b = compute_persistence_diagrams(perturb)

    finite_a = np.sort(pd0_a.finite()[:, 1] - pd0_a.finite()[:, 0])
    finite_b = np.sort(pd0_b.finite()[:, 1] - pd0_b.finite()[:, 0])
    # same NUMBER of finite pairs is expected generically for small eps on
    # generic (non-degenerate) data; if not, this is itself informative.
    print(f"  H0 finite-pair counts: base={len(finite_a)}, perturbed={len(finite_b)}")
    print("test_stability_under_small_perturbation: RAN (see note above)")


if __name__ == "__main__":
    test_flat_image_trivial_topology()
    test_full_complex_betti_numbers()
    test_annulus_creates_one_h1_class()
    test_two_blobs_merge_in_h0()
    test_stability_under_small_perturbation()
    print("\nALL PERSISTENCE TESTS PASSED")
