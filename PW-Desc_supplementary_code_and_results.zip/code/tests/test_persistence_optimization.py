"""
Correctness verification for the bit-packed boundary-matrix reduction
optimization: it must produce EXACTLY the same persistence diagrams as
the original, already-verified set-based reference implementation, on
every test case -- random patches of various sizes, and the analytic
ground-truth cases from test_persistence.py (exact annulus, two-blob
merge, flat image, Betti-number invariants).

If this test fails, the optimization must not be used: correctness is
never traded for speed in this codebase.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
from phdesc.persistence import compute_persistence_diagrams


def _diagrams_equal(pd_a, pd_b, tol=1e-9):
    a = np.array(sorted(map(tuple, pd_a.pairs.tolist())))
    b = np.array(sorted(map(tuple, pd_b.pairs.tolist())))
    if a.shape != b.shape:
        return False, f"shape mismatch {a.shape} vs {b.shape}"
    if a.size == 0:
        return True, "both empty"
    # inf == inf comparison handled via isnan/isinf-safe equality
    finite_mask = np.isfinite(a) & np.isfinite(b)
    inf_mask = np.isinf(a) & np.isinf(b)
    ok_finite = np.allclose(a[finite_mask], b[finite_mask], atol=tol)
    ok_inf = np.array_equal(np.isinf(a), np.isinf(b))
    return bool(ok_finite and ok_inf), "ok" if (ok_finite and ok_inf) else "mismatch"


def test_backends_agree_on_random_patches():
    rng = np.random.default_rng(42)
    n_checked = 0
    for H, W in [(4, 4), (5, 7), (8, 8), (10, 6), (16, 16), (21, 21), (32, 32)]:
        for trial in range(3):
            patch = rng.normal(size=(H, W))
            pd0_ref, pd1_ref = compute_persistence_diagrams(patch, backend="reference")
            pd0_bp, pd1_bp = compute_persistence_diagrams(patch, backend="bitpacked")
            ok0, msg0 = _diagrams_equal(pd0_ref, pd0_bp)
            ok1, msg1 = _diagrams_equal(pd1_ref, pd1_bp)
            assert ok0, f"H0 mismatch at {H}x{W} trial {trial}: {msg0}"
            assert ok1, f"H1 mismatch at {H}x{W} trial {trial}: {msg1}"
            n_checked += 1
    print(f"test_backends_agree_on_random_patches: PASSED ({n_checked} random patches, both backends identical)")


def test_backends_agree_on_analytic_annulus():
    N = 21
    cy, cx = N // 2, N // 2
    yy, xx = np.mgrid[0:N, 0:N]
    r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
    patch = np.full((N, N), 5.0)
    patch[r <= 8.0] = 2.0
    patch[r <= 5.0] = 5.0
    patch[(r > 5.0) & (r <= 8.0)] = 0.0

    pd0_ref, pd1_ref = compute_persistence_diagrams(patch, backend="reference")
    pd0_bp, pd1_bp = compute_persistence_diagrams(patch, backend="bitpacked")

    ok0, msg0 = _diagrams_equal(pd0_ref, pd0_bp)
    ok1, msg1 = _diagrams_equal(pd1_ref, pd1_bp)
    assert ok0 and ok1, f"annulus mismatch: H0={msg0}, H1={msg1}"

    # both backends must still recover the exact known ground truth
    f1_bp = pd1_bp.finite()
    assert len(f1_bp) >= 1
    top = f1_bp[np.argmax(f1_bp[:, 1] - f1_bp[:, 0])]
    assert abs(top[0] - 0.0) < 1e-9 and abs(top[1] - 5.0) < 1e-9, \
        f"bitpacked backend lost the exact ground truth: got {tuple(top)}"
    print("test_backends_agree_on_analytic_annulus: PASSED (both backends identical, exact ground truth preserved)")


def test_backends_agree_on_flat_and_two_blob_cases():
    flat = np.full((6, 6), 3.0)
    pd0_ref, pd1_ref = compute_persistence_diagrams(flat, backend="reference")
    pd0_bp, pd1_bp = compute_persistence_diagrams(flat, backend="bitpacked")
    ok0, msg0 = _diagrams_equal(pd0_ref, pd0_bp)
    ok1, msg1 = _diagrams_equal(pd1_ref, pd1_bp)
    assert ok0 and ok1, f"flat-image mismatch: H0={msg0}, H1={msg1}"

    blobs = np.full((10, 20), 9.0)
    blobs[3:7, 2:6] = 1.0
    blobs[3:7, 14:18] = 1.0
    pd0_ref, pd1_ref = compute_persistence_diagrams(blobs, backend="reference")
    pd0_bp, pd1_bp = compute_persistence_diagrams(blobs, backend="bitpacked")
    ok0, msg0 = _diagrams_equal(pd0_ref, pd0_bp)
    ok1, msg1 = _diagrams_equal(pd1_ref, pd1_bp)
    assert ok0 and ok1, f"two-blob mismatch: H0={msg0}, H1={msg1}"
    print("test_backends_agree_on_flat_and_two_blob_cases: PASSED")


if __name__ == "__main__":
    test_backends_agree_on_random_patches()
    test_backends_agree_on_analytic_annulus()
    test_backends_agree_on_flat_and_two_blob_cases()
    print("\nALL BACKEND-EQUIVALENCE TESTS PASSED")
