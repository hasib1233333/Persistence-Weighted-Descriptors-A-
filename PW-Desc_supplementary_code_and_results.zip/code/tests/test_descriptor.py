"""
Correctness test for Proposition 4 (exact invariance under rank
normalization) in the manuscript. This is not a statistical/approximate
check: the claim is exact equality, verified to floating-point precision.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
from phdesc.descriptor import rank_normalize_patch, compute_pw_descriptor, DescriptorConfig


def test_rank_normalization_exact_invariance_to_monotonic_transforms():
    rng = np.random.default_rng(0)
    patch = rng.random((20, 20))
    gammas = [0.2, 0.6, 1.0, 1.8, 3.0, 5.0]

    r_base = rank_normalize_patch(patch)
    max_diffs = []
    for gamma in gammas:
        distorted = np.clip(patch, 1e-9, 1.0) ** gamma  # strictly monotonic increasing for v>0
        r_distorted = rank_normalize_patch(distorted)
        diff = np.max(np.abs(r_base - r_distorted))
        max_diffs.append(diff)
        assert diff == 0.0, f"gamma={gamma}: expected exact equality, got max abs diff {diff}"

    print(f"test_rank_normalization_exact_invariance_to_monotonic_transforms: PASSED "
          f"(max abs diff = 0.0 for all gamma in {gammas})")


def test_rank_normalized_descriptor_exact_invariance():
    """End-to-end: the FULL descriptor (persistence diagrams + persistence
    images), not just the intermediate rank-normalized patch, is identical
    under gamma distortion when rank_normalize=True."""
    rng = np.random.default_rng(1)
    img = rng.random((48, 48))
    cfg = DescriptorConfig(scales=(16, 24), resolution=6, rank_normalize=True)

    y, x = 24, 24
    d_base = compute_pw_descriptor(img, y, x, cfg)
    for gamma in [0.5, 2.0, 4.0]:
        distorted = np.clip(img, 1e-9, 1.0) ** gamma
        d_distorted = compute_pw_descriptor(distorted, y, x, cfg)
        diff = np.max(np.abs(d_base - d_distorted))
        assert diff < 1e-10, f"gamma={gamma}: descriptor changed under monotonic transform, diff={diff}"

    print("test_rank_normalized_descriptor_exact_invariance: PASSED "
          "(full descriptor identical to <1e-10 under gamma in {0.5, 2.0, 4.0})")


def test_plain_pwdesc_is_NOT_invariant_control():
    """Sanity control: without rank normalization, the descriptor SHOULD
    change under gamma (this is the Table 3 finding) -- confirms the two
    tests above are actually testing the rank-normalization mechanism and
    not some accidental invariance of the whole pipeline."""
    rng = np.random.default_rng(2)
    img = rng.random((48, 48))
    cfg = DescriptorConfig(scales=(16, 24), resolution=6, rank_normalize=False)

    y, x = 24, 24
    d_base = compute_pw_descriptor(img, y, x, cfg)
    distorted = np.clip(img, 1e-9, 1.0) ** 2.5
    d_distorted = compute_pw_descriptor(distorted, y, x, cfg)
    diff = np.max(np.abs(d_base - d_distorted))
    assert diff > 1e-6, "expected plain PW-Desc to CHANGE under gamma distortion (control check)"
    print(f"test_plain_pwdesc_is_NOT_invariant_control: PASSED (diff={diff:.4f}, confirms non-invariance as expected)")


if __name__ == "__main__":
    test_rank_normalization_exact_invariance_to_monotonic_transforms()
    test_rank_normalized_descriptor_exact_invariance()
    test_plain_pwdesc_is_NOT_invariant_control()
    print("\nALL DESCRIPTOR INVARIANCE TESTS PASSED")
