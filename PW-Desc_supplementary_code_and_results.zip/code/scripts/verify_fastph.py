"""verify_fastph.py -- compares the off-diagonal diagrams of phdesc.fastph with GUDHI's
cubical complex (vertices=...) on random and real patches, and times both.
Usage: python verify_fastph.py /path/to/oxford out.json"""
import sys, os, json, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
import numpy as np, gudhi
from phdesc.fastph import diagrams
from phdesc import harris_keypoints
from phdesc.descriptor import extract_patch
from mc_measurement import load_resized

def g_diag(P):
    cc = gudhi.CubicalComplex(vertices=P); cc.compute_persistence(homology_coeff_field=2, min_persistence=-1)
    out = []
    for k in (0, 1):
        d = np.array(cc.persistence_intervals_in_dimension(k)).reshape(-1, 2)
        d = d[np.isfinite(d[:, 1])]; d = d[d[:, 1] > d[:, 0]]
        out.append(np.array(sorted(map(tuple, d))))
    return out

def same(a, b):
    a = np.array(sorted(map(tuple, a))).reshape(-1, 2); b = np.array(sorted(map(tuple, b))).reshape(-1, 2)
    return a.shape == b.shape and np.allclose(a, b, atol=0)

rng = np.random.default_rng(0); patches = []
for s in (4, 8, 16, 24, 32, 48):
    for _ in range(300):
        P = rng.random((s, s))
        if rng.random() < 0.5: P = np.round(P * rng.integers(2, 12)) / 12       # many ties
        patches.append(P)
for sc in sorted(os.listdir(sys.argv[1])):
    im = load_resized(os.path.join(sys.argv[1], sc, "img1.png"))
    for (y, x) in harris_keypoints(im, max_keypoints=100, min_distance=8):
        for s in (16, 24, 32): patches.append(extract_patch(im, y, x, s))
diagrams(patches[0])  # compile
bad = 0
for P in patches:
    f0, f1 = diagrams(P); g0, g1 = g_diag(P)
    bad += int(not (same(f0, g0) and same(f1, g1)))
real = patches[-2400:]
t = time.perf_counter(); [diagrams(P) for P in real]; tf = (time.perf_counter() - t) / len(real) * 3e3
t = time.perf_counter(); [g_diag(P) for P in real]; tg = (time.perf_counter() - t) / len(real) * 3e3
res = dict(n_patches=len(patches), mismatches=bad, fast_ms_per_keypoint=tf, gudhi_ms_per_keypoint=tg)
print(res); json.dump(res, open(sys.argv[2], "w"), indent=1)
