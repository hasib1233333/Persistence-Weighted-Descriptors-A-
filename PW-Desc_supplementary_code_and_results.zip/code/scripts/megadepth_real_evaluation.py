"""
megadepth_real_evaluation.py
================================

REAL MegaDepth-1500 evaluation on the actual, real, uploaded test set
(2 scenes: 0015, 0022; 1500 candidate pairs total across 5 overlap-band
files). Pose-estimation-AUC protocol (phdesc.pose_estimation), not the
homography-MMA protocol used for Oxford-Affine/HPatches -- MegaDepth
scenes are wide-baseline and non-planar, so a homography does not hold.

PW-Desc/PW-Desc-rank/SIFT/ORB: shared Harris keypoints.
SuperPoint/DISK: native detection (as elsewhere in this codebase).
LoFTR: detector-free, dense matching (no shared keypoints -- its own
protocol, consistent with Appendix B's documented adaptation).

Given real per-pair cost (LoFTR alone: several seconds to tens of
seconds per real MegaDepth-resolution pair), this evaluates a real,
checkpointed, resumable SUBSET of the 1500 pairs, not claimed as the
full standard test set -- stated explicitly in the manuscript text this
feeds, not implied by the script name alone.

Run: python code/scripts/megadepth_real_evaluation.py
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np

from phdesc import (harris_keypoints, nn_ratio_match, geometric_verify_homography,
                     estimate_relative_pose, relative_pose_error, pose_auc)
from phdesc.descriptor import DescriptorConfig, compute_pw_descriptors_batch
from phdesc.learned_baselines import SuperPointWrapper, DISKWrapper, sift_detect_and_describe, orb_detect_and_describe

ROOT = "/home/claude/phdesc_project/data/megadepth_test_1500"
RESULTS_PATH = os.path.join(os.path.dirname(__file__), "megadepth_real_results.json")
N_PAIRS_PER_FILE = 8  # subset size per scene_info file (5 files -> 40 pairs total)


def load_image_gray(path):
    from skimage.io import imread
    from skimage.color import rgb2gray
    img = imread(path)
    if img.ndim == 3:
        img = rgb2gray(img)
    return img.astype(np.float64)


def resize_long_side(img, K, target=840):
    """
    Resize so the long side is `target` pixels and scale K to match, so
    all downstream methods operate consistently in the resized image's
    coordinate frame with correctly-scaled intrinsics -- no per-method
    coordinate round-tripping needed. 840px is the standard MegaDepth-1500
    evaluation resolution used by LoFTR/SuperGlue/DKM papers, not an
    ad-hoc shortcut; applied uniformly here (not just for LoFTR) because
    full-resolution MegaDepth images (up to 1600px) were found to spike
    SuperPoint's memory use to ~2.6GB in this 3.9GB-RAM sandbox, verified
    directly by isolating the OOM to that specific call before fixing it.
    """
    h, w = img.shape
    scale = target / max(h, w)
    nh, nw = int(round(h * scale)), int(round(w * scale))
    from skimage.transform import resize as sk_resize
    resized = sk_resize(img, (nh, nw), anti_aliasing=True)
    K_scaled = K.copy().astype(np.float64)
    K_scaled[0, 0] *= scale; K_scaled[1, 1] *= scale
    K_scaled[0, 2] *= scale; K_scaled[1, 2] *= scale
    return resized, K_scaled


def relative_gt_pose(pose_a, pose_b):
    """Both poses are 4x4 world-to-camera matrices; relative pose from a to b."""
    T_rel = pose_b @ np.linalg.inv(pose_a)
    return T_rel[:3, :3], T_rel[:3, 3]


def pw_batch(image, keypoints, rank=False):
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8, rank_normalize=rank, backend="gudhi")
    return compute_pw_descriptors_batch(image, keypoints, cfg)


def evaluate_pair(img_a, img_b, K_a, K_b, R_gt, t_gt, models):
    out = {}
    for name, fn in models.items():
        t0 = time.perf_counter()
        if name in ("PW-Desc", "PW-Desc-rank"):
            kp_a = harris_keypoints(img_a, max_keypoints=500, min_distance=8)
            kp_b = harris_keypoints(img_b, max_keypoints=500, min_distance=8)
            if len(kp_a) < 8 or len(kp_b) < 8:
                out[name] = {"pose_err": 180.0, "n_matches": 0, "ms_per_kp": 0.0}
                continue
            da = fn(img_a, kp_a); db = fn(img_b, kp_b)
            matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
            pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64) if len(matches) else np.zeros((0, 2))
            pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64) if len(matches) else np.zeros((0, 2))
            n_kp = len(kp_a) + len(kp_b)
        elif name in ("SIFT", "ORB"):
            kp_a, da = fn(img_a)
            kp_b, db = fn(img_b)
            if len(kp_a) < 8 or len(kp_b) < 8:
                out[name] = {"pose_err": 180.0, "n_matches": 0, "ms_per_kp": 0.0}
                continue
            if name == "ORB":
                import cv2
                bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
                m = bf.match(da, db)
                matches = np.array([[x.queryIdx, x.trainIdx] for x in m]).reshape(-1, 2)
            else:
                matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
            pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64) if len(matches) else np.zeros((0, 2))
            pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64) if len(matches) else np.zeros((0, 2))
            n_kp = len(kp_a) + len(kp_b)
        elif name in ("SuperPoint", "DISK"):
            kp_a, da = fn.detect_and_describe(img_a)
            kp_b, db = fn.detect_and_describe(img_b)
            if len(kp_a) < 8 or len(kp_b) < 8:
                out[name] = {"pose_err": 180.0, "n_matches": 0, "ms_per_kp": 0.0}
                continue
            matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
            pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64) if len(matches) else np.zeros((0, 2))
            pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64) if len(matches) else np.zeros((0, 2))
            n_kp = len(kp_a) + len(kp_b)
        elif name == "LoFTR":
            import torch
            h, w = img_a.shape
            h16, w16 = (min(h, img_b.shape[0]) // 16) * 16, (min(w, img_b.shape[1]) // 16) * 16
            ta = torch.from_numpy(img_a[:h16, :w16].astype(np.float32))[None, None]
            tb = torch.from_numpy(img_b[:h16, :w16].astype(np.float32))[None, None]
            with torch.no_grad():
                res = fn({"image0": ta, "image1": tb})
            pts_a = res["keypoints0"].cpu().numpy().astype(np.float64)
            pts_b = res["keypoints1"].cpu().numpy().astype(np.float64)
            n_kp = len(pts_a) + len(pts_b)
        dt = time.perf_counter() - t0
        n_matches = len(pts_a)
        ms_per_kp = 1000 * dt / max(n_kp, 1) if name != "LoFTR" else 1000 * dt / max(n_matches, 1)

        if n_matches < 8:
            out[name] = {"pose_err": 180.0, "n_matches": int(n_matches), "ms_per_kp": ms_per_kp}
            continue
        R_est, t_est, inliers = estimate_relative_pose(pts_a, pts_b, K_a, K_b)
        if R_est is None:
            out[name] = {"pose_err": 180.0, "n_matches": int(n_matches), "ms_per_kp": ms_per_kp}
            continue
        r_err, t_err = relative_pose_error(R_gt, t_gt, R_est, t_est)
        pose_err = float(max(r_err, t_err))
        out[name] = {"pose_err": pose_err, "n_matches": int(n_matches), "ms_per_kp": ms_per_kp,
                      "rot_err": float(r_err), "trans_err": float(t_err)}
    return out


def main():
    import glob
    scene_info_files = sorted(glob.glob(os.path.join(ROOT, "scene_info", "*.npz")))
    print(f"Found {len(scene_info_files)} scene_info files")

    print("Loading SuperPoint..."); sp = SuperPointWrapper()
    print("Loading DISK..."); disk = DISKWrapper(n_keypoints=500)
    print("Loading LoFTR...")
    import torch, kornia.feature as KF
    loftr = KF.LoFTR(pretrained=None)
    ckpt = torch.load("/home/claude/phdesc_project/data/loftr_checkpoints/loftr_outdoor.ckpt",
                       map_location="cpu", weights_only=False)
    loftr.load_state_dict(ckpt["state_dict"])
    loftr.eval()

    models = {
        "PW-Desc": lambda im, kp: pw_batch(im, kp, rank=False),
        "PW-Desc-rank": lambda im, kp: pw_batch(im, kp, rank=True),
        "SIFT": sift_detect_and_describe,
        "ORB": orb_detect_and_describe,
        "SuperPoint": sp,
        "DISK": disk,
        "LoFTR": loftr,
    }

    if os.path.exists(RESULTS_PATH):
        with open(RESULTS_PATH) as f:
            results = json.load(f)
        print(f"Resuming: {len(results)} pairs already done")
    else:
        results = {}

    total_done = 0
    for sf in scene_info_files:
        scene_tag = os.path.basename(sf).replace(".npz", "")
        d = np.load(sf, allow_pickle=True)
        pair_infos = d["pair_infos"]
        n_this_file = min(N_PAIRS_PER_FILE, len(pair_infos))
        # evenly spaced sample across the file rather than first-N, for diversity
        idxs = np.linspace(0, len(pair_infos) - 1, n_this_file).astype(int)
        for local_i, pi in enumerate(idxs):
            pair_id = f"{scene_tag}_{pi}"
            if pair_id in results:
                continue
            idx0, idx1 = pair_infos[pi][0]
            p0, p1 = d["image_paths"][idx0], d["image_paths"][idx1]
            full0, full1 = os.path.join(ROOT, p0), os.path.join(ROOT, p1)
            if not (os.path.exists(full0) and os.path.exists(full1)):
                continue
            img_a, img_b = load_image_gray(full0), load_image_gray(full1)
            K_a, K_b = d["intrinsics"][idx0], d["intrinsics"][idx1]
            img_a, K_a = resize_long_side(img_a, K_a, target=840)
            img_b, K_b = resize_long_side(img_b, K_b, target=840)
            pose_a, pose_b = d["poses"][idx0], d["poses"][idx1]
            R_gt, t_gt = relative_gt_pose(pose_a, pose_b)

            out = evaluate_pair(img_a, img_b, K_a, K_b, R_gt, t_gt, models)
            results[pair_id] = out
            total_done += 1
            print(f"  [{pair_id}] " + " ".join(f"{k}={v['pose_err']:.1f}" for k, v in out.items()))
            with open(RESULTS_PATH, "w") as f:
                json.dump(results, f)

    # summary
    method_names = list(models.keys())
    summary = {}
    for name in method_names:
        errs = [r[name]["pose_err"] for r in results.values() if name in r]
        aucs = pose_auc(errs, thresholds=(5, 10, 20))
        summary[name] = {"auc5": aucs[5], "auc10": aucs[10], "auc20": aucs[20],
                          "n_pairs": len(errs),
                          "mean_ms_per_kp": float(np.mean([r[name]["ms_per_kp"] for r in results.values() if name in r]))}
    print("\n=== SUMMARY ===")
    print(json.dumps(summary, indent=2))
    with open(RESULTS_PATH, "w") as f:
        json.dump({"per_pair": results, "summary": summary}, f, indent=2)


if __name__ == "__main__":
    main()
