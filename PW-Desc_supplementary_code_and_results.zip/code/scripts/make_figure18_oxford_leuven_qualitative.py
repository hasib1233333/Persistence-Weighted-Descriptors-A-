import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches
import numpy as np

from phdesc import harris_keypoints, nn_ratio_match, geometric_verify_homography
from phdesc.datasets import OxfordAffineLoader
from oxford_affine_real_evaluation import pw_batch

loader = OxfordAffineLoader("/home/claude/phdesc_project/data/oxford_affine")
pairs = {p.pair_id: p for p in loader.iter_pairs()}
sample = pairs["leuven_1_6"]  # largest illumination change in the sequence

img_a, img_b, H_gt = sample.image_a, sample.image_b, sample.H_gt
kp_a = harris_keypoints(img_a, max_keypoints=40, min_distance=8)
kp_b = harris_keypoints(img_b, max_keypoints=40, min_distance=8)

fig, axes = plt.subplots(2, 2, figsize=(8.2, 4.6))

for row, (rank, title) in enumerate([(False, "PW-Desc (plain)"), (True, "PW-Desc-rank")]):
    da = pw_batch(img_a, kp_a, rank=rank)
    db = pw_batch(img_b, kp_b, rank=rank)
    matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)

    n_in = 0
    inliers = None
    if len(matches):
        pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
        pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
        H_est, inliers = geometric_verify_homography(pts_a, pts_b)
        n_in = int(np.sum(inliers)) if inliers is not None else 0

    ax_a, ax_b = axes[row, 0], axes[row, 1]
    ax_a.imshow(img_a, cmap="gray")
    ax_b.imshow(img_b, cmap="gray")
    for ax in (ax_a, ax_b):
        ax.axis("off")

    if len(matches):
        # draw connecting lines using a shared figure-coordinate transform
        for i, (a_idx, b_idx) in enumerate(matches):
            y1, x1 = kp_a[a_idx]
            y2, x2 = kp_b[b_idx]
            is_in = bool(inliers[i]) if inliers is not None and i < len(inliers) else False
            color = "#2ecc71" if is_in else "#e74c3c"
            ax_a.plot(x1, y1, "o", color=color, markersize=3)
            ax_b.plot(x2, y2, "o", color=color, markersize=3)
            con = matplotlib.patches.ConnectionPatch(
                xyA=(x1, y1), coordsA=ax_a.transData,
                xyB=(x2, y2), coordsB=ax_b.transData,
                color=color, linewidth=0.6, alpha=0.75)
            fig.add_artist(con)

    ax_a.set_title(f"{title}: {len(matches)} matches, {n_in} inliers", fontsize=9.5, loc="left")

fig.suptitle("Real matches, real 'leuven' Oxford-Affine pair (illumination change)\n"
             "green = RANSAC inlier, red = outlier", fontsize=10.5)
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure4.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
