"""
timing_quiet.py -- descriptor extraction time per keypoint, measured on an
otherwise idle machine, one process, one thread: Harris keypoints (K=200) on
img1 of four Oxford-Affine scenes, each method timed over all keypoints,
median of three repetitions.
Usage: python timing_quiet.py /path/to/oxford out.json
"""
import sys, os, time, json, statistics
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np, cv2
cv2.setNumThreads(1)
from phdesc import harris_keypoints
from benchmark_shared_detector import METHODS
from mc_measurement import load_resized
from phdesc.fastph import pw_desc_batch
METHODS = dict(METHODS)
METHODS['PW-Desc (compiled)'] = (lambda im, kp: pw_desc_batch(im, kp), False)
METHODS['PW-Desc-rank (compiled)'] = (lambda im, kp: pw_desc_batch(im, kp, rank=True), False)

root, out = sys.argv[1], sys.argv[2]
imgs = [load_resized(os.path.join(root, s, "img1.png")) for s in ("bikes", "graf", "trees", "wall")]
kps = [harris_keypoints(im, max_keypoints=200, min_distance=8) for im in imgs]
n_kp = int(sum(len(k) for k in kps))
res = {}
for name, (fn, _) in METHODS.items():
    fn(imgs[0], kps[0][:5])  # warm-up (JIT compilation)
    ts = []
    for rep in range(3):
        t0 = time.perf_counter()
        for im, kp in zip(imgs, kps):
            fn(im, kp)
        ts.append(1000 * (time.perf_counter() - t0) / n_kp)
    res[name] = statistics.median(ts)
    print(name, res[name], flush=True)
cpu = [l.split(":", 1)[1].strip() for l in open("/proc/cpuinfo") if l.startswith("model name")][0]
json.dump({"ms_per_kp": res, "n_kp": n_kp, "n_images": len(imgs), "repeats": 3, "cpu": cpu.replace("(R)", "")}, open(out, "w"), indent=1)
