"""
real_ablation.py
================

Real-data ablation of PW-Desc design choices on HPatches, with a train/test
split by sequence so that the learned projection is evaluated on sequences
it never saw.

  test split  : every 4th sequence (alphabetical, offset 0)  -> ablation
  train split : every 4th sequence (alphabetical, offset 2)  -> projection W

Variants (shared Harris keypoints, K per image):
  full (H0+H1, scales 16/24/32, 8x8, tau=0)          computed
  H0 only / H1 only / single-scale 16 / 24 / 32       exact slices of 'full',
                                                      re-normalized
  resolution 4x4, 16x16, tau = 0.05                   recomputed
  projection: none / spectrally constrained W / unconstrained W, W trained on
              the train split (exact gradient through the normalization)
For each variant: MMA@3, matching score, homography accuracy (mean corner
error <= 3 / 5 px), and noise sensitivity on the reference images
(self-retrieval rate and median normalized drift under U[-0.02, 0.02] noise).

Usage: python real_ablation.py /path/to/hpatches out_dir [K] [workers]
"""
import sys, os, time, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import numpy as np
import cv2

from phdesc import harris_keypoints, nn_ratio_match
from phdesc.descriptor import DescriptorConfig, compute_pw_descriptors_batch
from benchmark_shared_detector import warp, corner_errors, load_gray

NOISE = 0.02
RECOMPUTE = {"res4": dict(resolution=4), "res16": dict(resolution=16), "tau0.05": dict(tau=0.05)}


def blocks_of(desc, res=8, scales=3):
    """full descriptor -> (scale, dim) blocks; layout per scale: [PI0, PI1]."""
    b = res * res
    return desc.reshape(len(desc), scales, 2, b)


def slice_variant(desc, name):
    B = blocks_of(desc)
    if name == "H0":
        v = B[:, :, 0, :]
    elif name == "H1":
        v = B[:, :, 1, :]
    else:  # single scale
        s = {"s16": 0, "s24": 1, "s32": 2}[name]
        v = B[:, s, :, :]
    v = v.reshape(len(desc), -1)
    n = np.linalg.norm(v, axis=1, keepdims=True)
    return v / np.maximum(n, 1e-12)


def pw(img, kp, **kw):
    return compute_pw_descriptors_batch(img, kp, DescriptorConfig(backend="gudhi", **kw))


def describe_sequence(args):
    """Compute keypoints + full and recomputed-variant descriptors for one sequence."""
    root, seq, K, variants = args
    cv2.setNumThreads(1)
    d = os.path.join(root, seq)
    out = {"seq": seq, "images": {}}
    import zlib
    rng = np.random.default_rng(zlib.crc32(seq.encode()))
    for k in range(1, 7):
        img = load_gray(os.path.join(d, f"{k}.ppm"))
        kp = harris_keypoints(img, max_keypoints=K, min_distance=8)
        rec = {"kp": kp, "shape": img.shape, "full": pw(img, kp)}
        for v in variants:
            rec[v] = pw(img, kp, **RECOMPUTE[v])
        if k == 1:
            noisy = np.clip(img + rng.uniform(-NOISE, NOISE, img.shape), 0, 1)
            rec["noisy_full"] = pw(noisy, kp)
            for v in variants:
                rec["noisy_" + v] = pw(noisy, kp, **RECOMPUTE[v])
        out["images"][k] = rec
    return out


def pair_metrics(kp_a, da, kp_b, db, H_gt, shape_a):
    m = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
    if len(m) == 0:
        return dict(mma3=0.0, ms=0.0, mce=None)
    pa = kp_a[m[:, 0]][:, ::-1].astype(np.float64)
    pb = kp_b[m[:, 1]][:, ::-1].astype(np.float64)
    err = np.linalg.norm(warp(pa, H_gt) - pb, axis=1)
    H = None
    if len(m) >= 4:
        H, _ = cv2.findHomography(pa, pb, cv2.RANSAC, 3.0, maxIters=2000, confidence=0.999)
    mce, _ = corner_errors(H, H_gt, shape_a)
    return dict(mma3=float(np.mean(err <= 3)), ms=float(np.sum(err <= 3) / max(min(len(kp_a), len(kp_b)), 1)), mce=mce)


def noise_metrics(clean, noisy):
    drift = np.linalg.norm(clean - noisy, axis=1)
    dcc = np.linalg.norm(clean[:, None] - clean[None], axis=2)
    np.fill_diagonal(dcc, np.inf)
    nu = drift / np.maximum(dcc.min(1), 1e-12)
    dpc = np.linalg.norm(noisy[:, None] - clean[None], axis=2)
    return dict(nu_median=float(np.median(nu)), self_retrieval=float(np.mean(dpc.argmin(1) == np.arange(len(clean)))))


# ------------------------- projection training -------------------------
def train_projection(Xa, Xb, y, constrained, out_dim=128, lr=0.5, epochs=400, m_pos=0.3, m_neg=0.6, wd=1e-4, seed=0):
    """Hinge contrastive loss on z = Wx/||Wx||, exact gradient through the
    normalization, full-batch gradient descent; if constrained, W is
    projected onto {||W||_2 <= 1} by SVD clipping after every step."""
    rng = np.random.default_rng(seed)
    N, d = Xa.shape
    W = rng.normal(scale=1.0 / np.sqrt(d), size=(out_dim, d))
    if constrained:
        U, S, Vt = np.linalg.svd(W, full_matrices=False); W = (U * np.minimum(S, 1.0)) @ Vt
    hist = []
    for ep in range(epochs):
        Ua, Ub = Xa @ W.T, Xb @ W.T
        na = np.linalg.norm(Ua, axis=1, keepdims=True) + 1e-12
        nb = np.linalg.norm(Ub, axis=1, keepdims=True) + 1e-12
        za, zb = Ua / na, Ub / nb
        diff = za - zb
        dist = np.linalg.norm(diff, axis=1) + 1e-12
        pos = (y == 1) & (dist > m_pos)
        neg = (y == 0) & (dist < m_neg)
        c = np.zeros(N)
        c[pos] = 2 * (dist[pos] - m_pos)
        c[neg] = -2 * (m_neg - dist[neg])
        loss = np.sum(np.where(pos, (dist - m_pos) ** 2, 0) + np.where(neg, (m_neg - dist) ** 2, 0)) / N
        g_za = (c / dist)[:, None] * diff
        g_zb = -g_za
        g_ua = (g_za - za * np.sum(za * g_za, axis=1, keepdims=True)) / na
        g_ub = (g_zb - zb * np.sum(zb * g_zb, axis=1, keepdims=True)) / nb
        G = (g_ua.T @ Xa + g_ub.T @ Xb) / N + wd * W
        W = W - lr * G
        if constrained:
            U, S, Vt = np.linalg.svd(W, full_matrices=False); W = (U * np.minimum(S, 1.0)) @ Vt
        if ep % 50 == 0 or ep == epochs - 1:
            hist.append((ep, float(loss)))
    return W, hist


def project(W, X):
    Z = X @ W.T
    n = np.linalg.norm(Z, axis=1, keepdims=True)
    return Z / np.maximum(n, 1e-12), n[:, 0]


def training_pairs(seq_data, root, rng, max_pos_per_pair=150):
    Xa, Xb, y = [], [], []
    for sd in seq_data:
        d = os.path.join(root, sd["seq"])
        A = sd["images"][1]
        for k in range(2, 7):
            Bk = sd["images"][k]
            H = np.loadtxt(os.path.join(d, f"H_1_{k}"))
            wa = warp(A["kp"][:, ::-1].astype(float), H)
            dd = np.linalg.norm(wa[:, None] - Bk["kp"][:, ::-1][None].astype(float), axis=2)
            j = dd.argmin(1)
            ok = np.where(dd[np.arange(len(j)), j] <= 2.0)[0]
            ok = rng.permutation(ok)[:max_pos_per_pair]
            for i in ok:
                Xa.append(A["full"][i]); Xb.append(Bk["full"][j[i]]); y.append(1)
                jn = rng.integers(len(Bk["kp"]))
                while jn == j[i]:
                    jn = rng.integers(len(Bk["kp"]))
                Xa.append(A["full"][i]); Xb.append(Bk["full"][jn]); y.append(0)
    return np.array(Xa), np.array(Xb), np.array(y)


def main():
    root, out_dir = sys.argv[1], sys.argv[2]
    K = int(sys.argv[3]) if len(sys.argv) > 3 else 300
    workers = int(sys.argv[4]) if len(sys.argv) > 4 else 2
    os.makedirs(out_dir, exist_ok=True)
    seqs = sorted(s for s in os.listdir(root) if os.path.isdir(os.path.join(root, s)))
    test, train = seqs[0::4], seqs[2::4]
    from multiprocessing import Pool
    t0 = time.time()
    with Pool(workers) as pool:
        test_data = []
        for i, r in enumerate(pool.imap_unordered(describe_sequence, [(root, s, K, list(RECOMPUTE)) for s in test])):
            test_data.append(r); print(f"test [{i + 1}/{len(test)}] {r['seq']} {time.time() - t0:.0f}s", flush=True)
        train_data = []
        for i, r in enumerate(pool.imap_unordered(describe_sequence, [(root, s, K, []) for s in train])):
            train_data.append(r); print(f"train [{i + 1}/{len(train)}] {r['seq']} {time.time() - t0:.0f}s", flush=True)
    test_data.sort(key=lambda r: r["seq"]); train_data.sort(key=lambda r: r["seq"])

    rng = np.random.default_rng(0)
    Xa, Xb, y = training_pairs(train_data, root, rng)
    print("training pairs", Xa.shape, int(y.sum()), flush=True)
    Wc, hist_c = train_projection(Xa, Xb, y, constrained=True)
    Wu, hist_u = train_projection(Xa, Xb, y, constrained=False)
    proj_info = dict(n_train_pairs=int(len(y)), n_pos=int(y.sum()), train_sequences=train,
                     constrained=dict(spectral_norm=float(np.linalg.norm(Wc, 2)), loss=hist_c),
                     unconstrained=dict(spectral_norm=float(np.linalg.norm(Wu, 2)), loss=hist_u))

    variants = ["full", "H0", "H1", "s16", "s24", "s32"] + list(RECOMPUTE) + ["proj_constrained", "proj_unconstrained"]

    def get(rec, v, noisy=False):
        pre = "noisy_" if noisy else ""
        if v in ("full",) or v in RECOMPUTE:
            return rec[pre + v]
        if v.startswith("proj"):
            W = Wc if v == "proj_constrained" else Wu
            return project(W, rec[pre + "full"])[0]
        return slice_variant(rec[pre + "full"], v)

    per_seq = {v: [] for v in variants}
    eta_W = []
    for sd in test_data:
        d = os.path.join(root, sd["seq"])
        A = sd["images"][1]
        eta_W.extend(project(Wc, A["full"])[1].tolist())
        for v in variants:
            da = get(A, v)
            prs = []
            for k in range(2, 7):
                Bk = sd["images"][k]
                prs.append(pair_metrics(A["kp"], da, Bk["kp"], get(Bk, v), np.loadtxt(os.path.join(d, f"H_1_{k}")), A["shape"]))
            nm = noise_metrics(da, get(A, v, noisy=True))
            per_seq[v].append(dict(seq=sd["seq"], mma3=float(np.mean([p["mma3"] for p in prs])),
                                   ms=float(np.mean([p["ms"] for p in prs])),
                                   ha3=float(np.mean([p["mce"] is not None and p["mce"] <= 3 for p in prs])),
                                   ha5=float(np.mean([p["mce"] is not None and p["mce"] <= 5 for p in prs])),
                                   **nm))
    res = dict(K=K, test_sequences=test, projection=proj_info,
               eta_W=dict(min=float(np.min(eta_W)), p1=float(np.percentile(eta_W, 1)), median=float(np.median(eta_W))),
               per_sequence=per_seq)
    json.dump(res, open(os.path.join(out_dir, "real_ablation.json"), "w"), indent=1)
    for v in variants:
        r = per_seq[v]
        print(f"{v:20s} MMA3={np.mean([x['mma3'] for x in r]):.3f} HA5={np.mean([x['ha5'] for x in r]):.3f} "
              f"SR={np.mean([x['self_retrieval'] for x in r]):.3f} nu={np.median([x['nu_median'] for x in r]):.3f}")
    print("done", time.time() - t0)


if __name__ == "__main__":
    main()
