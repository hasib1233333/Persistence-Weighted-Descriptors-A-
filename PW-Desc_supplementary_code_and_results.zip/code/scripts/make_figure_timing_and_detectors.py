import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

sdir = os.path.dirname(__file__)
d = json.load(open(os.path.join(sdir, "cpu_stress_suite_results.json")))

# ---- Component-wise timing breakdown (stacked bar, single scale example) ----
ct = d["component_timing"]
stages = ["extract_ms", "filter_ms", "boundary_matrix_ms", "reduction_ms", "vectorization_ms"]
stage_labels = ["Patch\nextraction", "Filtration\n(value comp.)", "Boundary matrix\nconstruction",
                "Boundary matrix\nreduction", "Vectorization\n(persistence image)"]
means = [ct[s]["mean_ms"] for s in stages]
stds = [ct[s]["std_ms"] for s in stages]
colors = ["#95a5a6", "#3fa34d", "#e07b39", "#c0392b", "#2c6fbb"]

fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))

ax = axes[0]
left = 0
for stage, mean, color in zip(stage_labels, means, colors):
    ax.barh(0, mean, left=left, color=color, label=f"{stage.splitlines()[0]}: {mean:.2f} ms", height=0.5)
    left += mean
ax.set_xlim(0, left * 1.05)
ax.set_yticks([])
ax.set_xlabel("Time (ms), mean over 20 real keypoints, one 16/24/32px scale set")
ax.set_title(f"(a) Component-wise runtime breakdown\n(total: {sum(means):.2f} ms/keypoint, real measured)", fontsize=10)
ax.legend(fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.25), ncol=2)

ax2 = axes[1]
frac = np.array(means) / sum(means) * 100
ax2.pie(frac, labels=[f"{l.splitlines()[0]}\n{f:.0f}%" for l, f in zip(stage_labels, frac)],
        colors=colors, startangle=90, textprops={"fontsize": 8})
ax2.set_title("(b) Fraction of total runtime", fontsize=10)

plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure_timing_breakdown.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)

# ---- Detector repeatability comparison ----
rep = d["detector_repeatability"]
fig2, ax = plt.subplots(figsize=(8, 4.5))
names = list(rep.keys())
reps = [rep[n]["mean_repeatability"] for n in names]
nkp = [rep[n]["mean_n_keypoints"] for n in names]
colors3 = ["#2c6fbb", "#3fa34d", "#8e44ad", "#c0392b", "#7f8c8d"]
bars = ax.bar(names, reps, color=colors3)
for b, n in zip(bars, nkp):
    ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.02, f"n={n:.0f} kp",
            ha="center", fontsize=8)
ax.set_ylabel("Repeatability @ 3px (real, measured)")
ax.set_ylim(0, 1.05)
ax.set_xticks(range(len(names)))
ax.set_xticklabels(names, rotation=20, ha="right", fontsize=8.5)
ax.set_title("Keypoint detector repeatability under random homography\n"
              "(real detectors: this repo's Harris; scikit-image FAST/DoG-blob; OpenCV SIFT/ORB)",
              fontsize=10)
ax.grid(axis="y", alpha=0.3)
plt.tight_layout()
out2 = "/home/claude/phdesc_project/paper/figure_detector_repeatability.pdf"
plt.savefig(out2, bbox_inches="tight")
print("saved", out2)
