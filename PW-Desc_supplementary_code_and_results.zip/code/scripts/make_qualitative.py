"""
make_qualitative.py
===================

Fig. 7: real Oxford-Affine matches at shared Harris keypoints (protocol P1) for
PW-Desc-rank and SIFT, on one illumination and one viewpoint pair.
Monochrome annotation: correct matches (ground-truth error <= 3 px) as
solid white lines with a black outline, incorrect ones as thin dashed
black lines. Photographs are shown in grayscale, as used by the methods.

Usage: python make_qualitative.py /path/to/oxford out.pdf [scene_i] [k_i] [scene_v] [k_v]
"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe

from phdesc import harris_keypoints
from benchmark_shared_detector import METHODS, match, warp, load_gray

plt.rcParams.update({"font.family": "STIXGeneral", "mathtext.fontset": "stix", "font.size": 9,
                     "savefig.dpi": 300, "pdf.fonttype": 42})


def panel(ax, img_a, img_b, kp_a, kp_b, m, H, title):
    h = max(img_a.shape[0], img_b.shape[0])
    canvas = np.ones((h, img_a.shape[1] + 10 + img_b.shape[1]))
    canvas[:img_a.shape[0], :img_a.shape[1]] = img_a
    off = img_a.shape[1] + 10
    canvas[:img_b.shape[0], off:] = img_b
    ax.imshow(canvas, cmap="gray", vmin=0, vmax=1)
    pa = kp_a[m[:, 0]][:, ::-1].astype(float)
    pb = kp_b[m[:, 1]][:, ::-1].astype(float)
    ok = np.linalg.norm(warp(pa, H) - pb, axis=1) <= 3
    for (xa, ya), (xb, yb), good in zip(pa, pb, ok):
        if good:
            ax.plot([xa, xb + off], [ya, yb], color="white", lw=0.9,
                    path_effects=[pe.Stroke(linewidth=1.8, foreground="black"), pe.Normal()])
        else:
            ax.plot([xa, xb + off], [ya, yb], color="black", lw=0.5, ls=(0, (2, 2)))
    ax.set_title(f"{title}: {int(ok.sum())} correct / {len(ok)} matches", fontsize=9)
    ax.axis("off")
    return int(ok.sum()), len(ok)


def main():
    root, out = sys.argv[1], sys.argv[2]
    seq_i, k_i = (sys.argv[3], int(sys.argv[4])) if len(sys.argv) > 4 else ("leuven", 5)
    seq_v, k_v = (sys.argv[5], int(sys.argv[6])) if len(sys.argv) > 6 else ("graf", 3)
    fig, axs = plt.subplots(2, 2, figsize=(7.0, 2.9))
    res = {}
    for row, (seq, k) in enumerate(((seq_i, k_i), (seq_v, k_v))):
        d = os.path.join(root, seq)
        a, b = load_gray(os.path.join(d, "img1.png")), load_gray(os.path.join(d, f"img{k}.png"))
        H = np.loadtxt(os.path.join(d, f"H1to{k}p"))
        kp_a = harris_keypoints(a, max_keypoints=300, min_distance=8)
        kp_b = harris_keypoints(b, max_keypoints=300, min_distance=8)
        for col, name in enumerate(("PW-Desc-rank", "SIFT")):
            fn, binary = METHODS[name]
            m = match(fn(a, kp_a), fn(b, kp_b), binary)
            res[(seq, name)] = panel(axs[row, col], a, b, kp_a, kp_b, m, H, f"({'abcd'[2 * row + col]}) {name}, {seq} 1\u2013{k}")
    fig.tight_layout()
    fig.savefig(out, bbox_inches="tight")
    print(res)


if __name__ == "__main__":
    main()
