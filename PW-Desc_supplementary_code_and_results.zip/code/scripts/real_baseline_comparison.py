"""
real_baseline_comparison.py
==============================

Extends the synthetic sanity-check suite with REAL classical (OpenCV
SIFT, ORB) and REAL learned (SuperPoint, official MagicLeap weights)
baselines -- not reimplementations, not literature-quoted numbers, but
actual inference run in this repository. Each method uses its OWN native
detector (standard protocol for a descriptor/detector-coupled comparison,
complementing the shared-Harris-keypoint comparison in
synthetic_validation.py).

Licensing: SuperPoint inference uses Magic Leap's officially released,
noncommercially-licensed weights, downloaded at runtime (see
phdesc/learned_baselines.py docstring); not bundled with this repository.

Run: python code/scripts/real_baseline_comparison.py
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np

from phdesc import mean_matching_accuracy, geometric_verify_homography
from phdesc.learned_baselines import (SuperPointWrapper, sift_detect_and_describe,
                                       orb_detect_and_describe, hamming_nn_ratio_match)
from phdesc.matching import nn_ratio_match
from synthetic_validation import make_synthetic_scene, random_homography, warp_image, elastic_deform


def evaluate_native(name, detect_describe_fn, img_a, img_b, H_gt, is_binary=False):
    t0 = time.time()
    kp_a, da = detect_describe_fn(img_a)
    kp_b, db = detect_describe_fn(img_b)
    t_detect_describe = time.time() - t0
    n_kp = len(kp_a)

    if len(kp_a) == 0 or len(kp_b) == 0:
        return dict(name=name, n_kp=n_kp, n_matches=0, mma3=0.0, inlier_ratio=0.0,
                    ms_per_kp=1000 * t_detect_describe / max(n_kp, 1))

    if is_binary:
        matches = hamming_nn_ratio_match(da, db, ratio_thresh=0.85)
    else:
        matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)

    if len(matches) == 0:
        return dict(name=name, n_kp=n_kp, n_matches=0, mma3=0.0, inlier_ratio=0.0,
                    ms_per_kp=1000 * t_detect_describe / max(n_kp, 1))

    pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
    pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
    mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
    H_est, inliers = geometric_verify_homography(pts_a, pts_b)
    inlier_ratio = float(np.mean(inliers)) if len(inliers) else 0.0

    return dict(name=name, n_kp=n_kp, n_matches=int(len(matches)), mma3=mma[3],
                inlier_ratio=inlier_ratio, ms_per_kp=1000 * t_detect_describe / max(n_kp, 1))


def main():
    print("Loading SuperPoint (downloading official weights if not cached)...")
    sp = SuperPointWrapper()
    print("SuperPoint ready.\n")

    def sift_fn(img):
        return sift_detect_and_describe(img, max_keypoints=200)

    def orb_fn(img):
        return orb_detect_and_describe(img, max_keypoints=200)

    def sp_fn(img):
        return sp.detect_and_describe(img)

    methods = [
        ("SIFT (real, OpenCV)", sift_fn, False),
        ("ORB (real, OpenCV)", orb_fn, True),
        ("SuperPoint (real, official weights)", sp_fn, False),
    ]

    N_SCENES = 4
    results = {"homography_only": [], "homography_plus_elastic": []}

    for scene_id in range(N_SCENES):
        base = make_synthetic_scene(size=160, n_shapes=30, seed=scene_id)
        H_gt = random_homography(160, max_shift=12, seed=100 + scene_id)

        for regime in ["homography_only", "homography_plus_elastic"]:
            warped = warp_image(base, H_gt)
            if regime == "homography_plus_elastic":
                warped = elastic_deform(warped, alpha=3.0, sigma=10.0, seed=200 + scene_id)
            warped = np.clip(warped, 0, 1)

            for name, fn, is_binary in methods:
                r = evaluate_native(name, fn, base, warped, H_gt, is_binary=is_binary)
                r["scene_id"] = scene_id
                results[regime].append(r)
                print(f"  scene {scene_id} [{regime}] {name}: n_kp={r['n_kp']} "
                      f"mma3={r['mma3']:.3f} inlier_ratio={r['inlier_ratio']:.3f} "
                      f"ms/kp={r['ms_per_kp']:.3f}")

    summary = {}
    for regime, rows in results.items():
        summary[regime] = {}
        for name, _, _ in methods:
            sub = [r for r in rows if r["name"] == name]
            mma3 = np.array([r["mma3"] for r in sub])
            inlier = np.array([r["inlier_ratio"] for r in sub])
            n_kp = np.array([r["n_kp"] for r in sub])
            ms = np.array([r["ms_per_kp"] for r in sub])
            summary[regime][name] = dict(
                mean_mma3=float(np.mean(mma3)), std_mma3=float(np.std(mma3)),
                mean_inlier_ratio=float(np.mean(inlier)),
                mean_n_kp=float(np.mean(n_kp)),
                mean_ms_per_kp=float(np.mean(ms)),
                n_scenes=len(sub))

    print("\n" + json.dumps(summary, indent=2))
    out_path = os.path.join(os.path.dirname(__file__), "real_baseline_comparison_results.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nSaved -> {out_path}")


if __name__ == "__main__":
    main()
