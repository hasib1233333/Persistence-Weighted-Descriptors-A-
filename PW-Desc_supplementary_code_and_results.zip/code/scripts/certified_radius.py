"""
certified_radius.py -- per-keypoint certified noise tolerance.

For the reference descriptors of one image, the nearest-neighbour match of a
perturbed descriptor x(P') against the clean set is guaranteed correct when
||x(P') - x(P)|| < d_nn(P)/2 (triangle inequality). With the thresholded bound
(Proposition 3), whose right-hand side depends only on the clean patch, this
gives a certified tolerance
    delta*(P) = sup{ delta < tau/2 : 2 B_tau(P, delta)/||x~(P)|| < d_nn(P)/2 },
    B_tau(P, delta) = r K_tau (sum_{s,k} N_{tau-2delta}(D_k(P_s))^2)^{1/2} delta.
The script computes delta* on the 16 reference images (100 Harris keypoints
each) for tau in {0.05, 0.1}, and checks it empirically: uniform noise of bound
delta* is applied and self-retrieval must hold at every certified keypoint.
Usage: python certified_radius.py /path/to/oxford out.json
"""
import sys, os, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
import numpy as np
from phdesc import harris_keypoints
from phdesc.descriptor import extract_patch, persistence_image
from phdesc.persistence import compute_persistence_diagrams
from mc_measurement import load_resized

SCALES, R = (16, 24, 32), 8
SIGMA = 1.0 / R


def K(tau):
    return 2.0 / (1.0 - tau) + np.sqrt(5) / (SIGMA * np.sqrt(np.e))


def desc(patches, tau):
    pers, vec = [], []
    for P in patches:
        for pd in compute_persistence_diagrams(P, backend="gudhi"):
            f = pd.finite()
            pers.append(f[:, 1] - f[:, 0] if len(f) else np.zeros(0))
            vec.append(persistence_image(pd, (0, 1), (0, 1), R, tau=tau).reshape(-1))
    return pers, np.concatenate(vec)


def bound(pers, tau, d):
    n = np.array([np.sum(p > tau - 2 * d) for p in pers], dtype=float)
    return R * K(tau) * np.sqrt(np.sum(n ** 2)) * d


def radius(pers, nrm, dnn, tau):
    ok = lambda d: 2 * bound(pers, tau, d) / nrm < dnn / 2
    lo, hi = 0.0, tau / 2 * (1 - 1e-9)
    if ok(hi):
        return hi
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        lo, hi = (mid, hi) if ok(mid) else (lo, mid)
    return lo


def main():
    root, out = sys.argv[1], sys.argv[2]
    paths = [os.path.join(root, s, f"img{k}.png") for s in sorted(os.listdir(root)) for k in (1, 4)]
    res = {}
    for tau in (0.05, 0.1):
        rad, viol, n = [], 0, 0
        for idx, p in enumerate(paths):
            img = load_resized(p)
            kp = harris_keypoints(img, max_keypoints=100, min_distance=8)
            D = [desc([extract_patch(img, y, x, s) for s in SCALES], tau) for (y, x) in kp]
            Xt = np.stack([d[1] for d in D]); nr = np.linalg.norm(Xt, axis=1)
            X = Xt / np.maximum(nr, 1e-12)[:, None]
            G = np.linalg.norm(X[:, None] - X[None], axis=2); np.fill_diagonal(G, np.inf)
            dnn = G.min(1)
            r = np.array([radius(D[i][0], nr[i], dnn[i], tau) if nr[i] > 0 else 0.0 for i in range(len(kp))])
            rad += r.tolist()
            # empirical check at delta* (one draw per keypoint, noise on the patch stack)
            rng = np.random.default_rng(9000 + idx)
            for i, (y, x) in enumerate(kp):
                if r[i] <= 0:
                    continue
                Pn = [np.clip(extract_patch(img, y, x, s) + rng.uniform(-r[i], r[i], (s, s)), 0, 1) for s in SCALES]
                xn = desc(Pn, tau)[1]; xn = xn / max(np.linalg.norm(xn), 1e-12)
                n += 1
                viol += int(np.argmin(np.linalg.norm(X - xn, axis=1)) != i)
            print(tau, p, float(np.median(r)), flush=True)
        r = np.array(rad)
        res[str(tau)] = dict(n_kp=len(r), median=float(np.median(r)), p10=float(np.percentile(r, 10)), p90=float(np.percentile(r, 90)),
                             max=float(r.max()), frac_half_level=float(np.mean(r >= 0.5 / 255)), frac_tenth_level=float(np.mean(r >= 0.1 / 255)),
                             frac_zero=float(np.mean(r <= 0)), checked=n, violations=viol)
        print(tau, res[str(tau)], flush=True)
    json.dump(res, open(out, "w"), indent=1)


if __name__ == "__main__":
    main()
