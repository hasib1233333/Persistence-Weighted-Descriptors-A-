"""
real_image_validation.py
==========================

Genuinely REAL (not procedurally-generated synthetic) image validation,
using real bundled photographs from scikit-image (the classic "cameraman",
an astronaut photo, a coffee cup, coin photographs, a real retinal fundus
photograph, a cat photo, the moon, brick/texture photos, and a Hubble deep
field image) -- all offline, zero network calls, real photographic
content with real noise/texture/optical characteristics that procedurally
generated Gaussian-blob scenes do not have.

Honesty note (see manuscript Sec. 8/Limitations): this is a controlled,
single-image, known-ground-truth-homography protocol (the same design
used by the classical Oxford-Affine benchmark itself, for exactly the
same reason: homography ground truth is exact and requires no expensive
multi-view 3D reconstruction). It is NOT a substitute for HPatches/
MegaDepth/ScanNet, which use independently-captured multi-view sequences.
It IS a genuine, real-photographic-content upgrade over the fully
synthetic procedural scenes used elsewhere in this repository, and is
reported as exactly that -- no more, no less.

Run: python code/scripts/real_image_validation.py
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np
import skimage.data as skdata
from skimage.color import rgb2gray

from phdesc import harris_keypoints, nn_ratio_match, mean_matching_accuracy, geometric_verify_homography
from phdesc.descriptor import DescriptorConfig, compute_pw_descriptors_batch
from phdesc import baselines
from phdesc.profiling import (cv2_sift_describe, cv2_orb_describe,
                               cv2_brisk_detect_and_describe, cv2_akaze_detect_and_describe,
                               cv2_kaze_detect_and_describe)
from synthetic_validation import random_homography, warp_image, elastic_deform
import cv2


REAL_IMAGES = ["camera", "astronaut", "coffee", "coins", "retina",
               "chelsea", "moon", "brick", "rocket", "hubble_deep_field"]


def load_real_image(name, max_size=200):
    img = getattr(skdata, name)()
    if img.ndim == 3:
        img = rgb2gray(img)
    img = img.astype(np.float64)
    img = (img - img.min()) / (img.max() - img.min() + 1e-9)
    # downsample large images to keep runtime tractable (this repo's
    # from-scratch PH engine is CPU-bound, Sec. 6 of the manuscript)
    H, W = img.shape
    if max(H, W) > max_size:
        from skimage.transform import resize
        scale = max_size / max(H, W)
        img = resize(img, (int(H * scale), int(W * scale)), anti_aliasing=True)
    return img


def pw_batch(image, keypoints, rank=False):
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8, rank_normalize=rank)
    return compute_pw_descriptors_batch(image, keypoints, cfg)


def raw_batch(image, keypoints):
    return baselines.batch_descriptor(baselines.raw_patch_descriptor, image, keypoints, size=16)


def gradhist_batch(image, keypoints):
    return baselines.batch_descriptor(baselines.gradient_histogram_descriptor, image, keypoints, size=16)


def match_and_score(da, db, kp_a, kp_b, H_gt, binary=False):
    if len(da) == 0 or len(db) == 0:
        return 0.0, 0
    if binary:
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        matches = bf.match(da, db)
        if len(matches) == 0:
            return 0.0, 0
        idx_a = np.array([m.queryIdx for m in matches])
        idx_b = np.array([m.trainIdx for m in matches])
    else:
        m = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
        if len(m) == 0:
            return 0.0, 0
        idx_a, idx_b = m[:, 0], m[:, 1]
    pts_a = kp_a[idx_a][:, ::-1].astype(np.float64)
    pts_b = kp_b[idx_b][:, ::-1].astype(np.float64)
    mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
    return mma[3], len(idx_a)


METHODS = {
    "PW-Desc": (pw_batch, False),
    "PW-Desc-rank": (lambda im, kp: pw_batch(im, kp, rank=True), False),
    "RawPatch": (raw_batch, False),
    "GradHist": (gradhist_batch, False),
    "SIFT": (cv2_sift_describe, False),
    "ORB": (cv2_orb_describe, True),
}


def run_homography_regime():
    """Real images, real homography warp -- direct analogue of Table 11's
    synthetic homography-only regime, on real photographs instead."""
    print("=== Real-image homography regime ===")
    results = {name: [] for name in METHODS}
    for idx, name_img in enumerate(REAL_IMAGES):
        base = load_real_image(name_img)
        H_gt = random_homography(base.shape[0], max_shift=int(0.08 * base.shape[0]), seed=500 + idx)
        warped = np.clip(warp_image(base, H_gt), 0, 1)

        kp_a = harris_keypoints(base, max_keypoints=40, min_distance=8)
        kp_b = harris_keypoints(warped, max_keypoints=40, min_distance=8)
        if len(kp_a) < 6 or len(kp_b) < 6:
            print(f"  {name_img}: too few keypoints, skipped")
            continue

        for method, (fn, binary) in METHODS.items():
            da = fn(base, kp_a)
            db = fn(warped, kp_b)
            mma, n = match_and_score(da, db, kp_a, kp_b, H_gt, binary=binary)
            results[method].append(mma)
        print(f"  {name_img}: done ({len(kp_a)} kp)")

    summary = {m: dict(mean_mma3=float(np.mean(v)) if v else 0.0,
                        std_mma3=float(np.std(v)) if v else 0.0,
                        n_images=len(v))
               for m, v in results.items()}
    return summary, results


def run_elastic_regime():
    """Real images, homography + non-rigid elastic warp."""
    print("=== Real-image homography+elastic regime ===")
    results = {name: [] for name in METHODS}
    for idx, name_img in enumerate(REAL_IMAGES):
        base = load_real_image(name_img)
        H_gt = random_homography(base.shape[0], max_shift=int(0.06 * base.shape[0]), seed=600 + idx)
        warped = warp_image(base, H_gt)
        warped = elastic_deform(warped, alpha=3.0, sigma=10.0, seed=700 + idx)
        warped = np.clip(warped, 0, 1)

        kp_a = harris_keypoints(base, max_keypoints=40, min_distance=8)
        kp_b = harris_keypoints(warped, max_keypoints=40, min_distance=8)
        if len(kp_a) < 6 or len(kp_b) < 6:
            print(f"  {name_img}: too few keypoints, skipped")
            continue

        for method, (fn, binary) in METHODS.items():
            da = fn(base, kp_a)
            db = fn(warped, kp_b)
            mma, n = match_and_score(da, db, kp_a, kp_b, H_gt, binary=binary)
            results[method].append(mma)
        print(f"  {name_img}: done ({len(kp_a)} kp)")

    summary = {m: dict(mean_mma3=float(np.mean(v)) if v else 0.0,
                        std_mma3=float(np.std(v)) if v else 0.0,
                        n_images=len(v))
               for m, v in results.items()}
    return summary, results


NATIVE_METHODS = {
    "BRISK": (cv2_brisk_detect_and_describe, True),
    "AKAZE": (cv2_akaze_detect_and_describe, True),
    "KAZE": (cv2_kaze_detect_and_describe, False),
}


def run_native_detector_regime(max_kp=40):
    """BRISK/AKAZE/KAZE on the same real images, native detector (required
    -- see code/phdesc/profiling.py), homography-only regime, for a
    complete real-image picture across all methods tested elsewhere in
    this repository."""
    print("=== Real-image native-detector regime (BRISK/AKAZE/KAZE) ===")
    results = {name: [] for name in NATIVE_METHODS}
    for idx, name_img in enumerate(REAL_IMAGES):
        base = load_real_image(name_img)
        H_gt = random_homography(base.shape[0], max_shift=int(0.08 * base.shape[0]), seed=500 + idx)
        warped = np.clip(warp_image(base, H_gt), 0, 1)

        for name, (fn, binary) in NATIVE_METHODS.items():
            kp_a, da = fn(base, max_kp)
            kp_b, db = fn(warped, max_kp)
            if len(kp_a) < 4 or len(kp_b) < 4:
                results[name].append(0.0)
                continue
            mma, n = match_and_score(da, db, kp_a, kp_b, H_gt, binary=binary)
            results[name].append(mma)
        print(f"  {name_img}: done")

    summary = {m: dict(mean_mma3=float(np.mean(v)) if v else 0.0,
                        std_mma3=float(np.std(v)) if v else 0.0,
                        n_images=len(v))
               for m, v in results.items()}
    return summary


def main():
    out = {}
    hom_summary, hom_raw = run_homography_regime()
    out["homography_only"] = hom_summary
    print(json.dumps(hom_summary, indent=2))

    ela_summary, ela_raw = run_elastic_regime()
    out["homography_plus_elastic"] = ela_summary
    print(json.dumps(ela_summary, indent=2))

    native_summary = run_native_detector_regime()
    out["native_detector_homography_only"] = native_summary
    print(json.dumps(native_summary, indent=2))

    # paired stats: PW-Desc vs GradHist, using the raw per-image scores
    from phdesc import paired_bootstrap_ci, wilcoxon_signed_rank
    for regime, raw in [("homography_only", hom_raw), ("homography_plus_elastic", ela_raw)]:
        pw = np.array(raw["PW-Desc"])
        gh = np.array(raw["GradHist"])
        n = min(len(pw), len(gh))
        if n > 1:
            mean_diff, lo, hi = paired_bootstrap_ci(pw[:n], gh[:n], n_boot=5000, seed=0)
            z, p = wilcoxon_signed_rank(pw[:n], gh[:n])
            out[regime]["PW-Desc_vs_GradHist_stats"] = dict(
                n=n, mean_diff=mean_diff, ci95=[lo, hi], wilcoxon_z=z, wilcoxon_p=p)

    out_path = os.path.join(os.path.dirname(__file__), "real_image_validation_results.json")
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved -> {out_path}")


if __name__ == "__main__":
    main()
