import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from phdesc.persistence import compute_persistence_diagrams
from phdesc.descriptor import persistence_image

# Use the analytic annulus patch (exact, hand-verified ground truth: H1
# birth=0.0, death=5.0) so every panel in this figure is independently
# checkable, not just "some patch".
N = 21
cy, cx = N // 2, N // 2
yy, xx = np.mgrid[0:N, 0:N]
r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
patch = np.full((N, N), 5.0)
patch[r <= 8.0] = 2.0
patch[r <= 5.0] = 5.0
patch[(r > 5.0) & (r <= 8.0)] = 0.0
patch_norm = patch / patch.max()

pd0, pd1 = compute_persistence_diagrams(patch)

thresholds = [0.0, 0.4, 0.7, 1.0]  # normalized sublevel-set cutoffs t (fraction of max)
fig, axes = plt.subplots(2, 4, figsize=(13, 6.4))

for i, t in enumerate(thresholds):
    ax = axes[0, i]
    sublevel = patch_norm <= t
    display = np.where(sublevel, patch_norm, np.nan)
    ax.imshow(patch_norm, cmap="gray", vmin=0, vmax=1, alpha=0.25)
    masked = np.ma.masked_where(~sublevel, patch_norm)
    ax.imshow(masked, cmap="viridis", vmin=0, vmax=1)
    ax.set_title(f"Sublevel set $X_t$\n$t={t:.2f}$" + (" (birth of loop)" if i == 0 else
                 (" (loop still open)" if t < 1.0 and i < 3 else " (hole filled: death)")),
                 fontsize=9)
    ax.set_xticks([]); ax.set_yticks([])

# bottom row: birth event, death event, PD, PI
ax = axes[1, 0]
ax.imshow(patch_norm, cmap="gray", vmin=0, vmax=1, alpha=0.3)
ring_mask = (r > 5.0) & (r <= 8.0)
ax.imshow(np.ma.masked_where(~ring_mask, np.ones_like(patch_norm)), cmap="autumn")
ax.set_title("Birth: the ring closes\ninto a loop at $t=0$", fontsize=9)
ax.set_xticks([]); ax.set_yticks([])

ax = axes[1, 1]
ax.imshow(patch_norm, cmap="gray", vmin=0, vmax=1, alpha=0.3)
disk_mask = r <= 5.0
ax.imshow(np.ma.masked_where(~disk_mask, np.ones_like(patch_norm)), cmap="cool")
ax.set_title("Death: the interior disk\nfills the hole at $t=1.0$", fontsize=9)
ax.set_xticks([]); ax.set_yticks([])

ax = axes[1, 2]
f1 = pd1.finite()
ax.scatter(f1[:, 0], f1[:, 1], s=80, c="#8e44ad", edgecolor="k", zorder=3)
lims = [-0.3, patch.max() + 0.6]
ax.plot(lims, lims, "k--", linewidth=0.8)
ax.annotate("(birth=0.0, death=5.0)\nexact hand-derived ground truth",
            xy=(f1[0, 0], f1[0, 1]), xytext=(1.2, 3.0),
            arrowprops=dict(arrowstyle="->", color="gray"), fontsize=7.5)
ax.set_xlim(lims); ax.set_ylim(lims)
ax.set_xlabel("birth"); ax.set_ylabel("death")
ax.set_title("$H_1$ persistence diagram", fontsize=9)

ax = axes[1, 3]
img1 = persistence_image(pd1, birth_range=(0.0, 5.0), pers_range=(0.0, 5.0), resolution=8)
im = ax.imshow(img1, origin="lower", cmap="magma", extent=[0, 5, 0, 5])
ax.set_xlabel("birth"); ax.set_ylabel("persistence")
ax.set_title("Persistence image\n(vectorized descriptor input)", fontsize=9)
plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

fig.suptitle("Topological evolution of a local patch through the sublevel-set filtration\n"
             "(analytic annulus patch, exact ground truth: $H_1$ birth=0.0, death=5.0)",
             fontsize=11, y=1.02)
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure3.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
