"""
complexity_scaling.py -- measured cost of the persistence computation as a
function of patch side s (from-scratch bit-packed reduction and GUDHI), on
200 Harris-keypoint patches of the Oxford-Affine reference images.
Usage: python complexity_scaling.py /path/to/oxford out.json
"""
import sys, os, json, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
import numpy as np
from phdesc import harris_keypoints
from phdesc.descriptor import extract_patch
from phdesc.persistence import compute_persistence_diagrams
from mc_measurement import load_resized

root, out = sys.argv[1], sys.argv[2]
imgs = [load_resized(os.path.join(root, s, "img1.png")) for s in ("bikes", "graf", "trees", "wall")]
kps = [harris_keypoints(im, max_keypoints=50, min_distance=8) for im in imgs]
res = {}
for s in (8, 16, 24, 32, 48, 64):
    patches = [extract_patch(im, y, x, s) for im, kp in zip(imgs, kps) for (y, x) in kp]
    cells = s * s + 2 * s * (s - 1) + (s - 1) ** 2
    row = {"cells": cells}
    for be in ("bitpacked", "gudhi"):
        t0 = time.perf_counter()
        npts = 0
        for P in patches:
            d0, d1 = compute_persistence_diagrams(P, backend=be)
            npts += len(d0.pairs) + len(d1.pairs)
        row[be + "_ms"] = 1000 * (time.perf_counter() - t0) / len(patches)
    _, d1 = compute_persistence_diagrams(patches[0], backend="gudhi")
    nz = []
    for P in patches:
        d0, d1 = compute_persistence_diagrams(P, backend="gudhi")
        f = [p for p in (d0.finite(), d1.finite())]
        nz.append(sum(int(np.sum(x[:, 1] - x[:, 0] > 0)) for x in f))
    row["offdiag_points_median"] = float(np.median(nz))
    res[str(s)] = row
    print(s, row, flush=True)
json.dump(res, open(out, "w"), indent=1)
