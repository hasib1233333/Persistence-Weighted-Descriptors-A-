import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import ndimage as ndi

from synthetic_validation import make_synthetic_scene

base = make_synthetic_scene(size=160, n_shapes=30, seed=7)

def rotate(img, deg):
    return ndi.rotate(img, deg, reshape=False, mode="reflect")

def scale(img, factor):
    zoomed = ndi.zoom(img, factor, mode="reflect")
    h, w = zoomed.shape
    out = np.zeros_like(img)
    if factor >= 1.0:
        y0, x0 = (h - img.shape[0]) // 2, (w - img.shape[1]) // 2
        out = zoomed[y0:y0 + img.shape[0], x0:x0 + img.shape[1]]
    else:
        y0, x0 = (img.shape[0] - h) // 2, (img.shape[1] - w) // 2
        out[y0:y0 + h, x0:x0 + w] = zoomed
    return out

def blur(img, sigma):
    return ndi.gaussian_filter(img, sigma)

def jpeg_like(img, block=8, keep_frac=0.15):
    # crude illustrative block-DCT-truncation artefact (not a real JPEG codec)
    out = img.copy()
    H, W = img.shape
    from scipy.fft import dctn, idctn
    for y in range(0, H - block + 1, block):
        for x in range(0, W - block + 1, block):
            blk = img[y:y + block, x:x + block]
            c = dctn(blk, norm="ortho")
            mask = np.zeros_like(c)
            k = max(1, int(block * keep_frac))
            mask[:k, :k] = 1
            out[y:y + block, x:x + block] = idctn(c * mask, norm="ortho")
    return out

def illuminate(img, gamma):
    return np.clip(img, 1e-6, 1.0) ** gamma

def affine_shear(img, shear=0.3):
    from skimage.transform import AffineTransform, warp
    t = AffineTransform(shear=shear)
    return warp(img, t.inverse, mode="reflect")

panels = [
    ("Original", base),
    ("Rotation (25\u00b0)", rotate(base, 25)),
    ("Scale (1.4\u00d7)", scale(base, 1.4)),
    ("Blur (\u03c3=2.5px)", blur(base, 2.5)),
    ("JPEG-like block loss", jpeg_like(base)),
    ("Illumination (\u03b3=2.2)", illuminate(base, 2.2)),
    ("Affine (shear)", affine_shear(base)),
]

fig, axes = plt.subplots(1, len(panels), figsize=(17, 2.6))
for ax, (title, img) in zip(axes, panels):
    ax.imshow(np.clip(img, 0, 1), cmap="gray")
    ax.set_title(title, fontsize=9)
    ax.set_xticks([]); ax.set_yticks([])

fig.suptitle("Illustration of the Oxford-Affine benchmark's six distortion axes "
             "(Mikolajczyk et al., 2005), applied here to our own synthetic scene "
             "for illustration only -- NOT the real Oxford-Affine images, which are "
             "not redistributed with this package", fontsize=9.5, y=1.18)
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure7.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
