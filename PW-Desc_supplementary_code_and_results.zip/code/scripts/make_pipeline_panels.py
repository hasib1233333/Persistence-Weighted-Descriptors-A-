"""
make_pipeline_panels.py
=======================

Computes the real panels embedded in the TikZ schematics of Figs. 1 and 2
(input image, multi-scale patches, rank-normalized patch, sublevel sets,
persistence diagrams, birth-persistence plane with the thresholded ramp
weight, persistence images, descriptor strip). Every panel is computed by
the released code from scikit-image's public-domain 'camera' image; the
schematic around it is drawn in TikZ (figures/fig1_pipeline.tex,
figures/fig2_construction.tex). Monochrome output, serif fonts.

Usage: python make_pipeline_panels.py out_dir [tau]
"""
import sys, os, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from skimage import data

from phdesc import harris_keypoints
from phdesc.descriptor import extract_patch, rank_normalize_patch, persistence_image, DescriptorConfig, compute_pw_descriptor
from phdesc.persistence import compute_persistence_diagrams

plt.rcParams.update({
    "font.family": "STIXGeneral", "mathtext.fontset": "stix", "font.size": 9,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5, "savefig.dpi": 600,
    "pdf.fonttype": 42,
})


def save_image(arr, path, vmin=0, vmax=1, cmap="gray", grid=False):
    h, w = arr.shape
    fig = plt.figure(figsize=(1.0, 1.0 * h / w))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.imshow(arr, cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
    if grid:
        for k in range(1, w):
            ax.axvline(k - 0.5, color="0.6", lw=0.25)
        for k in range(1, h):
            ax.axhline(k - 0.5, color="0.6", lw=0.25)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(0.6); s.set_color("black")
    fig.savefig(path, bbox_inches="tight", pad_inches=0.0)
    plt.close(fig)


def finite(pd):
    p = pd.finite()
    return p[(p[:, 1] - p[:, 0]) > 0] if len(p) else np.zeros((0, 2))


def main():
    out = sys.argv[1]
    tau = float(sys.argv[2]) if len(sys.argv) > 2 else 0.0
    os.makedirs(out, exist_ok=True)
    img = data.camera().astype(np.float64) / 255.0
    cands = harris_keypoints(img, max_keypoints=60, min_distance=16)
    # choose the keypoint whose 32-px patch has the most H1 features with persistence > 0.1
    best, best_score = None, -1
    for (y, x) in cands:
        if not (110 < y < 400 and 110 < x < 420):
            continue
        _, d1 = compute_persistence_diagrams(extract_patch(img, y, x, 32), backend="gudhi")
        f = finite(d1)
        score = int(np.sum(f[:, 1] - f[:, 0] > 0.1)) if len(f) else 0
        if score > best_score:
            best, best_score = (int(y), int(x)), score
    y, x = best

    # input image with the keypoint and the three patch windows
    fig = plt.figure(figsize=(1.4, 1.4))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.imshow(img, cmap="gray", vmin=0, vmax=1)
    ax.set_xticks([]); ax.set_yticks([])
    fig.savefig(os.path.join(out, "p_input.pdf"), bbox_inches="tight", pad_inches=0.0)
    plt.close(fig)

    patches = {s: extract_patch(img, y, x, s) for s in (16, 24, 32)}
    for s, P in patches.items():
        save_image(P, os.path.join(out, f"p_patch{s}.pdf"))
    P = patches[32]
    R = rank_normalize_patch(P)
    save_image(R, os.path.join(out, "p_rank32.pdf"))

    d0, d1 = compute_persistence_diagrams(P, backend="gudhi")
    f0, f1 = finite(d0), finite(d1)
    # thresholds: quantiles of the patch values chosen to show components merging and a loop
    ts = np.quantile(P, [0.2, 0.4, 0.6, 0.8])
    for i, t in enumerate(ts):
        save_image((P <= t).astype(float), os.path.join(out, f"p_sub{i}.pdf"), cmap="gray_r")
    json.dump({"keypoint_yx": [y, x], "image_shape": list(img.shape), "thresholds": [float(t) for t in ts],
               "n_h0": int(len(f0)), "n_h1": int(len(f1)), "tau": tau},
              open(os.path.join(out, "panels_meta.json"), "w"), indent=1)

    # persistence diagram (birth, death), H0 filled circles, H1 open triangles
    lo = float(min(P.min(), 0.0)); hi = float(max(P.max(), 1.0))
    fig = plt.figure(figsize=(1.2, 1.2)); ax = fig.add_axes([0, 0, 1, 1])
    ax.plot([0, 1], [0, 1], ls="--", color="black", lw=0.6)
    ax.scatter(f0[:, 0], f0[:, 1], s=9, marker="o", facecolor="black", edgecolor="black", lw=0.5, label=r"$H_0$", zorder=3)
    if len(f1):
        ax.scatter(f1[:, 0], f1[:, 1], s=14, marker="^", facecolor="white", edgecolor="black", lw=0.7, label=r"$H_1$", zorder=3)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_xticks([]); ax.set_yticks([])
    fig.savefig(os.path.join(out, "p_diagram.pdf"), bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)

    # birth-persistence plane with the thresholded ramp weight
    fig = plt.figure(figsize=(1.2, 1.2)); ax = fig.add_axes([0, 0, 1, 1])
    ax.axhspan(0, max(tau, 1e-9), color="0.85", lw=0)
    ax.scatter(f0[:, 0], f0[:, 1] - f0[:, 0], s=9, marker="o", facecolor="black", edgecolor="black", lw=0.5, zorder=3)
    if len(f1):
        ax.scatter(f1[:, 0], f1[:, 1] - f1[:, 0], s=14, marker="^", facecolor="white", edgecolor="black", lw=0.7, zorder=3)
    if tau > 0:
        ax.axhline(tau, color="black", lw=0.6, ls=":")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_xticks([]); ax.set_yticks([])
    fig.savefig(os.path.join(out, "p_birthpers.pdf"), bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)

    # weight function
    fig = plt.figure(figsize=(1.2, 0.8)); ax = fig.add_axes([0, 0, 1, 1])
    pp = np.linspace(0, 1, 200)
    ax.plot(pp, np.clip((pp - tau) / (1 - tau), 0, 1), color="black", lw=0.9)
    ax.set_xlim(0, 1); ax.set_ylim(-0.02, 1.05)
    ax.set_xticks([]); ax.set_yticks([])
    fig.savefig(os.path.join(out, "p_weight.pdf"), bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)

    # persistence images (8 x 8), dark = high density; origin at lower left in (b, p)
    cfg = DescriptorConfig(backend="gudhi", tau=tau)
    pi0 = persistence_image(d0, (0, 1), (0, 1), 8, tau=tau)
    pi1 = persistence_image(d1, (0, 1), (0, 1), 8, tau=tau)
    vmax = max(pi0.max(), pi1.max(), 1e-9)
    save_image(np.flipud(pi0), os.path.join(out, "p_pi0.pdf"), vmin=0, vmax=vmax, cmap="gray_r", grid=True)
    save_image(np.flipud(pi1), os.path.join(out, "p_pi1.pdf"), vmin=0, vmax=vmax, cmap="gray_r", grid=True)

    # descriptor strip (384 values)
    v = compute_pw_descriptor(img, y, x, cfg)
    fig = plt.figure(figsize=(3.0, 0.16))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.imshow(v[None, :], aspect="auto", cmap="gray_r", vmin=0, vmax=v.max(), interpolation="nearest")
    for k in range(1, 6):
        ax.axvline(64 * k - 0.5, color="black", lw=0.6)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(0.6)
    fig.savefig(os.path.join(out, "p_strip.pdf"), bbox_inches="tight", pad_inches=0.0)
    plt.close(fig)
    print("keypoint", best, "H1 features >0.1:", best_score, "n0", len(f0), "n1", len(f1))


if __name__ == "__main__":
    main()


def stability_panels(out, eps=0.05, seed=0):
    """Fig. 2 bottom row: diagrams of P and of P + U[-eps, eps] noise, with the
    l_inf boxes of radius delta = ||P - P'||_inf around the clean points and
    the band p <= 2 delta; every noisy point must lie in their union
    (consequence of Proposition 1). Also |rho(D) - rho(D')| maps."""
    meta = json.load(open(os.path.join(out, "panels_meta.json")))
    y, x = meta["keypoint_yx"]
    img = data.camera().astype(np.float64) / 255.0
    P = extract_patch(img, y, x, 32)
    rng = np.random.default_rng(seed)
    Pn = np.clip(P + rng.uniform(-eps, eps, P.shape), 0, 1)
    delta = float(np.max(np.abs(P - Pn)))
    import gudhi
    stats = {"eps": eps, "delta": delta}
    for k, (dc, dn) in enumerate(zip(compute_persistence_diagrams(P, backend="gudhi"),
                                     compute_persistence_diagrams(Pn, backend="gudhi"))):
        fc, fn_ = finite(dc), finite(dn)
        dB = gudhi.bottleneck_distance(fc, fn_)
        # containment check
        inside = []
        for v in fn_:
            ok = (v[1] - v[0]) <= 2 * delta + 1e-12 or (len(fc) and np.min(np.max(np.abs(fc - v), axis=1)) <= delta + 1e-12)
            inside.append(bool(ok))
        stats[f"H{k}"] = dict(n_clean=int(len(fc)), n_noisy=int(len(fn_)), dB=float(dB), all_inside=bool(all(inside)))
        fig = plt.figure(figsize=(1.2, 1.2)); ax = fig.add_axes([0, 0, 1, 1])
        ax.fill_between([0, 1], [0, 1], [2 * delta, 1 + 2 * delta], color="0.88", lw=0)
        for u in fc:
            if u[1] - u[0] > 2 * delta:
                ax.add_patch(plt.Rectangle((u[0] - delta, u[1] - delta), 2 * delta, 2 * delta, fill=False, ec="0.45", lw=0.4))
        ax.plot([0, 1], [0, 1], ls="--", color="black", lw=0.6)
        mk = "o" if k == 0 else "^"
        ax.scatter(fc[:, 0], fc[:, 1], s=8 if k == 0 else 11, marker=mk, facecolor="black", edgecolor="black", lw=0.4, zorder=3)
        ax.scatter(fn_[:, 0], fn_[:, 1], s=8 if k == 0 else 11, marker=mk, facecolor="white", edgecolor="black", lw=0.5, zorder=4)
        ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.set_xticks([]); ax.set_yticks([])
        fig.savefig(os.path.join(out, f"p_stab_h{k}.pdf"), bbox_inches="tight", pad_inches=0.0)
        plt.close(fig)
        diff = np.abs(persistence_image(dc, (0, 1), (0, 1), 8) - persistence_image(dn, (0, 1), (0, 1), 8))
        stats[f"H{k}"]["pi_diff_max"] = float(diff.max())
        stats[f"H{k}"]["pi_max"] = float(persistence_image(dc, (0, 1), (0, 1), 8).max())
        save_image(np.flipud(diff), os.path.join(out, f"p_pidiff{k}.pdf"), vmin=0,
                   vmax=persistence_image(dc, (0, 1), (0, 1), 8).max(), cmap="gray_r", grid=True)
    save_image(Pn, os.path.join(out, "p_patch32_noisy.pdf"))
    json.dump(stats, open(os.path.join(out, "stability_meta.json"), "w"), indent=1)
    print(stats)


if __name__ == "__main__" and len(sys.argv) > 3 and sys.argv[3] == "stability":
    stability_panels(sys.argv[1])
