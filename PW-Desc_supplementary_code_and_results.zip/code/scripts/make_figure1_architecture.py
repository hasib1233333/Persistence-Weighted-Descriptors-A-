import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(11, 4.2))
ax.set_xlim(0, 11)
ax.set_ylim(0, 4.2)
ax.axis("off")

def box(x, y, w, h, text, fc="#eef3fb", ec="#2c3e6b", fontsize=9.2):
    b = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.06,rounding_size=0.08",
                        linewidth=1.4, edgecolor=ec, facecolor=fc)
    ax.add_patch(b)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fontsize, wrap=True)

def arrow(x0, y0, x1, y1):
    a = FancyArrowPatch((x0, y0), (x1, y1), arrowstyle="-|>", mutation_scale=14,
                         linewidth=1.4, color="#2c3e6b")
    ax.add_patch(a)

# stage boxes
box(0.2, 1.5, 1.6, 1.2, "Input image\n+ keypoint\n(y, x)")
box(2.2, 1.5, 1.9, 1.2, "Multi-scale\npatch extraction\n{P_s} : s in scales")
box(4.5, 1.5, 2.0, 1.2, "Cubical\nsublevel-set\nfiltration")
box(6.9, 1.5, 2.0, 1.2, "Persistence\ndiagrams\nD0(P_s), D1(P_s)")
box(9.3, 2.6, 1.55, 1.1, "Persistence\nimages\nrho(D_k)")
box(9.3, 0.35, 1.55, 1.1, "Concat +\nlinear proj.\nW (spectral norm <= 1)", fontsize=8.2)

arrow(1.8, 2.1, 2.2, 2.1)
arrow(4.1, 2.1, 4.5, 2.1)
arrow(6.5, 2.1, 6.9, 2.1)
arrow(8.9, 2.3, 9.3, 3.0)
arrow(10.07, 2.6, 10.07, 1.45)

ax.text(5.5, 3.85, "PW-Desc: Persistence-Weighted Descriptor pipeline",
        ha="center", va="center", fontsize=12.5, fontweight="bold")
ax.text(5.5, 0.55,
        "Each stage is Lipschitz-continuous in the sup-norm of local intensity "
        "(Prop. 1-2)  \u2192  end-to-end deformation-robustness guarantee",
        ha="center", va="center", fontsize=9, style="italic", color="#444")

plt.tight_layout()
plt.savefig("/home/claude/phdesc_project/paper/figure1.pdf", bbox_inches="tight")
print("saved figure1.pdf")
