"""
learned_native_oxford.py
==========================

Complete-system comparison on Oxford-Affine (8 scenes, 40 pairs): SuperPoint
and DISK, each with its own detector and official released weights, top-K
keypoints per image, mutual nearest-neighbour matching, the same metrics as
benchmark_shared_detector.py (MMA@{1,3,5,10}, matching score, RANSAC
homography corner error). Weights are loaded from local copies of the
official files (SuperPoint: magicleap/SuperPointPretrainedNetwork;
DISK: cvlab-epfl/disk, 'depth' checkpoint); they are not redistributed.

Usage: python learned_native_oxford.py /path/to/hpatches weights_dir out.jsonl [K]
"""
import sys, os, time, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import numpy as np
import cv2
import torch

from benchmark_shared_detector import warp, corner_errors, load_gray, THRESHOLDS

torch.set_num_threads(2)


class SuperPoint:
    def __init__(self, wdir, K):
        sys.path.insert(0, wdir)
        from demo_superpoint import SuperPointFrontend
        self.fe = SuperPointFrontend(os.path.join(wdir, "superpoint_v1.pth"), nms_dist=4,
                                     conf_thresh=0.005, nn_thresh=0.7, cuda=False)
        self.K = K

    def __call__(self, img):
        pts, desc, _ = self.fe.run(img.astype(np.float32))
        if pts.shape[1] == 0:
            return np.zeros((0, 2)), np.zeros((0, 256))
        order = np.argsort(-pts[2])[: self.K]
        return pts[:2, order].T.astype(np.float64), desc[:, order].T.astype(np.float64)


class DISK:
    def __init__(self, wdir, K):
        import kornia.feature as KF
        self.model = KF.DISK()
        sd = torch.load(os.path.join(wdir, "disk_depth-save.pth"), map_location="cpu")
        self.model.load_state_dict(sd["extractor"])
        self.model.eval()
        self.K = K

    def __call__(self, img):
        t = torch.from_numpy(img.astype(np.float32))[None, None].repeat(1, 3, 1, 1)
        with torch.no_grad():
            f = self.model(t, n=self.K, pad_if_not_divisible=True)[0]
        return f.keypoints.numpy().astype(np.float64), f.descriptors.numpy().astype(np.float64)


def mnn(da, db):
    if len(da) == 0 or len(db) == 0:
        return np.zeros((0, 2), dtype=np.int64)
    d = np.linalg.norm(da[:, None, :] - db[None, :, :], axis=2) if len(da) * len(db) < 4e6 else None
    if d is None:
        d2 = (da ** 2).sum(1)[:, None] + (db ** 2).sum(1)[None, :] - 2 * da @ db.T
        d = np.sqrt(np.maximum(d2, 0))
    ab = d.argmin(1)
    ba = d.argmin(0)
    i = np.arange(len(da))
    keep = ba[ab] == i
    return np.stack([i[keep], ab[keep]], axis=1)


def evaluate(xy_a, da, xy_b, db, H_gt, shape_a):
    m = mnn(da, db)
    r = dict(n_matches=int(len(m)))
    if len(m) == 0:
        r.update(mma={str(t): 0.0 for t in THRESHOLDS}, matching_score=0.0, mean_corner_err=None, max_corner_err=None)
        return r
    pa, pb = xy_a[m[:, 0]], xy_b[m[:, 1]]
    err = np.linalg.norm(warp(pa, H_gt) - pb, axis=1)
    r["mma"] = {str(t): float(np.mean(err <= t)) for t in THRESHOLDS}
    r["matching_score"] = float(np.sum(err <= 3) / max(min(len(xy_a), len(xy_b)), 1))
    H_est = None
    if len(m) >= 4:
        H_est, _ = cv2.findHomography(pa, pb, cv2.RANSAC, 3.0, maxIters=2000, confidence=0.999)
    r["mean_corner_err"], r["max_corner_err"] = corner_errors(H_est, H_gt, shape_a)
    return r


def main():
    root, wdir, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
    K = int(sys.argv[4]) if len(sys.argv) > 4 else 1000
    cv2.setNumThreads(1)
    models = {"SuperPoint": SuperPoint(wdir, K), "DISK": DISK(wdir, K)}
    done = set()
    if os.path.exists(out_path):
        done = {json.loads(l)["sequence"] for l in open(out_path)}
    seqs = [s for s in sorted(os.listdir(root)) if os.path.isdir(os.path.join(root, s)) and s not in done]
    t0 = time.time()
    with open(out_path, "a") as f:
        for i, s in enumerate(seqs):
            d = os.path.join(root, s)
            ext = next(e for e in ("png", "ppm", "pgm") if os.path.exists(os.path.join(d, f"img1.{e}")))
            img_a = load_gray(os.path.join(d, f"img1.{ext}"))
            feats_a, times = {}, {}
            for name, mdl in models.items():
                t = time.perf_counter(); feats_a[name] = mdl(img_a); times[name] = [time.perf_counter() - t]
            for k in range(2, 7):
                img_b = load_gray(os.path.join(d, f"img{k}.{ext}"))
                H_gt = np.loadtxt(os.path.join(d, f"H1to{k}p"))
                res = {}
                for name, mdl in models.items():
                    t = time.perf_counter(); xy_b, db = mdl(img_b); times[name].append(time.perf_counter() - t)
                    xy_a, da = feats_a[name]
                    r = evaluate(xy_a, da, xy_b, db, H_gt, img_a.shape)
                    r["n_kp_a"], r["n_kp_b"] = int(len(xy_a)), int(len(xy_b))
                    r["seconds_per_image"] = float(np.mean(times[name]))
                    res[name] = r
                f.write(json.dumps(dict(dataset="oxford", sequence=s, pair=f"{s}_1_{k}", k=k, methods=res)) + "\n")
            f.flush()
            print(f"[{i + 1}/{len(seqs)}] {s} {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
