import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# Real measurements (this repository). SIFT and ORB are now REAL measured
# bars (code/scripts/cpu_stress_suite.py, via OpenCV's real implementations
# run on this CPU) -- no longer shown as "pending", unlike the initial
# version of this figure. SuperPoint/DISK/LoFTR remain genuinely pending:
# they require GPU compute and official checkpoints unavailable here.
measured_methods = ["ORB", "RawPatch", "SIFT", "GradHist", "PW-Desc", "PW-Desc-rank"]
measured_times = [0.0064, 0.04, 0.1232, 1.35, 54.29, 56.85]
measured_colors = ["#7f8c8d", "#e07b39", "#c0392b", "#3fa34d", "#2c6fbb", "#8e44ad"]

pending_methods = ["SuperPoint", "DISK", "LoFTR"]

fig, ax = plt.subplots(figsize=(9.5, 4.2))

x_measured = np.arange(len(measured_methods))
bars = ax.bar(x_measured, measured_times, color=measured_colors, width=0.6, log=True)
for b, t in zip(bars, measured_times):
    ax.text(b.get_x() + b.get_width() / 2, t * 1.15, f"{t:.3f}" if t < 1 else f"{t:.2f}",
            ha="center", fontsize=8.5)

x_pending = np.arange(len(measured_methods), len(measured_methods) + len(pending_methods))
ax.bar(x_pending, [0.001] * len(pending_methods), width=0.6, color="none",
       edgecolor="gray", hatch="///", linestyle="--")
for xp, name in zip(x_pending, pending_methods):
    ax.text(xp, 0.0015, "pending\n(GPU req.)", ha="center", va="bottom", fontsize=7.5,
            color="gray", rotation=0)

ax.set_xticks(list(x_measured) + list(x_pending))
ax.set_xticklabels(measured_methods + pending_methods, rotation=20, ha="right")
ax.set_ylabel("Time per keypoint (ms, log scale)")
ax.set_title("Runtime comparison -- ORB, RawPatch, SIFT, GradHist, PW-Desc, PW-Desc-rank\n"
              "are all REAL measurements from this repository (CPU, single-threaded);\n"
              "only the GPU-only learned baselines remain unmeasured", fontsize=9.5)
ax.set_ylim(0.001, 200)
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure9.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
