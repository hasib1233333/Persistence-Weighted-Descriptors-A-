"""
photometric_robustness.py
===========================

A second, targeted sanity check: nonlinear (gamma) photometric distortion,
which is the regime where PW-Desc's topological-pairing invariance is
theoretically expected to help relative to linearly-normalized baselines
(RawPatch's z-score normalization only buys AFFINE photometric invariance,
not invariance to a nonlinear tone curve; PW-Desc's persistence PAIRING
structure -- which points merge with which -- is exactly preserved under
ANY monotonic transform, though the persistence-IMAGE coordinates used
here are not yet rank-normalized, so this is a genuine, not a rigged,
comparison; see manuscript Sec. 7.2/Limitations for discussion).

Run: python code/scripts/photometric_robustness.py
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
import numpy as np

from phdesc import harris_keypoints, nn_ratio_match, mean_matching_accuracy
from phdesc import baselines
from synthetic_validation import make_synthetic_scene, pw_batch, pw_rank_batch, raw_batch, gradhist_batch


def identity_H():
    return np.eye(3)


def main():
    gammas = [1.0, 0.6, 1.8, 3.0]   # 1.0 = no distortion; others = increasing nonlinearity
    n_scenes = 4
    summary = {}

    for gamma in gammas:
        rows = {"PW-Desc": [], "PW-Desc-rank": [], "RawPatch": [], "GradHist": []}
        for scene_id in range(n_scenes):
            base = make_synthetic_scene(size=160, n_shapes=30, seed=scene_id)
            distorted = np.clip(base, 1e-6, 1.0) ** gamma  # pure per-pixel nonlinear tone curve, no geometry change

            kp_a = harris_keypoints(base, max_keypoints=70, min_distance=8)
            kp_b = harris_keypoints(distorted, max_keypoints=70, min_distance=8)
            if len(kp_a) < 8 or len(kp_b) < 8:
                continue
            H_gt = identity_H()  # no geometric warp: only intensities changed

            for name, fn in [("PW-Desc", pw_batch), ("PW-Desc-rank", pw_rank_batch),
                              ("RawPatch", raw_batch), ("GradHist", gradhist_batch)]:
                da = fn(base, kp_a)
                db = fn(distorted, kp_b)
                matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
                if len(matches) == 0:
                    rows[name].append(0.0)
                    continue
                pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
                pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
                mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
                rows[name].append(mma[3])

        summary[f"gamma={gamma}"] = {k: dict(mean_mma3=float(np.mean(v)) if v else 0.0,
                                              n=len(v)) for k, v in rows.items()}
        print(f"gamma={gamma} done")

    print(json.dumps(summary, indent=2))
    out_path = os.path.join(os.path.dirname(__file__), "photometric_robustness_results.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"Saved -> {out_path}")


if __name__ == "__main__":
    main()
