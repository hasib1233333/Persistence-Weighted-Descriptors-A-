import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

sdir = "/home/claude/phdesc_project/code/scripts"
with open(os.path.join(sdir, "synthetic_validation_results.json")) as f:
    sval = json.load(f)
with open(os.path.join(sdir, "photometric_robustness_results.json")) as f:
    photo = json.load(f)

methods = ["PW-Desc", "PW-Desc-rank", "RawPatch", "GradHist"]
colors = {"PW-Desc": "#2c6fbb", "PW-Desc-rank": "#8e44ad", "RawPatch": "#e07b39", "GradHist": "#3fa34d"}

fig, axes = plt.subplots(1, 2, figsize=(11, 4.3))

# ---- panel A: MMA@3 under homography-only vs homography+elastic --------
ax = axes[0]
regimes = ["homography_only", "homography_plus_elastic"]
x = np.arange(len(regimes))
width = 0.18
for i, m in enumerate(methods):
    vals = [sval[r][m]["mean_mma3"] for r in regimes]
    stds = [sval[r][m]["std_mma3"] for r in regimes]
    ax.bar(x + (i - 1.5) * width, vals, width, yerr=stds, capsize=3, label=m, color=colors[m])
ax.set_xticks(x)
ax.set_xticklabels(["Homography only", "Homography +\nnon-rigid (elastic)"])
ax.set_ylabel("Mean Matching Accuracy @ 3px")
ax.set_title("(a) Synthetic sanity check\n(4 scenes, real measured values)", fontsize=10)
ax.legend(fontsize=8)
ax.set_ylim(0, 1.05)
ax.grid(axis="y", alpha=0.3)

# ---- panel B: MMA@3 vs gamma photometric distortion ---------------------
ax = axes[1]
gammas = sorted([float(k.split("=")[1]) for k in photo.keys()])
for m in methods:
    vals = [photo[f"gamma={g}"][m]["mean_mma3"] for g in gammas]
    ax.plot(gammas, vals, "o-", label=m, color=colors[m])
ax.axvline(1.0, color="gray", linestyle=":", linewidth=1)
ax.set_xlabel("Gamma distortion (1.0 = no distortion)")
ax.set_ylabel("Mean Matching Accuracy @ 3px")
ax.set_title("(b) Nonlinear photometric stress test\n(pure intensity distortion, no geometric warp)", fontsize=10)
ax.legend(fontsize=8)
ax.set_ylim(-0.05, 1.05)
ax.grid(alpha=0.3)

plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure14.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
