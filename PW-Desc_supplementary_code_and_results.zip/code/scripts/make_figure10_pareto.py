import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

sdir = "/home/claude/phdesc_project/code/scripts"
with open(os.path.join(sdir, "synthetic_validation_results.json")) as f:
    sval = json.load(f)
with open(os.path.join(sdir, "real_baseline_comparison_results.json")) as f:
    real_bl = json.load(f)

# All real, measured points (homography-only regime), from this repository.
points = []
for name in ["PW-Desc", "PW-Desc-rank", "RawPatch", "GradHist"]:
    d = sval["homography_only"][name]
    points.append((name, d["mean_ms_per_kp"], d["mean_mma3"]))
for name in ["SIFT (real, OpenCV)", "ORB (real, OpenCV)", "SuperPoint (real, official weights)"]:
    d = real_bl["homography_only"][name]
    points.append((name.split(" (")[0] + (" (real)" if "real" in name else ""),
                    d["mean_ms_per_kp"], d["mean_mma3"]))

fig, ax = plt.subplots(figsize=(8.5, 6))
colors = {"PW-Desc": "#2c6fbb", "PW-Desc-rank": "#8e44ad", "RawPatch": "#e07b39",
          "GradHist": "#3fa34d", "SIFT (real)": "#c0392b", "ORB (real)": "#16a085",
          "SuperPoint (real)": "#d35400"}

for name, ms, mma in points:
    c = colors.get(name, "#333333")
    ax.scatter(ms, mma, s=140, c=c, edgecolor="k", zorder=3)
    ax.annotate(name, (ms, mma), textcoords="offset points", xytext=(7, 5), fontsize=8.5)

ax.set_xscale("log")
ax.set_xlabel("CPU time per keypoint (ms, log scale)")
ax.set_ylabel("MMA@3px (homography-only, synthetic suite)")
ax.set_title("Pareto efficiency: accuracy vs. CPU runtime\n"
              "All points are real measurements from this repository "
              "(SIFT/ORB/SuperPoint via real inference, Sec. 8)", fontsize=10.5)
ax.set_ylim(0, 1.05)
ax.grid(alpha=0.3, which="both")

# annotate the Pareto frontier (points not dominated in both axes)
pts_sorted = sorted(points, key=lambda p: p[1])
frontier = []
best_mma = -1
for name, ms, mma in pts_sorted:
    if mma > best_mma:
        frontier.append((ms, mma))
        best_mma = mma
if len(frontier) > 1:
    fx, fy = zip(*frontier)
    ax.plot(fx, fy, "k--", alpha=0.4, linewidth=1, zorder=1, label="Pareto frontier")
    ax.legend(fontsize=8, loc="lower right")

plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure_pareto.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
for name, ms, mma in points:
    print(f"  {name}: {ms:.3f} ms/kp, MMA@3={mma:.3f}")
