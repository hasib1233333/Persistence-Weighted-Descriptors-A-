"""
controlled_perturbation.py
==========================

Metrological characterization of PW-Desc under controlled, known-magnitude
intensity perturbations on real HPatches images.

Part A (sensitivity, exact ground truth). The reference image of each
selected sequence is perturbed by
  * bounded additive noise  n ~ U[-eps, eps] i.i.d. per pixel, clipped to
    [0,1] (clipping keeps |I_p - I| <= eps), eps in EPS_LIST;
  * gamma remapping I_p = I**gamma (strictly increasing), gamma in GAMMAS.
At K_A Harris keypoints of the clean image, and for each descriptor, it
measures the descriptor drift ||d(P) - d(P')||, the drift normalized by the
descriptor's own discriminability scale (distance from the clean descriptor
to its nearest other clean descriptor in the same image), and the
self-retrieval rate (perturbed descriptor's nearest clean neighbour is its
own keypoint). For PW-Desc it also checks, per keypoint, scale and
homological dimension:
  * CSEH:     d_B(D(P), D(P')) <= ||P - P'||_inf               (theorem)
  * Lemma:    ||x~(P) - x~(P')||_2 <= B(P,P')                  (Prop. 2, unnormalized)
  * Prop. 2:  ||x(P) - x(P')||_2 <= 2 B / max(||x~(P)||, ||x~(P')||)
  * Rank:     ||r(P) - r(P')||_inf <= M_{2 delta}(P) / (N - 1)  (Cor. rank)
and records eta = ||x~(P)||, the quantity that must be bounded away from
zero for the normalized bound.

Part B (propagation to a downstream measurement). For the pair (1, 2) of
each selected sequence, image 2 is perturbed as above and a homography is
estimated from shared-Harris (K_B) matches; the measured quantity is the
mean corner error (pixels) against the ground-truth homography.

Usage: python controlled_perturbation.py /path/to/hpatches out_dir [workers]
"""
import sys, os, time, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import numpy as np
import cv2
import gudhi

from phdesc import harris_keypoints
from phdesc.descriptor import (DescriptorConfig, extract_patch, persistence_image,
                               rank_normalize_patch, compute_pw_descriptors_batch)
from phdesc.persistence import compute_persistence_diagrams
from benchmark_shared_detector import METHODS, match, warp, corner_errors, load_gray

EPS_LIST = [0.005, 0.01, 0.02, 0.05, 0.1]
GAMMAS = [0.5, 0.67, 1.5, 2.0]
EPS_B = [0.02, 0.05, 0.1]
GAMMAS_B = [0.5, 2.0]
K_A, K_B = 100, 300
SCALES = (16, 24, 32)
RES = 8
SIGMA = 1.0 / RES          # persistence_image default: one grid-cell width on [0,1]
L_W = 1.0                  # ramp weight w(p) = clip(p / p_max, 0, 1), p_max = 1
K_PI = 2 * L_W + np.sqrt(5) / (SIGMA * np.sqrt(np.e))   # per-pair constant (Lemma 2)


def finite_nonzero(pd):
    p = pd.finite()
    if len(p) == 0:
        return np.zeros((0, 2))
    p = p[(p[:, 1] - p[:, 0]) > 0]
    return p.reshape(-1, 2)


def pw_blocks(patch_list):
    """Return per-(scale, dim) diagrams and persistence-image blocks."""
    diags, blocks = [], []
    for P in patch_list:
        pd0, pd1 = compute_persistence_diagrams(P, backend="gudhi")
        for pd in (pd0, pd1):
            diags.append(finite_nonzero(pd))
            blocks.append(persistence_image(pd, (0.0, 1.0), (0.0, 1.0), RES).reshape(-1))
    return diags, blocks


def perturb(img, kind, val, rng):
    if kind == "noise":
        return np.clip(img + rng.uniform(-val, val, size=img.shape), 0.0, 1.0)
    return np.power(img, val)


def nn_stats(clean, pert):
    """drift, distance to nearest other clean descriptor, self-retrieval."""
    drift = np.linalg.norm(clean - pert, axis=1)
    d_cc = np.linalg.norm(clean[:, None, :] - clean[None, :, :], axis=2)
    np.fill_diagonal(d_cc, np.inf)
    d_nn = d_cc.min(axis=1)
    d_pc = np.linalg.norm(pert[:, None, :] - clean[None, :, :], axis=2)
    self_ret = np.argmin(d_pc, axis=1) == np.arange(len(clean))
    return drift, d_nn, self_ret


def part_a(seq_dir, seed, img=None):
    """seq_dir: HPatches sequence directory (uses 1.ppm), or None with img given."""
    rng = np.random.default_rng(seed)
    if img is None:
        img = load_gray(os.path.join(seq_dir, "1.ppm"))
    kp = harris_keypoints(img, max_keypoints=K_A, min_distance=8)
    base = {}
    clean_patches = [[extract_patch(img, y, x, s) for s in SCALES] for (y, x) in kp]
    clean_pw = [pw_blocks(ps) for ps in clean_patches]
    clean_rank = [pw_blocks([rank_normalize_patch(p) for p in ps]) for ps in clean_patches]
    xt_clean = np.array([np.concatenate(b) for _, b in clean_pw])
    eta = np.linalg.norm(xt_clean, axis=1)
    x_clean = xt_clean / np.maximum(eta[:, None], 1e-12)
    xr = np.array([np.concatenate(b) for _, b in clean_rank])
    xr_clean = xr / np.maximum(np.linalg.norm(xr, axis=1)[:, None], 1e-12)
    for name in ("SIFT", "RawPatch", "GradHist"):
        base[name] = METHODS[name][0](img, kp)

    out = dict(n_kp=int(len(kp)), eta_min=float(eta.min()), eta_median=float(np.median(eta)),
               perturbations={})
    for kind, vals in (("noise", EPS_LIST), ("gamma", GAMMAS)):
        for v in vals:
            imp = perturb(img, kind, v, rng)
            rec = {}
            cseh_ok = lem_ok = prop_ok = rank_ok = 0
            n_checks_cseh = n_kp = 0
            ratio_db = []      # d_B / ||P - P'||_inf
            tight = []         # normalized drift / certified bound
            bound_vals = []
            rank_infl = []     # ||r(P)-r(P')||_inf / ||P-P'||_inf
            xt_p, xr_p = [], []
            for i, (y, x) in enumerate(kp):
                Pp = [extract_patch(imp, y, x, s) for s in SCALES]
                diags_p, blocks_p = pw_blocks(Pp)
                xtp = np.concatenate(blocks_p)
                xt_p.append(xtp)
                # per-block CSEH check and bound
                B2 = 0.0
                for bi in range(len(blocks_p)):
                    s_idx = bi // 2
                    delta = float(np.max(np.abs(clean_patches[i][s_idx] - Pp[s_idx])))
                    D, Dp = clean_pw[i][0][bi], diags_p[bi]
                    dB = gudhi.bottleneck_distance(D, Dp) if (len(D) + len(Dp)) > 0 else 0.0
                    n_checks_cseh += 1
                    if dB <= delta + 1e-9:
                        cseh_ok += 1
                    if delta > 0:
                        ratio_db.append(dB / delta)
                    B2 += (RES * K_PI * (len(D) + len(Dp)) * delta) ** 2
                B = np.sqrt(B2)
                dt = np.linalg.norm(xt_clean[i] - xtp)
                lem_ok += int(dt <= B + 1e-9)
                etap = np.linalg.norm(xtp)
                bnorm = 2 * B / max(eta[i], etap, 1e-12)
                dn = np.linalg.norm(x_clean[i] - xtp / max(etap, 1e-12))
                prop_ok += int(dn <= bnorm + 1e-9)
                if bnorm > 0:
                    tight.append(dn / bnorm)
                    bound_vals.append(bnorm)
                # rank variant
                rp = [rank_normalize_patch(p) for p in Pp]
                for s_idx, P in enumerate(clean_patches[i]):
                    delta = float(np.max(np.abs(P - Pp[s_idx])))
                    r0 = rank_normalize_patch(P)
                    dr = float(np.max(np.abs(r0 - rp[s_idx])))
                    flat = P.reshape(-1)
                    M = np.max(np.sum(np.abs(flat[:, None] - flat[None, :]) <= 2 * delta, axis=1) - 1)
                    rank_ok += int(dr <= M / (flat.size - 1) + 1e-12)
                    if delta > 0:
                        rank_infl.append(dr / delta)
                _, rb = pw_blocks(rp)
                xr_p.append(np.concatenate(rb))
                n_kp += 1
            xt_p = np.array(xt_p)
            x_p = xt_p / np.maximum(np.linalg.norm(xt_p, axis=1)[:, None], 1e-12)
            xr_p = np.array(xr_p)
            xr_p = xr_p / np.maximum(np.linalg.norm(xr_p, axis=1)[:, None], 1e-12)
            descs = {"PW-Desc": (x_clean, x_p), "PW-Desc-rank": (xr_clean, xr_p)}
            for name in ("SIFT", "RawPatch", "GradHist"):
                descs[name] = (base[name], METHODS[name][0](imp, kp))
            for name, (c, p) in descs.items():
                drift, d_nn, sr = nn_stats(c, p)
                rec[name] = dict(drift_median=float(np.median(drift)),
                                 drift_p95=float(np.percentile(drift, 95)),
                                 drift_max=float(np.max(drift)),
                                 nu_median=float(np.median(drift / np.maximum(d_nn, 1e-12))),
                                 self_retrieval=float(np.mean(sr)))
            rec["checks"] = dict(cseh_pass=cseh_ok, cseh_total=n_checks_cseh,
                                 lemma_pass=lem_ok, prop2_pass=prop_ok, total_kp=n_kp,
                                 rank_pass=rank_ok, rank_total=n_kp * len(SCALES),
                                 dB_over_delta_max=float(np.max(ratio_db)) if ratio_db else 0.0,
                                 dB_over_delta_median=float(np.median(ratio_db)) if ratio_db else 0.0,
                                 tightness_median=float(np.median(tight)) if tight else 0.0,
                                 tightness_max=float(np.max(tight)) if tight else 0.0,
                                 bound_median=float(np.median(bound_vals)) if bound_vals else 0.0,
                                 rank_inflation_median=float(np.median(rank_infl)) if rank_infl else 0.0,
                                 rank_inflation_p95=float(np.percentile(rank_infl, 95)) if rank_infl else 0.0)
            out["perturbations"][f"{kind}_{v}"] = rec
    return out


def part_b(seq_dir, seed):
    rng = np.random.default_rng(seed + 10_000)
    img_a = load_gray(os.path.join(seq_dir, "1.ppm"))
    img_b0 = load_gray(os.path.join(seq_dir, "2.ppm"))
    H_gt = np.loadtxt(os.path.join(seq_dir, "H_1_2"))
    kp_a = harris_keypoints(img_a, max_keypoints=K_B, min_distance=8)
    desc_a = {n: fn(img_a, kp_a) for n, (fn, _) in METHODS.items()}
    out = {}
    conds = [("clean", None)] + [("noise", e) for e in EPS_B] + [("gamma", g) for g in GAMMAS_B]
    for kind, v in conds:
        img_b = img_b0 if kind == "clean" else perturb(img_b0, kind, v, rng)
        kp_b = harris_keypoints(img_b, max_keypoints=K_B, min_distance=8)
        rec = {}
        for name, (fn, binary) in METHODS.items():
            db = fn(img_b, kp_b)
            m = match(desc_a[name], db, binary)
            mce = None
            if len(m) >= 4:
                pa = kp_a[m[:, 0]][:, ::-1].astype(np.float64)
                pb = kp_b[m[:, 1]][:, ::-1].astype(np.float64)
                H, _ = cv2.findHomography(pa, pb, cv2.RANSAC, 3.0, maxIters=2000, confidence=0.999)
                mce, _ = corner_errors(H, H_gt, img_a.shape)
            rec[name] = dict(mean_corner_err=mce, n_matches=int(len(m)))
        out["clean" if kind == "clean" else f"{kind}_{v}"] = rec
    return out


def run(args):
    root, name, idx = args
    cv2.setNumThreads(1)
    d = os.path.join(root, name)
    t0 = time.time()
    a = part_a(d, seed=idx)
    b = part_b(d, seed=idx)
    return dict(sequence=name, part_a=a, part_b=b, seconds=time.time() - t0)


def main():
    root, out_dir = sys.argv[1], sys.argv[2]
    workers = int(sys.argv[3]) if len(sys.argv) > 3 else 2
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "controlled_perturbation.jsonl")
    seqs = sorted(d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d)))
    selected = seqs[::2]   # deterministic half: every second sequence, alphabetical
    done = set()
    if os.path.exists(out_path):
        done = {json.loads(l)["sequence"] for l in open(out_path)}
    todo = [(root, s, seqs.index(s)) for s in selected if s not in done]
    print(f"{len(todo)} sequences to run ({len(selected)} selected)", flush=True)
    from multiprocessing import Pool
    t0 = time.time()
    with Pool(workers) as pool, open(out_path, "a") as f:
        for i, r in enumerate(pool.imap_unordered(run, todo)):
            f.write(json.dumps(r) + "\n")
            f.flush()
            print(f"[{i + 1}/{len(todo)}] {r['sequence']} {r['seconds']:.0f}s total {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
