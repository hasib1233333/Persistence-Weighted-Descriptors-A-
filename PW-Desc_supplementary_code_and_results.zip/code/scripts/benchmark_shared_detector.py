"""
benchmark_shared_detector.py
============================

Descriptor-only benchmark on HPatches (116 sequences, 580 pairs) and
Oxford-Affine (8 scenes, 40 pairs). Every descriptor is computed at the
SAME Harris keypoints (K per image), so differences between methods are
attributable to the descriptor alone.

Per pair it records: MMA@{1,3,5,10} px over mutual-NN ratio-test matches,
number of putative matches, matching score (correct matches at 3 px /
min(#kp_a, #kp_b)), RANSAC homography (OpenCV, 3 px), mean and maximum
corner error of the estimated homography, and descriptor extraction time.

The reference image of each sequence is described once and reused for its
five target images.

Usage:
  python benchmark_shared_detector.py hpatches /path/to/hpatches out.jsonl [K] [workers]
  python benchmark_shared_detector.py oxford   /path/to/oxford   out.jsonl [K] [workers]
Resumable: sequences already present in out.jsonl are skipped.
"""
import sys, os, time, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))

import numpy as np
import cv2

from phdesc import harris_keypoints, nn_ratio_match
from phdesc.descriptor import DescriptorConfig, compute_pw_descriptors_batch
from phdesc import baselines
from phdesc.profiling import cv2_sift_describe, cv2_orb_describe

THRESHOLDS = (1, 3, 5, 10)


def pw(image, kp, rank):
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8, rank_normalize=rank, backend="gudhi")
    return compute_pw_descriptors_batch(image, kp, cfg)


METHODS = {
    "PW-Desc": (lambda im, kp: pw(im, kp, False), False),
    "PW-Desc-rank": (lambda im, kp: pw(im, kp, True), False),
    "SIFT": (cv2_sift_describe, False),
    "RawPatch": (lambda im, kp: baselines.batch_descriptor(baselines.raw_patch_descriptor, im, kp, size=16), False),
    "GradHist": (lambda im, kp: baselines.batch_descriptor(baselines.gradient_histogram_descriptor, im, kp, size=16), False),
    "ORB": (cv2_orb_describe, True),
}


def load_gray(path):
    im = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    return im.astype(np.float64) / 255.0


def sequences(dataset, root):
    out = []
    for name in sorted(os.listdir(root)):
        d = os.path.join(root, name)
        if not os.path.isdir(d):
            continue
        if dataset == "hpatches":
            ref = os.path.join(d, "1.ppm")
            targets = [(k, os.path.join(d, f"{k}.ppm"), os.path.join(d, f"H_1_{k}")) for k in range(2, 7)]
        else:
            ext = next(e for e in ("ppm", "pgm", "png") if os.path.exists(os.path.join(d, f"img1.{e}")))
            ref = os.path.join(d, f"img1.{ext}")
            targets = [(k, os.path.join(d, f"img{k}.{ext}"), os.path.join(d, f"H1to{k}p")) for k in range(2, 7)]
        out.append((name, ref, targets))
    return out


def match(da, db, binary):
    if len(da) == 0 or len(db) == 0:
        return np.zeros((0, 2), dtype=np.int64)
    if binary:
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        ms = bf.match(da, db)
        return np.array([[m.queryIdx, m.trainIdx] for m in ms], dtype=np.int64).reshape(-1, 2)
    return nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)


def warp(pts_xy, H):
    h = np.concatenate([pts_xy, np.ones((len(pts_xy), 1))], axis=1) @ H.T
    return h[:, :2] / (h[:, 2:3] + 1e-12)


def corner_errors(H_est, H_gt, shape):
    h, w = shape
    c = np.array([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]], dtype=np.float64)
    if H_est is None:
        return None, None
    e = np.linalg.norm(warp(c, H_est) - warp(c, H_gt), axis=1)
    return float(e.mean()), float(e.max())


def describe_all(image, kp):
    out = {}
    for name, (fn, _) in METHODS.items():
        t0 = time.perf_counter()
        d = fn(image, kp)
        out[name] = (d, 1000.0 * (time.perf_counter() - t0) / max(len(kp), 1))
    return out


def eval_pair(kp_a, desc_a, kp_b, desc_b, H_gt, shape_a):
    res = {}
    for name, (_, binary) in METHODS.items():
        da, ta = desc_a[name]
        db, tb = desc_b[name]
        m = match(da, db, binary)
        r = dict(n_matches=int(len(m)), ms_per_kp=0.5 * (ta + tb))
        if len(m) == 0:
            r.update(mma={str(t): 0.0 for t in THRESHOLDS}, matching_score=0.0,
                     mean_corner_err=None, max_corner_err=None, n_inliers=0)
            res[name] = r
            continue
        pa = kp_a[m[:, 0]][:, ::-1].astype(np.float64)
        pb = kp_b[m[:, 1]][:, ::-1].astype(np.float64)
        err = np.linalg.norm(warp(pa, H_gt) - pb, axis=1)
        r["mma"] = {str(t): float(np.mean(err <= t)) for t in THRESHOLDS}
        r["matching_score"] = float(np.sum(err <= 3) / max(min(len(kp_a), len(kp_b)), 1))
        H_est, n_in = None, 0
        if len(m) >= 4:
            H_est, mask = cv2.findHomography(pa, pb, cv2.RANSAC, 3.0, maxIters=2000, confidence=0.999)
            n_in = int(mask.sum()) if mask is not None else 0
        mce, xce = corner_errors(H_est, H_gt, shape_a)
        r.update(mean_corner_err=mce, max_corner_err=xce, n_inliers=n_in)
        res[name] = r
    return res


def run_sequence(args):
    dataset, (name, ref_path, targets), K = args
    cv2.setNumThreads(1)
    img_a = load_gray(ref_path)
    kp_a = harris_keypoints(img_a, max_keypoints=K, min_distance=8)
    desc_a = describe_all(img_a, kp_a)
    recs = []
    for k, path, hpath in targets:
        if not (os.path.exists(path) and os.path.exists(hpath)):
            continue
        img_b = load_gray(path)
        H_gt = np.loadtxt(hpath)
        kp_b = harris_keypoints(img_b, max_keypoints=K, min_distance=8)
        desc_b = describe_all(img_b, kp_b)
        res = eval_pair(kp_a, desc_a, kp_b, desc_b, H_gt, img_a.shape)
        recs.append(dict(dataset=dataset, sequence=name, pair=f"{name}_1_{k}", k=k,
                         n_kp_a=int(len(kp_a)), n_kp_b=int(len(kp_b)), methods=res))
    return name, recs


def main():
    dataset, root, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
    K = int(sys.argv[4]) if len(sys.argv) > 4 else 300
    workers = int(sys.argv[5]) if len(sys.argv) > 5 else 2
    done = set()
    if os.path.exists(out_path):
        for line in open(out_path):
            done.add(json.loads(line)["sequence"])
    todo = [s for s in sequences(dataset, root) if s[0] not in done]
    print(f"{dataset}: {len(todo)} sequences to run, {len(done)} already done, K={K}", flush=True)
    from multiprocessing import Pool
    t0 = time.time()
    with Pool(workers) as pool, open(out_path, "a") as f:
        for i, (name, recs) in enumerate(pool.imap_unordered(run_sequence, [(dataset, s, K) for s in todo])):
            for r in recs:
                f.write(json.dumps(r) + "\n")
            f.flush()
            print(f"[{i + 1}/{len(todo)}] {name} {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
