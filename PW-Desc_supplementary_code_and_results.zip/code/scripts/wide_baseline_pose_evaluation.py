"""
wide_baseline_pose_evaluation.py
===================================

Real pose-estimation-AUC evaluation on MegaDepth (and, with a different
loader, ScanNet), following the standard protocol used by SuperGlue/LoFTR:
estimate an essential matrix from matched keypoints (using known
intrinsics), recover relative pose, compare against ground-truth relative
pose (derived from each image's known absolute pose) via angular rotation
and translation-direction error, and compute AUC at 5/10/20 degree
thresholds.

This is a genuinely different protocol from this paper's homography-based
MMA evaluation (Oxford-Affine, HPatches): MegaDepth/ScanNet are 3D
wide-baseline scenes, not planar, so ground truth is a relative pose, not
a 2D homography.

GIVEN THE MEASURED RUNTIME (LoFTR: ~22s/pair on this sandbox's single CPU
core; keypoint-based methods much faster but still nontrivial at scale),
this runs on a SMALL, explicitly-labeled SUBSET of pairs, not the full
1500 -- stated honestly, not represented as the complete standard
benchmark.

Run: python code/scripts/wide_baseline_pose_evaluation.py
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np
import cv2

from phdesc import harris_keypoints, nn_ratio_match
from phdesc.descriptor import DescriptorConfig, compute_pw_descriptors_batch
from phdesc.profiling import cv2_sift_describe, cv2_orb_describe
from phdesc.learned_baselines import SuperPointWrapper, DISKWrapper


def relative_pose_error(R_est, t_est, R_gt, t_gt):
    """Standard SuperGlue-style pose error: max(rotation angular error,
    translation direction angular error), degrees. Translation magnitude
    is unrecoverable from images alone (scale ambiguity), so only
    direction is compared."""
    cos_r = (np.trace(R_est.T @ R_gt) - 1) / 2
    cos_r = np.clip(cos_r, -1, 1)
    rot_err = np.degrees(np.arccos(cos_r))

    t_est_n = t_est.flatten() / (np.linalg.norm(t_est) + 1e-12)
    t_gt_n = t_gt.flatten() / (np.linalg.norm(t_gt) + 1e-12)
    cos_t = np.clip(np.dot(t_est_n, t_gt_n), -1, 1)
    trans_err = np.degrees(np.arccos(np.abs(cos_t)))  # sign-invariant

    return max(rot_err, trans_err)


def pose_auc(errors, thresholds=(5, 10, 20)):
    """AUC of the error CDF up to each threshold, standard SuperGlue metric."""
    errors = np.sort(np.array(errors))
    n = len(errors)
    recall = np.arange(1, n + 1) / n
    aucs = {}
    for t in thresholds:
        idx = np.searchsorted(errors, t)
        if idx == 0:
            aucs[t] = 0.0
            continue
        e = np.concatenate([[0], errors[:idx], [t]])
        r = np.concatenate([[0], recall[:idx], [recall[idx - 1] if idx > 0 else 0]])
        aucs[t] = float(np.trapezoid(r, e) / t)
    return aucs


def load_megadepth_pairs(root, n_pairs=15, seed=0):
    """Load a small, random, reproducible subset of real MegaDepth-1500
    pairs across both available scenes (0015, 0022) and all overlap
    ranges, with real images and real ground-truth poses/intrinsics."""
    rng = np.random.default_rng(seed)
    scene_info_dir = os.path.join(root, "scene_info")
    files = sorted(os.listdir(scene_info_dir))
    pairs = []
    for f in files:
        d = np.load(os.path.join(scene_info_dir, f), allow_pickle=True)
        image_paths, intrinsics, poses, pair_infos = (
            d["image_paths"], d["intrinsics"], d["poses"], d["pair_infos"])
        for (idx0, idx1), overlap, _ in pair_infos:
            p0, p1 = image_paths[idx0], image_paths[idx1]
            if p0 is None or p1 is None:
                continue
            full0 = os.path.join(root, p0)
            full1 = os.path.join(root, p1)
            if not (os.path.exists(full0) and os.path.exists(full1)):
                continue
            pairs.append(dict(img0=full0, img1=full1, K0=intrinsics[idx0],
                               K1=intrinsics[idx1], T0=poses[idx0], T1=poses[idx1],
                               overlap=float(overlap), src=f))
    rng.shuffle(pairs)
    return pairs[:n_pairs]


def load_gray_and_scaled(path, max_side=640):
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    h, w = img.shape
    scale = max_side / max(h, w)
    new_w, new_h = int(w * scale), int(h * scale)
    img_resized = cv2.resize(img, (new_w, new_h))
    K_scale = np.array([[scale, 0, 0], [0, scale, 0], [0, 0, 1]])
    return img_resized.astype(np.float64) / 255.0, K_scale


def estimate_pose_from_matches(pts0, pts1, K0, K1):
    if len(pts0) < 8:
        return None, None, 0
    E, mask = cv2.findEssentialMat(pts0, pts1, cameraMatrix=K0, method=cv2.RANSAC,
                                    prob=0.999, threshold=1.0)
    if E is None:
        return None, None, 0
    _, R, t, mask_pose = cv2.recoverPose(E, pts0, pts1, cameraMatrix=K0, mask=mask)
    n_inliers = int(mask_pose.sum())
    return R, t, n_inliers


def pw_batch(image, keypoints, rank=False, backend="gudhi"):
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8, rank_normalize=rank, backend=backend)
    return compute_pw_descriptors_batch(image, keypoints, cfg)


def evaluate_keypoint_method(pair, describe_fn, binary=False, max_kp=300):
    img0, K0s = load_gray_and_scaled(pair["img0"])
    img1, K1s = load_gray_and_scaled(pair["img1"])
    K0 = K0s @ pair["K0"]
    K1 = K1s @ pair["K1"]

    t0 = time.perf_counter()
    kp0, desc0 = describe_fn(img0, max_kp)
    kp1, desc1 = describe_fn(img1, max_kp)
    dt = time.perf_counter() - t0

    if len(kp0) < 8 or len(kp1) < 8:
        return dict(pose_err=180.0, n_matches=0, dt=dt)

    if binary:
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        m = bf.match(desc0, desc1)
        matches = np.array([[x.queryIdx, x.trainIdx] for x in m]).reshape(-1, 2)
    else:
        matches = nn_ratio_match(desc0, desc1, ratio_thresh=0.9, mutual=True)

    if len(matches) < 8:
        return dict(pose_err=180.0, n_matches=len(matches), dt=dt)

    pts0 = kp0[matches[:, 0]][:, ::-1].astype(np.float64)
    pts1 = kp1[matches[:, 1]][:, ::-1].astype(np.float64)

    R_est, t_est, n_inl = estimate_pose_from_matches(pts0, pts1, K0, K1)
    T_rel = pair["T1"] @ np.linalg.inv(pair["T0"])
    R_gt, t_gt = T_rel[:3, :3], T_rel[:3, 3]

    if R_est is None:
        return dict(pose_err=180.0, n_matches=len(matches), dt=dt)

    err = relative_pose_error(R_est, t_est, R_gt, t_gt)
    return dict(pose_err=err, n_matches=len(matches), n_inliers=n_inl, dt=dt)


def harris_kp(image, max_kp):
    return harris_keypoints(image, max_keypoints=max_kp, min_distance=8)


def main():
    pairs = load_megadepth_pairs("/home/claude/phdesc_project/data/megadepth_test_1500", n_pairs=15, seed=0)
    print(f"Loaded {len(pairs)} real MegaDepth pairs (subset, not full 1500)")
    for p in pairs:
        print(f"  {os.path.basename(p['img0'])} <-> {os.path.basename(p['img1'])} (overlap={p['overlap']:.2f})")

    sp = SuperPointWrapper()
    disk = DISKWrapper(n_keypoints=300)

    def pw_method(im, mkp, rank):
        kp = harris_kp(im, mkp)
        desc = pw_batch(im, kp, rank=rank)
        return kp, desc

    def sift_method(im, mkp):
        kp = harris_kp(im, mkp)
        desc = cv2_sift_describe(im, kp)
        return kp, desc

    methods = {
        "PW-Desc": lambda im, mkp: pw_method(im, mkp, rank=False),
        "PW-Desc-rank": lambda im, mkp: pw_method(im, mkp, rank=True),
        "SIFT": sift_method,
        "SuperPoint": lambda im, mkp: sp.detect_and_describe(im),
        "DISK": lambda im, mkp: disk.detect_and_describe(im),
    }
    binary_methods = set()

    results = {name: [] for name in methods}
    for i, pair in enumerate(pairs):
        print(f"\n[{i+1}/{len(pairs)}] {pair['src']}")
        for name, fn in methods.items():
            t0 = time.time()
            try:
                out = evaluate_keypoint_method(pair, fn, binary=name in binary_methods)
            except Exception as e:
                print(f"    {name}: ERROR {e}")
                out = dict(pose_err=180.0, n_matches=0, dt=0)
            results[name].append(out)
            print(f"    {name}: pose_err={out['pose_err']:.1f} deg, "
                  f"n_matches={out['n_matches']}, {time.time()-t0:.1f}s")
        with open(os.path.join(os.path.dirname(__file__), "megadepth_subset_results.json"), "w") as f:
            json.dump(results, f, indent=2)

    print("\n=== SUMMARY (subset, n={}) ===".format(len(pairs)))
    summary = {}
    for name, res in results.items():
        errs = [r["pose_err"] for r in res]
        aucs = pose_auc(errs)
        summary[name] = dict(auc5=aucs[5], auc10=aucs[10], auc20=aucs[20],
                              mean_matches=float(np.mean([r["n_matches"] for r in res])),
                              median_pose_err=float(np.median(errs)))
        print(name, summary[name])
    with open(os.path.join(os.path.dirname(__file__), "megadepth_subset_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)


if __name__ == "__main__":
    main()
