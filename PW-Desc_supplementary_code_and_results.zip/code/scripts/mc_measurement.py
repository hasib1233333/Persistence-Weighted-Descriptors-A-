"""
mc_measurement.py
=================

Calibrated measurement experiment with known reference values, evaluated by
Monte Carlo propagation in the sense of GUM Supplement 1 (JCGM 101:2008).

Measurement task: planar image registration used for dimensional mapping.
A real reference image I (img1 and img4 of the eight Oxford-Affine scenes,
16 photographs, resized to 640 px on the long side and quantized to 8 bits) is mapped by a KNOWN
homography H drawn at random (rotation U[-15,15] deg, scale U[0.85,1.15],
aspect U[0.95,1.05], perspective +-1e-4 per pixel, centred), producing the
target J = warp(I, H). An intensity disturbance of KNOWN magnitude is then
applied to J (none; bounded uniform noise eps; gamma), and J is re-quantized
to 8 bits, as an 8-bit camera would deliver it. (Part A applies the same
perturbations without re-quantization, to test the propositions exactly.) The measuring system
detects Harris corners (K = 300, shared by all descriptors), describes them,
matches them and estimates H_hat by RANSAC. The measurand is the position, in
the target image, of a 5 x 5 grid of reference points covering the central
60 % of I; the measurement error of one trial is the target registration
error TRE = mean_i ||H_hat(p_i) - H(p_i)|| in pixels.

The same random homographies (common random numbers) are used for every
descriptor and every disturbance, so comparisons are paired.

Part A of controlled_perturbation.py (descriptor sensitivity and verification
of the certified bounds) is run on the same 16 reference images.

Usage: python mc_measurement.py /path/to/oxford_dir out_dir [trials] [workers]
"""
import sys, os, time, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import numpy as np
import cv2

from phdesc import harris_keypoints
from benchmark_shared_detector import METHODS, match, warp
import controlled_perturbation as CP

CONDITIONS = [("clean", None), ("noise", 0.02), ("noise", 0.05), ("noise", 0.1), ("gamma", 0.5), ("gamma", 2.0)]
LONG_SIDE = 640
RUN_PART_A = True
K = 300


def load_resized(path):
    im = cv2.imread(path, cv2.IMREAD_GRAYSCALE).astype(np.float64) / 255.0
    h, w = im.shape
    s = LONG_SIDE / max(h, w)
    im = cv2.resize(im, (round(w * s), round(h * s)), interpolation=cv2.INTER_AREA)
    return quantize(im)


def quantize(im):
    """8-bit quantization, as delivered by an 8-bit camera."""
    return np.round(np.clip(im, 0, 1) * 255.0) / 255.0


def random_homography(rng, shape):
    h, w = shape
    c = np.array([[1, 0, -w / 2], [0, 1, -h / 2], [0, 0, 1.0]])
    th = np.deg2rad(rng.uniform(-15, 15))
    s = rng.uniform(0.85, 1.15)
    a = rng.uniform(0.95, 1.05)
    A = np.array([[s * a * np.cos(th), -s * np.sin(th), 0], [s * a * np.sin(th), s * np.cos(th), 0], [0, 0, 1.0]])
    P = np.eye(3)
    P[2, :2] = rng.uniform(-1e-4, 1e-4, 2)
    return np.linalg.inv(c) @ P @ A @ c


def grid_points(shape, n=5, frac=0.6):
    h, w = shape
    xs = np.linspace(w * (1 - frac) / 2, w * (1 + frac) / 2, n)
    ys = np.linspace(h * (1 - frac) / 2, h * (1 + frac) / 2, n)
    return np.array([[x, y] for y in ys for x in xs])


def disturb(img, kind, v, rng):
    """Disturbance followed by 8-bit re-quantization (realistic sensor output)."""
    if kind == "clean":
        return img
    if kind == "noise":
        return quantize(img + rng.uniform(-v, v, img.shape))
    if kind == "blur":
        return quantize(cv2.GaussianBlur(img, (0, 0), v))
    if kind == "jpeg":
        ok, buf = cv2.imencode(".jpg", np.round(img * 255).astype(np.uint8), [cv2.IMWRITE_JPEG_QUALITY, int(v)])
        return cv2.imdecode(buf, cv2.IMREAD_GRAYSCALE).astype(np.float64) / 255.0
    return quantize(np.power(img, v))


T_START = 0


def run_image(args):
    path, idx, trials = args
    cv2.setNumThreads(1)
    t0 = time.time()
    I = load_resized(path)
    out = {"image": path, "shape": list(I.shape)}
    # Part A: descriptor metrology on the reference image
    if RUN_PART_A:
        out["part_a"] = CP.part_a(None, seed=1000 + idx, img=I)
    # Monte Carlo registration
    kp_a = harris_keypoints(I, max_keypoints=K, min_distance=8)
    desc_a = {n: fn(I, kp_a) for n, (fn, _) in METHODS.items()}
    grid = grid_points(I.shape)
    trials_out = []
    for t in range(T_START, T_START + trials):
        rng_h = np.random.default_rng(10_000 * idx + t)
        H = random_homography(rng_h, I.shape)
        J0 = quantize(cv2.warpPerspective(I, H, (I.shape[1], I.shape[0]), flags=cv2.INTER_LINEAR,
                                          borderMode=cv2.BORDER_CONSTANT, borderValue=0))
        gt = warp(grid, H)
        for kind, v in CONDITIONS:
            rng_n = np.random.default_rng(20_000 * idx + 100 * t + (0 if v is None else int(1000 * v)))
            J = disturb(J0, kind, v, rng_n)
            kp_b = harris_keypoints(J, max_keypoints=K, min_distance=8)
            rec = {"trial": t, "condition": kind if v is None else f"{kind}_{v}"}
            for name, (fn, binary) in METHODS.items():
                m = match(desc_a[name], fn(J, kp_b), binary)
                tre, n_in = None, 0
                if len(m) >= 4:
                    pa = kp_a[m[:, 0]][:, ::-1].astype(np.float64)
                    pb = kp_b[m[:, 1]][:, ::-1].astype(np.float64)
                    He, mask = cv2.findHomography(pa, pb, cv2.RANSAC, 3.0, maxIters=2000, confidence=0.999)
                    if He is not None:
                        tre = float(np.mean(np.linalg.norm(warp(grid, He) - gt, axis=1)))
                        n_in = int(mask.sum())
                rec[name] = {"tre": tre, "n_matches": int(len(m)), "n_inliers": n_in}
            trials_out.append(rec)
    out["mc"] = trials_out
    out["seconds"] = time.time() - t0
    return out


def main():
    root, out_dir = sys.argv[1], sys.argv[2]
    trials = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    workers = int(sys.argv[4]) if len(sys.argv) > 4 else 2
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "mc_measurement.jsonl")
    imgs = []
    for s in sorted(os.listdir(root)):
        for k in (1, 4):
            p = next((os.path.join(root, s, f"img{k}.{e}") for e in ("png", "ppm", "pgm")
                      if os.path.exists(os.path.join(root, s, f"img{k}.{e}"))), None)
            if p:
                imgs.append(p)
    done = set()
    if os.path.exists(out_path):
        done = {json.loads(l)["image"] for l in open(out_path)}
    todo = [(p, i, trials) for i, p in enumerate(imgs) if p not in done]
    print(f"{len(todo)} images to run of {len(imgs)}", flush=True)
    from multiprocessing import Pool
    t0 = time.time()
    with Pool(workers) as pool, open(out_path, "a") as f:
        for i, r in enumerate(pool.imap_unordered(run_image, todo)):
            f.write(json.dumps(r) + "\n"); f.flush()
            print(f"[{i + 1}/{len(todo)}] {r['image']} {r['seconds']:.0f}s total {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
