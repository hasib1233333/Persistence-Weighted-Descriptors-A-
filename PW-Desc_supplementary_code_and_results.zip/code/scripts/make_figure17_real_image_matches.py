import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from phdesc import harris_keypoints, nn_ratio_match, geometric_verify_homography
from real_image_validation import load_real_image, pw_batch
from synthetic_validation import random_homography, warp_image

fig, axes = plt.subplots(2, 2, figsize=(12, 10))
examples = [("camera", 501), ("coffee", 601), ("retina", 502), ("chelsea", 602)]

for ax, (name, seed) in zip(axes.flat, examples):
    base = load_real_image(name)
    H_gt = random_homography(base.shape[0], max_shift=int(0.08 * base.shape[0]), seed=seed)
    warped = np.clip(warp_image(base, H_gt), 0, 1)

    kp_a = harris_keypoints(base, max_keypoints=40, min_distance=8)
    kp_b = harris_keypoints(warped, max_keypoints=40, min_distance=8)
    da = pw_batch(base, kp_a)
    db = pw_batch(warped, kp_b)
    matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)

    canvas = np.concatenate([base, np.ones((base.shape[0], 4)), warped], axis=1)
    ax.imshow(canvas, cmap="gray")
    offset = base.shape[1] + 4

    if len(matches):
        pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
        pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
        H_est, inliers = geometric_verify_homography(pts_a, pts_b)
        n_in = int(np.sum(inliers)) if inliers is not None else 0
        for i, (a_idx, b_idx) in enumerate(matches):
            y1, x1 = kp_a[a_idx]
            y2, x2 = kp_b[b_idx]
            is_in = bool(inliers[i]) if inliers is not None and i < len(inliers) else False
            color = "#2ecc71" if is_in else "#e74c3c"
            ax.plot([x1, x2 + offset], [y1, y2], color=color, linewidth=0.6, alpha=0.7)
            ax.plot(x1, y1, "o", color=color, markersize=2.5)
            ax.plot(x2 + offset, y2, "o", color=color, markersize=2.5)
        title = f"{name}: {len(matches)} matches, {n_in} inliers (real photograph)"
    else:
        title = f"{name}: 0 matches (real photograph)"
    ax.set_title(title, fontsize=10)
    ax.axis("off")

fig.suptitle("PW-Desc matches on real (non-synthetic) photographs, real computed output\n"
             "(green = RANSAC inlier, red = outlier; scikit-image bundled images)", fontsize=11.5, y=1.01)
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure18.pdf"
plt.savefig(out, bbox_inches="tight", dpi=220)
print("saved", out)
