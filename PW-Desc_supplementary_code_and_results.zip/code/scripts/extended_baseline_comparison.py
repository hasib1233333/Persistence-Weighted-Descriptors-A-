"""
extended_baseline_comparison.py
=================================

Real, measured comparison extending the existing SIFT/ORB baselines with
BRISK, AKAZE, and KAZE (all real OpenCV implementations), reporting
MMA@3, precision, recall, F1, RANSAC inlier ratio, and runtime -- plus
real memory profiling (descriptor size in bytes, measured via
sys.getsizeof/nbytes; peak RAM during extraction and matching, measured
via tracemalloc).

Run: python code/scripts/extended_baseline_comparison.py
"""
import sys, os, time, json, tracemalloc
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np

from phdesc import harris_keypoints, nn_ratio_match, mean_matching_accuracy, DescriptorConfig
from phdesc import compute_pw_descriptors_batch
from phdesc.profiling import (cv2_sift_describe, cv2_orb_describe,
                               cv2_brisk_detect_and_describe, cv2_akaze_detect_and_describe,
                               cv2_kaze_detect_and_describe)
from synthetic_validation import make_synthetic_scene, random_homography, warp_image
import cv2


def precision_recall_f1(pts_a, pts_b, H_gt, thresh=3.0):
    """Precision/recall/F1 of the putative-match set against the
    ground-truth correspondence set, following standard practice: a
    putative match is a true positive if its reprojection error under
    H_gt is within `thresh` pixels. Since every putative match is
    evaluated (there's no separate "ground truth match count" beyond
    what a perfect matcher would find at this keypoint set), recall here
    is computed against the maximum matchable set: keypoints in A that
    have a real correspondence in B within `thresh` px after warping
    (the repeatable set), following the same convention as repeatability."""
    if len(pts_a) == 0:
        return 0.0, 0.0, 0.0
    ones = np.ones((len(pts_a), 1))
    warped = np.concatenate([pts_a, ones], axis=1) @ H_gt.T
    warped = warped[:, :2] / (warped[:, 2:3] + 1e-12)
    err = np.linalg.norm(warped - pts_b, axis=1)
    tp = np.sum(err <= thresh)
    precision = tp / len(pts_a)
    return precision, tp, len(pts_a)  # recall computed by caller (needs repeatable-set denominator)


def match_binary(da, db):
    if len(da) == 0 or len(db) == 0:
        return np.zeros((0, 2), dtype=np.int64)
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = bf.match(da, db)
    return np.array([[m.queryIdx, m.trainIdx] for m in matches], dtype=np.int64).reshape(-1, 2)


def match_real(da, db):
    m = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
    return m


METHODS_JOINT = {
    # name -> (detect_and_describe_fn(image, max_kp) -> (coords_yx, desc), is_binary)
    "BRISK": (cv2_brisk_detect_and_describe, True),
    "AKAZE": (cv2_akaze_detect_and_describe, True),
    "KAZE": (cv2_kaze_detect_and_describe, False),
}


def run_joint_detector_comparison(n_scenes=4, max_kp=60):
    """BRISK/AKAZE/KAZE use their own native detector (required, per the
    detectAndCompute constraint documented in phdesc/profiling.py), so
    this is evaluated under each method's NATIVE detector, not the shared
    Harris protocol used elsewhere -- documented explicitly, matching the
    manuscript's own distinction between primary (shared-detector) and
    secondary (native-detector) protocols."""
    results = {name: {"mma3": [], "precision": [], "recall": [], "f1": [],
                       "inlier_ratio": [], "ms_per_kp": [], "n_matches": []}
               for name in METHODS_JOINT}

    for seed in range(n_scenes):
        base = make_synthetic_scene(size=160, n_shapes=30, seed=seed)
        H_gt = random_homography(160, max_shift=14, seed=200 + seed)
        warped = np.clip(warp_image(base, H_gt), 0, 1)

        for name, (fn, is_binary) in METHODS_JOINT.items():
            t0 = time.perf_counter()
            kp_a, da = fn(base, max_kp)
            kp_b, db = fn(warped, max_kp)
            dt = time.perf_counter() - t0
            n_kp = len(kp_a) + len(kp_b)
            ms_per_kp = 1000 * dt / max(n_kp, 1)

            if len(kp_a) < 4 or len(kp_b) < 4:
                continue

            matches = match_binary(da, db) if is_binary else match_real(da, db)
            n_matches = len(matches)
            if n_matches == 0:
                for k in results[name]:
                    results[name][k].append(0.0)
                continue

            pts_a = kp_a[matches[:, 0]][:, ::-1]
            pts_b = kp_b[matches[:, 1]][:, ::-1]
            mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))

            from phdesc import geometric_verify_homography
            H_est, inliers = geometric_verify_homography(pts_a, pts_b)
            inlier_ratio = float(np.mean(inliers)) if len(inliers) else 0.0

            precision, tp, n_putative = precision_recall_f1(pts_a, pts_b, H_gt, thresh=3.0)
            # recall: fraction of the REPEATABLE keypoint set (kp_a with a
            # real match in kp_b within 3px after warping) that was
            # actually found among the putative matches
            from phdesc import repeatability as rep_fn
            ones = np.ones((len(kp_a), 1))
            kp_a_xy = kp_a[:, ::-1]
            warped_all = np.concatenate([kp_a_xy, ones], axis=1) @ H_gt.T
            warped_all = warped_all[:, :2] / (warped_all[:, 2:3] + 1e-12)
            kp_b_xy = kp_b[:, ::-1]
            d = np.linalg.norm(warped_all[:, None, :] - kp_b_xy[None, :, :], axis=2)
            repeatable_mask = np.any(d <= 3.0, axis=1)
            n_repeatable = int(np.sum(repeatable_mask))
            recall = tp / n_repeatable if n_repeatable > 0 else 0.0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

            results[name]["mma3"].append(mma[3])
            results[name]["precision"].append(float(precision))
            results[name]["recall"].append(float(recall))
            results[name]["f1"].append(float(f1))
            results[name]["inlier_ratio"].append(inlier_ratio)
            results[name]["ms_per_kp"].append(ms_per_kp)
            results[name]["n_matches"].append(n_matches)

        print(f"  scene {seed+1}/{n_scenes} done")

    summary = {}
    for name, metrics in results.items():
        summary[name] = {k: (float(np.mean(v)) if v else 0.0) for k, v in metrics.items()}
        summary[name]["std_mma3"] = float(np.std(metrics["mma3"])) if metrics["mma3"] else 0.0
    return summary


def run_memory_analysis(max_kp=60):
    """Real memory profiling via tracemalloc: peak RAM during descriptor
    extraction and during matching, plus descriptor size in bytes
    (measured via .nbytes, not estimated)."""
    scene = make_synthetic_scene(size=160, n_shapes=30, seed=0)
    warped = np.clip(warp_image(scene, random_homography(160, max_shift=14, seed=300)), 0, 1)
    kp_a_harris = harris_keypoints(scene, max_keypoints=max_kp, min_distance=8)
    kp_b_harris = harris_keypoints(warped, max_keypoints=max_kp, min_distance=8)

    results = {}

    def profile_extraction(name, fn, *args):
        tracemalloc.start()
        t0 = time.perf_counter()
        out = fn(*args)
        dt = time.perf_counter() - t0
        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        return out, dt, peak

    # PW-Desc
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8)
    (da,), dt, peak = profile_extraction("PW-Desc", lambda: (compute_pw_descriptors_batch(scene, kp_a_harris, cfg),))
    results["PW-Desc"] = dict(descriptor_bytes_per_kp=int(da.nbytes / max(len(da), 1)),
                               peak_extraction_kb=peak / 1024, extraction_ms=dt * 1000)

    # SIFT (real)
    (da,), dt, peak = profile_extraction("SIFT", lambda: (cv2_sift_describe(scene, kp_a_harris),))
    results["SIFT"] = dict(descriptor_bytes_per_kp=int(da.nbytes / max(len(da), 1)),
                            peak_extraction_kb=peak / 1024, extraction_ms=dt * 1000)

    # ORB (real)
    (da,), dt, peak = profile_extraction("ORB", lambda: (cv2_orb_describe(scene, kp_a_harris),))
    results["ORB"] = dict(descriptor_bytes_per_kp=int(da.nbytes / max(len(da), 1)),
                           peak_extraction_kb=peak / 1024, extraction_ms=dt * 1000)

    # BRISK/AKAZE/KAZE (real, native detector + descriptor combined)
    for name, fn in [("BRISK", cv2_brisk_detect_and_describe),
                      ("AKAZE", cv2_akaze_detect_and_describe),
                      ("KAZE", cv2_kaze_detect_and_describe)]:
        (kp_d, da), dt, peak = profile_extraction(name, lambda fn=fn: fn(scene, max_kp))
        results[name] = dict(descriptor_bytes_per_kp=int(da.nbytes / max(len(da), 1)),
                              peak_extraction_kb=peak / 1024, extraction_ms=dt * 1000)

    return results


def main():
    out = {}
    print("=== Extended baseline comparison (BRISK/AKAZE/KAZE, native detectors) ===")
    out["extended_baselines"] = run_joint_detector_comparison()
    print(json.dumps(out["extended_baselines"], indent=2))

    print("\n=== Memory analysis (real, tracemalloc) ===")
    out["memory_analysis"] = run_memory_analysis()
    print(json.dumps(out["memory_analysis"], indent=2))

    out_path = os.path.join(os.path.dirname(__file__), "extended_baseline_comparison_results.json")
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved -> {out_path}")


if __name__ == "__main__":
    main()
