"""
analyze_mc.py
=============

Generates every table, data figure and in-text number of the Measurement
manuscript from the raw result files:

  mc_measurement.jsonl   (mc_measurement.py: Part A metrology + Monte Carlo registration)
  oxford_k300.jsonl      (benchmark_shared_detector.py, real Oxford-Affine pairs)
  ablation_mc.json       (ablation_mc.py)
  timing.json            (timing_quiet.py)
  learned_oxford.jsonl   (learned_native_oxford.py, optional)
  megadepth_real_results.json (raw per-pair pose errors, code/scripts)

Usage: python analyze_mc.py results_dir paper_dir scripts_dir
"""
import sys, os, json, math
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, ".."))
from analyze_results import (P1, STYLE, HATCH, FILL, sci, num, load_jsonl, cluster_boot_diff,
                             rank_biserial, holm, boot_mean, table_megadepth)

CONDS = ["clean", "noise_0.02", "noise_0.05", "noise_0.1", "gamma_0.5", "gamma_2.0"]
CLAB = {"clean": "none", "noise_0.02": r"$\varepsilon=\sci{2}{-2}$", "noise_0.05": r"$\varepsilon=\sci{5}{-2}$",
        "noise_0.1": r"$\varepsilon=\sci{1}{-1}$", "gamma_0.5": r"$\gamma=0.5$", "gamma_2.0": r"$\gamma=2$"}
GROSS = 5.0
LAB = {"PW-Desc-rank-t0.05": r"PW-Desc-rank, $\tau=0.05$", "PW-Desc-rank-t0.1": r"PW-Desc-rank, $\tau=0.1$"}       # px: trials with no estimate or TRE above this are gross errors
NAMES_A = ["PW-Desc", "PW-Desc-rank", "SIFT", "RawPatch", "GradHist"]
EPS = [0.005, 0.01, 0.02, 0.05, 0.1]
GAM = [0.5, 0.67, 1.5, 2.0]
MAC = {}


def macro(name, value):
    MAC[name] = value


def wr(out, name, lines):
    txt = "\n".join(lines) + "\n"
    if name in ("tab_paired.tex", "tab_oxford.tex", "tab_ablation.tex", "tab_mc.tex"):
        txt = txt.replace("\\begin{tabular}", "\\resizebox{\\textwidth}{!}{\\begin{tabular}").replace("\\end{tabular}", "\\end{tabular}}")
    open(os.path.join(out, "tables", name), "w").write(txt)


# ---------------------------------------------------------------- Part A
def part_a(M, out):
    A = [m["part_a"] for m in M]
    chk = dict(cseh=[0, 0], lem=[0, 0], prop=[0, 0], rank=[0, 0])
    ratio_max, tight, tight_max, infl = [], {}, [], {}
    curves = {n: {"noise": {}, "gamma": {}} for n in NAMES_A}
    gamma_rank_max = 0.0
    for a in A:
        for key, rec in a["perturbations"].items():
            kind, v = key.split("_"); v = float(v)
            c = rec["checks"]
            chk["cseh"][0] += c["cseh_pass"]; chk["cseh"][1] += c["cseh_total"]
            chk["lem"][0] += c["lemma_pass"]; chk["lem"][1] += c["total_kp"]
            chk["prop"][0] += c["prop2_pass"]; chk["prop"][1] += c["total_kp"]
            chk["rank"][0] += c["rank_pass"]; chk["rank"][1] += c["rank_total"]
            ratio_max.append(c["dB_over_delta_max"]); tight_max.append(c["tightness_max"])
            if kind == "noise":
                tight.setdefault(v, []).append(c["tightness_median"])
                infl.setdefault(v, []).append(c["rank_inflation_median"])
            else:
                gamma_rank_max = max(gamma_rank_max, rec["PW-Desc-rank"]["drift_max"])
            for n in NAMES_A:
                curves[n][kind].setdefault(v, []).append((rec[n]["self_retrieval"], rec[n]["nu_median"], rec[n]["drift_median"]))
    n_img = len(A); n_kp = sum(a["n_kp"] for a in A)
    eta_min = min(a["eta_min"] for a in A)
    S = dict(n_img=n_img, n_kp=n_kp, checks=chk, dB_ratio_max=max(ratio_max), tightness_max=max(tight_max),
             tightness_median={str(k): float(np.median(v)) for k, v in tight.items()},
             rank_inflation_median={str(k): float(np.median(v)) for k, v in infl.items()},
             eta_min=eta_min, gamma_rank_drift_max=gamma_rank_max)
    summ = {n: {k: {str(v): dict(sr=float(np.mean([x[0] for x in vals])), nu=float(np.median([x[1] for x in vals])),
                                 drift=float(np.median([x[2] for x in vals])))
                    for v, vals in d.items()} for k, d in curves[n].items()} for n in NAMES_A}
    S["curves"] = summ
    tm = S["tightness_median"]["0.02"]
    macro("CsehMaxRatio", f"{S['dB_ratio_max']:.3f}")
    macro("VerifyKp", f"{chk['prop'][1]:,}".replace(",", "{,}"))
    macro("VerifyChecks", f"{chk['cseh'][1] + chk['lem'][1] + chk['prop'][1] + chk['rank'][1]:,}".replace(",", "{,}"))
    macro("NImgA", str(n_img)); macro("NKpA", f"{n_kp:,}".replace(",", "{,}"))
    macro("TightMedian", sci(tm)); macro("TightMax", sci(S["tightness_max"]))
    macro("TightOrders", str(int(round(-math.log10(tm)))))
    macro("EtaMin", f"{eta_min:.2f}")
    macro("RankInflMed", f"{S['rank_inflation_median']['0.02']:.0f}")
    macro("RankInflMedHigh", f"{S['rank_inflation_median']['0.1']:.1f}")
    macro("GammaRankDriftMax", "0" if gamma_rank_max == 0 else sci(gamma_rank_max))
    for n, tag in (("PW-Desc", "PW"), ("PW-Desc-rank", "PWR"), ("SIFT", "SIFT"), ("RawPatch", "Raw"), ("GradHist", "Grad")):
        macro(f"Nu{tag}TwoPct", f"{summ[n]['noise']['0.02']['nu']:.2f}")
        macro(f"SR{tag}TwoPct", f"{summ[n]['noise']['0.02']['sr']:.2f}")
        macro(f"SR{tag}TenPct", f"{summ[n]['noise']['0.1']['sr']:.2f}")
        macro(f"SR{tag}GammaTwo", f"{summ[n]['gamma']['2.0']['sr']:.2f}")
    ok = all(chk[k][0] == chk[k][1] for k in chk)
    S["all_pass"] = ok
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Verification of the certified sensitivity chain (Experiment A): " + f"{n_img}" + r" reference images, " + f"{n_kp:,}".replace(",", "{,}") + r" keypoints, nine perturbations each (five noise bounds, four gamma values, no re-quantization). Every inequality is checked with the measured $\delta=\lVert P_s-P'_s\rVert_\infty$. Tightness is the measured drift of the normalized descriptor divided by its certified bound.}",
             r"\label{tab:verify}", r"\begin{tabular}{@{}lc@{}}", r"\toprule", r"Quantity & Value \\", r"\midrule",
             r"Prop.~\ref{prop:cseh}, $d_B\le\delta$ (per scale and dimension) & " + f"{chk['cseh'][0]:,} / {chk['cseh'][1]:,}".replace(",", "{,}") + r" \\",
             r"Prop.~\ref{prop:stability}, unnormalized bound & " + f"{chk['lem'][0]:,} / {chk['lem'][1]:,}".replace(",", "{,}") + r" \\",
             r"Prop.~\ref{prop:stability}, normalized bound & " + f"{chk['prop'][0]:,} / {chk['prop'][1]:,}".replace(",", "{,}") + r" \\",
             r"Cor.~\ref{cor:rank-noise}, rank-change bound (per scale) & " + f"{chk['rank'][0]:,} / {chk['rank'][1]:,}".replace(",", "{,}") + r" \\",
             r"Largest measured $d_B/\delta$ & " + f"{S['dB_ratio_max']:.3f}" + r" \\",
             r"Smallest $\lVert\tilde x\rVert_2$ observed ($\eta$) & " + f"{eta_min:.2f}" + r" \\",
             r"Tightness, median over keypoints ($\varepsilon=\sci{2}{-2}$) & " + sci(tm) + r" \\",
             r"Tightness, largest observed & " + sci(S["tightness_max"]) + r" \\",
             r"Rank amplification $\lVert r(P)-r(P')\rVert_\infty/\delta$, median ($\varepsilon=\sci{2}{-2}$) & " + f"{S['rank_inflation_median']['0.02']:.1f}" + r" \\",
             r"Largest PW-Desc-rank drift under gamma (Prop.~\ref{prop:rank}) & " + ("0" if gamma_rank_max == 0 else sci(gamma_rank_max)) + r" \\",
             r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    wr(out, "tab_verify.tex", lines)

    fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.3), gridspec_kw=dict(width_ratios=[1, 1, 0.95]))
    for n in NAMES_A:
        st = STYLE[n]
        sr = [summ[n]["noise"][str(v)]["sr"] for v in EPS]
        nu = [summ[n]["noise"][str(v)]["nu"] for v in EPS]
        kw = dict(ls=st["ls"], color=st["color"], marker=st["marker"], mfc=st["mfc"], mec=st["color"], ms=4, lw=1)
        axs[0].plot(EPS, sr, label=n, **kw)
        axs[1].plot(EPS, nu, **kw)
    for ax in axs[:2]:
        ax.set_xscale("log"); ax.set_xlabel(r"noise bound $\varepsilon$")
    axs[0].set_ylabel("self-retrieval rate"); axs[0].set_ylim(0, 1.03)
    axs[1].set_ylabel(r"normalized drift $\nu$ (median)"); axs[1].set_yscale("log")
    w = 0.16
    for i, n in enumerate(NAMES_A):
        vals = [summ[n]["gamma"][str(g)]["sr"] for g in GAM]
        axs[2].bar(np.arange(len(GAM)) + (i - 2) * w, vals, width=w, color=FILL[n], edgecolor="black", lw=0.5, hatch=HATCH[n])
    axs[2].set_xticks(range(len(GAM))); axs[2].set_xticklabels([str(g) for g in GAM]); axs[2].set_xlabel(r"gamma $\gamma$")
    axs[2].set_ylabel("self-retrieval rate"); axs[2].set_ylim(0, 1.05)
    for ax, lab in zip(axs, "abc"):
        ax.text(-0.02, 1.04, f"({lab})", transform=ax.transAxes, ha="right", va="bottom")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=5, bbox_to_anchor=(0.5, 1.08), handlelength=2.6)
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    fig.savefig(os.path.join(out, "figures", "fig3_sensitivity.pdf"), bbox_inches="tight")
    plt.close(fig)
    return S


# ---------------------------------------------------------------- Monte Carlo registration
def mc(M, out, TAU=None):
    methods = list(P1)
    if TAU:
        tmap = {t["image"]: t for t in TAU}
        for m in M:
            t = tmap[m["image"]]
            for rec, trec in zip(m["mc"], t["mc"]):
                assert rec["trial"] == trec["trial"] and rec["condition"] == trec["condition"]
                for k, v in trec.items():
                    if isinstance(v, dict):
                        rec[k] = v
        methods += [k for k in TAU[0]["mc"][0] if isinstance(TAU[0]["mc"][0][k], dict)]
    tre = {n: {c: [] for c in CONDS} for n in methods}          # list of (image_index, tre or inf)
    for i, m in enumerate(M):
        for rec in m["mc"]:
            for n in methods:
                v = rec[n]["tre"]
                tre[n][rec["condition"]].append((i, np.inf if v is None else v))
    n_img = len(M); n_trials = len(tre["SIFT"]["clean"])
    S = {"n_img": n_img, "n_trials_per_condition": n_trials}
    res = {}
    for n in methods:
        res[n] = {}
        for c in CONDS:
            e = np.array([x[1] for x in tre[n][c]])
            gross = e > GROSS
            ok = e[~gross]
            per_img = np.array([np.mean(np.array([x[1] for x in tre[n][c] if x[0] == i]) > GROSS) for i in range(n_img)])
            bm = boot_mean(per_img)
            res[n][c] = dict(gross=float(gross.mean()), gross_lo=float(np.percentile(bm, 2.5)), gross_hi=float(np.percentile(bm, 97.5)),
                             median=float(np.median(ok)) if len(ok) else None,
                             u95=float(np.percentile(e, 95)), rms_ok=float(np.sqrt(np.mean(ok ** 2))) if len(ok) else None,
                             p_sub=float(np.mean(e <= 0.5)))
    S["res"] = res
    # sensitivity coefficient of the median TRE (successful trials) with respect to eps
    for n in methods:
        m02, m10 = res[n]["noise_0.02"]["median"], res[n]["noise_0.1"]["median"]
        res[n]["c_eps"] = (m10 - m02) / 0.08 if (m02 is not None and m10 is not None) else None

    def u95txt(u):
        return r"$>$" + f"{GROSS:.0f}" if not math.isfinite(u) or u > GROSS else f"{u:.2f}"
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Monte Carlo evaluation of the registration measurement (" + f"{n_img}" + r" real reference images $\times$ " + f"{n_trials // n_img}" + r" known random homographies per disturbance, 8-bit re-quantized). Top: gross-error rate, the fraction of trials without an estimate or with a target registration error (TRE) above " + f"{GROSS:.0f}" + r" pixels. Bottom: $U_{95}$, the 95th percentile of the TRE over all trials (gross errors included), i.e.\ the upper limit of the 95\% coverage interval in pixels; ``$>5$'' means that 95\% coverage is not reached within " + f"{GROSS:.0f}" + r" pixels.}",
             r"\label{tab:mc}", r"\setlength{\tabcolsep}{4pt}", r"\begin{tabular}{@{}lcccccc@{}}", r"\toprule",
             r"Method & " + " & ".join(CLAB[c] for c in CONDS) + r" \\", r"\midrule",
             r"\multicolumn{7}{@{}l}{\textit{Gross-error rate (\%)}} \\"]
    for n in methods:
        lines.append(LAB.get(n, n) + " & " + " & ".join(f"{100 * res[n][c]['gross']:.1f}" for c in CONDS) + r" \\")
    lines += [r"\midrule", r"\multicolumn{7}{@{}l}{\textit{$U_{95}$ of the TRE (pixels)}} \\"]
    for n in methods:
        lines.append(LAB.get(n, n) + " & " + " & ".join(u95txt(res[n][c]["u95"]) for c in CONDS) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    wr(out, "tab_mc.tex", lines)

    # paired, image-level comparisons of gross-error rate (all disturbed conditions, and gamma only)
    comps = [("PW-Desc-rank", "PW-Desc")] + [("PW-Desc-rank", b) for b in ("SIFT", "RawPatch", "GradHist", "ORB")]
    blocks = {"noise": [c for c in CONDS if c.startswith("noise")], "gamma": [c for c in CONDS if c.startswith("gamma")]}
    rows = []
    for bname, cl in blocks.items():
        def per_img(n):
            return np.array([np.mean([x[1] > GROSS for c in cl for x in tre[n][c] if x[0] == i]) for i in range(n_img)])
        raw, blk = [], []
        for a, b in comps:
            x, y = per_img(a), per_img(b)
            mean, lo, hi = cluster_boot_diff(x, y)
            try:
                p = stats.wilcoxon(x, y).pvalue if np.any(x != y) else 1.0
            except ValueError:
                p = 1.0
            raw.append(p); blk.append(dict(block=bname, a=a, b=b, mean=mean, lo=lo, hi=hi, r=rank_biserial(x, y)))
        for d, pa in zip(blk, holm(np.array(raw))):
            d["p_holm"] = float(pa)
        rows += blk
    S["paired"] = rows
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Paired comparison of gross-error rates in the Monte Carlo experiment, with the reference image as statistical unit ($n=" + str(n_img) + r"$): mean difference in percentage points (first minus second method; negative favours PW-Desc-rank), 95\% bootstrap interval over images, Wilcoxon signed-rank $p$ with Holm correction within each block, and rank-biserial effect size.}",
             r"\label{tab:paired}", r"\setlength{\tabcolsep}{4pt}", r"\begin{tabular}{@{}llcccc@{}}", r"\toprule",
             r"Disturbance & Comparison & Diff.\ (pp) & 95\% CI & $p_{\mathrm{Holm}}$ & $r_{rb}$ \\", r"\midrule"]
    prev = None
    for d in rows:
        if prev and d["block"] != prev:
            lines.append(r"\midrule")
        lab = {"noise": "noise ($\\varepsilon\\le 0.1$)", "gamma": "gamma ($0.5$, $2$)"}[d["block"]] if d["block"] != prev else ""
        p = d["p_holm"]
        ptxt = (r"$<$\sci{1}{-3}" if p < 1e-3 else (sci(p) if p < 0.1 else f"{p:.2f}"))
        lines.append(f"{lab} & {d['a']} $-$ {d['b']} & ${100 * d['mean']:+.1f}$ & $[{100 * d['lo']:+.1f},\\,{100 * d['hi']:+.1f}]$ & {ptxt} & ${d['r']:+.2f}$ \\\\")
        prev = d["block"]
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    wr(out, "tab_paired.tex", lines)

    # figure: empirical CDF of TRE for three conditions
    fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.3), sharey=True)
    for ax, c, lab in zip(axs, ("clean", "noise_0.05", "gamma_2.0"), ("(a) no disturbance", r"(b) noise $\varepsilon=0.05$", r"(c) gamma $\gamma=2$")):
        for n in [x for x in methods if x in STYLE]:
            e = np.sort([x[1] for x in tre[n][c]])
            y = np.arange(1, len(e) + 1) / len(e)
            st = STYLE[n]
            fin = np.isfinite(e)
            ax.step(np.clip(e[fin], 1e-2, 1e3), y[fin], where="post", ls=st["ls"], color=st["color"], lw=1, label=n)
        ax.axvline(GROSS, color="0.6", lw=0.6, ls=":")
        ax.set_xscale("log"); ax.set_xlim(1e-2, 1e2); ax.set_ylim(0, 1)
        ax.set_xlabel("TRE (pixels)"); ax.set_title(lab, fontsize=9)
    axs[0].set_ylabel("cumulative fraction of trials")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=6, bbox_to_anchor=(0.5, 1.07), handlelength=2.4)
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    fig.savefig(os.path.join(out, "figures", "fig4_tre_cdf.pdf"), bbox_inches="tight")
    plt.close(fig)

    r = res
    macro("NImgMC", str(n_img)); macro("NTrialsMC", str(n_trials)); macro("NTrialsPerImg", str(n_trials // n_img))
    macro("NRegistrations", f"{n_trials * len(CONDS) * len(P1):,}".replace(",", "{,}"))
    tags = [("PW-Desc", "PW"), ("PW-Desc-rank", "PWR"), ("SIFT", "SIFT"), ("RawPatch", "Raw"), ("GradHist", "Grad"), ("ORB", "ORB"),
            ("PW-Desc-rank-t0.05", "PWRTauA"), ("PW-Desc-rank-t0.1", "PWRTauB")]
    for n, tag in [t for t in tags if t[0] in r]:
        for c, ct in (("clean", "Clean"), ("noise_0.02", "NTwo"), ("noise_0.05", "NFive"), ("noise_0.1", "NTen"), ("gamma_0.5", "GHalf"), ("gamma_2.0", "GTwo")):
            macro(f"Gross{tag}{ct}", f"{100 * r[n][c]['gross']:.1f}")
            macro(f"GrossLo{tag}{ct}", f"{100 * r[n][c]['gross_lo']:.1f}")
            macro(f"GrossHi{tag}{ct}", f"{100 * r[n][c]['gross_hi']:.1f}")
            u = r[n][c]["u95"]
            macro(f"U{tag}{ct}", f"{u:.2f}" if math.isfinite(u) and u <= GROSS else f"$>${GROSS:.0f}")
            md = r[n][c]["median"]
            macro(f"Med{tag}{ct}", f"{md:.2f}" if md is not None else "--")
        ce = r[n]["c_eps"]
        macro(f"Ceps{tag}", f"{ce:.1f}" if ce is not None else "--")
    return S


# ---------------------------------------------------------------- Oxford
def oxford(O, L, out):
    def agg(recs, m):
        rs = [r["methods"][m] for r in recs if m in r["methods"]]
        ce = [x.get("mean_corner_err") for x in rs]
        return dict(mma1=np.mean([x["mma"]["1"] for x in rs]), mma3=np.mean([x["mma"]["3"] for x in rs]),
                    mma5=np.mean([x["mma"]["5"] for x in rs]), ms=np.mean([x["matching_score"] for x in rs]),
                    ha3=np.mean([c is not None and c <= 3 for c in ce]), ha5=np.mean([c is not None and c <= 5 for c in ce]),
                    ha10=np.mean([c is not None and c <= 10 for c in ce]), n=len(rs))
    rows = [("P1", m, agg(O, m)) for m in P1]
    if L:
        rows += [("P2", m, agg(L, m)) for m in ("SuperPoint", "DISK") if any(m in r["methods"] for r in L)]
    keys = ("mma1", "mma3", "mma5", "ms", "ha3", "ha5", "ha10")
    best = {k: max(r[2][k] for r in rows if r[0] == "P1") for k in keys}
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Real image pairs of Oxford-Affine (8 scenes, 40 pairs with ground-truth homographies). P1: all descriptors at the same Harris keypoints ($K=300$), so differences are due to the descriptor; best P1 value in bold. P2: SuperPoint and DISK with their own detectors and the same budget, for reference. MMA@$t$: fraction of matches within $t$ pixels; MS: matching score; HA@$t$: fraction of pairs whose homography has a mean corner error of at most $t$ pixels.}",
             r"\label{tab:oxford}", r"\setlength{\tabcolsep}{4pt}", r"\begin{tabular}{@{}llccccccc@{}}", r"\toprule",
             r" & Method & MMA@1 & MMA@3 & MMA@5 & MS & HA@3 & HA@5 & HA@10 \\", r"\midrule"]
    prev = None
    S = {}
    for proto, m, a in rows:
        if prev and proto != prev:
            lines.append(r"\midrule")
        cells = []
        for k in keys:
            s = num(a[k])
            cells.append(r"\textbf{" + s + "}" if proto == "P1" and abs(a[k] - best[k]) < 1e-12 else s)
        lines.append(f"{proto if proto != prev else ''} & {m} & " + " & ".join(cells) + r" \\")
        prev = proto
        S[m] = {k: float(v) for k, v in a.items()}
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    wr(out, "tab_oxford.tex", lines)
    for m, tag in (("PW-Desc", "PW"), ("PW-Desc-rank", "PWR"), ("SIFT", "SIFT"), ("RawPatch", "Raw"), ("GradHist", "Grad"), ("ORB", "ORB")):
        macro(f"Ox{tag}MMA", num(S[m]["mma3"])); macro(f"Ox{tag}HA", num(S[m]["ha5"]))
    for m in ("SuperPoint", "DISK"):
        if m in S:
            macro(f"Ox{m}MMA", num(S[m]["mma3"])); macro(f"Ox{m}HA", num(S[m]["ha5"]))
    # illumination scene (leuven) for the rank variant
    lv = [r for r in O if r["sequence"] == "leuven"]
    for m, tag in (("PW-Desc", "PW"), ("PW-Desc-rank", "PWR"), ("SIFT", "SIFT")):
        macro(f"Leuven{tag}", num(np.mean([r["methods"][m]["mma"]["3"] for r in lv])))
    return S


# ---------------------------------------------------------------- ablation
def ablation(A, out):
    if not A:
        return None
    ps = A["per_sequence"]; pe = A["projection_eval"]
    order = [("full", r"Full: $H_0{+}H_1$, $s\in\{16,24,32\}$, $8{\times}8$, $\tau=0$"),
             ("H0", r"$H_0$ only"), ("H1", r"$H_1$ only"),
             ("s16", r"single scale $s=16$"), ("s24", r"single scale $s=24$"), ("s32", r"single scale $s=32$"),
             ("res4", r"resolution $4{\times}4$"), ("res16", r"resolution $16{\times}16$"),
             ("tau0.05", r"ramp threshold $\tau=0.05$")]

    def row(r, ref):
        d = np.array([x["mma3"] for x in r]) - np.array([x["mma3"] for x in ref])
        mean, lo, hi = cluster_boot_diff(d, np.zeros_like(d))
        return dict(mma3=float(np.mean([x["mma3"] for x in r])), ha3=float(np.mean([x["ha3"] for x in r])),
                    sr=float(np.mean([x["self_retrieval"] for x in r])), nu=float(np.median([x["nu_median"] for x in r])),
                    d=mean, lo=lo, hi=hi)
    res = {k: row(ps[k], ps["full"]) for k, _ in order}
    pres = {k: row(pe[k], pe["full"]) for k in ("full", "proj_constrained", "proj_unconstrained")}
    n = A["n_sequences"]
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Ablation on real photographs warped by mild random homographies with exactly known ground truth (" + str(n) + r" reference images, five targets each, generated as in Experiment B: rotation within $\pm15^\circ$, scale 0.85--1.15, no photometric change; protocol P1). These targets are much easier than the real Oxford-Affine pairs of Table~\ref{tab:oxford}, so absolute MMA values are higher; only differences between rows are meaningful. $\Delta$MMA@3: mean per-image difference from the full configuration with 95\% bootstrap interval. HA@3: homography accuracy at 3 pixels. Noise sensitivity of the reference images under $U[-0.02,0.02]$: self-retrieval rate (SR, higher is better) and median normalized drift $\nu$ (lower is better). The projection rows are evaluated on the " + str(len(pe["full"])) + r" images of four scenes not used to train $W$ (training: " + f"{A['projection']['n_train_pairs']:,}".replace(",", "{,}") + r" pairs from the other four scenes).}",
             r"\label{tab:ablation}", r"\setlength{\tabcolsep}{3.5pt}", r"\begin{tabular}{@{}lccccc@{}}", r"\toprule",
             r"Configuration & MMA@3 & $\Delta$MMA@3 [95\% CI] & HA@3 & SR & $\nu$ \\", r"\midrule"]

    def fmt(lab, r, ref=False):
        dt = "--" if ref else f"${r['d']:+.3f}$ $[{r['lo']:+.3f},{r['hi']:+.3f}]$"
        return f"{lab} & {r['mma3']:.3f} & {dt} & {r['ha3']:.3f} & {r['sr']:.3f} & {r['nu']:.3f} \\\\"
    for k, lab in order:
        lines.append(fmt(lab, res[k], k == "full"))
        if k in ("full", "H1", "s32", "res16"):
            lines.append(r"\midrule")
    lines += [r"\midrule", r"\multicolumn{6}{@{}l}{\textit{Held-out scenes}} \\",
              fmt("no projection ($x\\in\\mathbb R^{384}$)", pres["full"], True),
              fmt(r"projection, $\lVert W\rVert_2\le1$", pres["proj_constrained"]),
              fmt(r"projection, unconstrained ($\lVert W\rVert_2=" + f"{A['projection']['unconstrained']['spectral_norm']:.2f}" + r"$)", pres["proj_unconstrained"]),
              r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    wr(out, "tab_ablation.tex", lines)
    macro("WuNorm", f"{A['projection']['unconstrained']['spectral_norm']:.2f}")
    macro("EtaWMin", f"{A['eta_W']['min']:.2f}")
    macro("AblTauDelta", f"{res['tau0.05']['d']:+.3f}")
    macro("AblTauNu", f"{res['tau0.05']['nu']:.2f}"); macro("AblFullNu", f"{res['full']['nu']:.2f}")
    macro("AblTauSR", f"{res['tau0.05']['sr']:.2f}"); macro("AblFullSR", f"{res['full']['sr']:.2f}")
    macro("AblFullMMA", f"{res['full']['mma3']:.3f}")
    return dict(res=res, proj=pres, info=A["projection"], eta_W=A["eta_W"])


# ---------------------------------------------------------------- cost
def cost(T, O, out):
    if not T:
        return None
    t = T["ms_per_kp"]
    acc = {m: np.mean([r["methods"][m]["mma"]["3"] for r in O]) for m in P1}
    dims = {"PW-Desc": (384, 8), "PW-Desc-rank": (384, 8), "SIFT": (128, 4), "RawPatch": (256, 8), "GradHist": (128, 8), "ORB": (32, 1)}
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Cost per keypoint on one CPU core (" + T["cpu"] + r"), measured in isolation on " + str(T["n_kp"]) + r" keypoints of " + str(T["n_images"]) + r" images, median of " + str(T["repeats"]) + r" repetitions; storage per descriptor as implemented (PW-Desc stores \texttt{float64}; \texttt{float32} would halve it). Reference: the NumPy/GUDHI implementation used in all experiments. Compiled: the same algorithm in a compiled union-find implementation (Section~\ref{sec:implementation}), whose descriptors agree with the reference to within $10^{-15}$.}",
             r"\label{tab:cost}", r"\begin{tabular}{@{}lcccc@{}}", r"\toprule",
             r"Method & Time (ms/kp) & Relative to SIFT & Dimension & Bytes \\", r"\midrule"]
    rows = []
    for m in P1:
        rows.append((m + (" (reference)" if m.startswith("PW") else ""), m, m))
        if m.startswith("PW") and (m + " (compiled)") in t:
            rows.append((m + " (compiled)", m + " (compiled)", m))
    for lab, key, base in rows:
        d, b = dims[base]
        lines.append(f"{lab} & {num(t[key])} & {t[key] / t['SIFT']:.1f} & {d} & {d * b} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    wr(out, "tab_cost.tex", lines)
    macro("TimePW", f"{t['PW-Desc']:.1f}"); macro("TimePWR", f"{t['PW-Desc-rank']:.1f}"); macro("TimeSIFT", f"{t['SIFT']:.2f}")
    macro("TimeRatioPW", f"{t['PW-Desc'] / t['SIFT']:.0f}")
    if "PW-Desc (compiled)" in t:
        macro("TimePWC", f"{t['PW-Desc (compiled)']:.2f}"); macro("TimePWRC", f"{t['PW-Desc-rank (compiled)']:.2f}")
        macro("TimeRatioPWC", f"{t['PW-Desc (compiled)'] / t['SIFT']:.1f}")
        macro("SpeedupPW", f"{t['PW-Desc'] / t['PW-Desc (compiled)']:.0f}")
        macro("TimeGrad", f"{t['GradHist']:.2f}")
    fig, ax = plt.subplots(figsize=(3.4, 2.3))
    for m in P1:
        st = STYLE[m]
        ax.scatter([t[m]], [acc[m]], marker=st["marker"], facecolor=st["mfc"], edgecolor="black", s=28, lw=0.7, zorder=3)
        ax.annotate(m, (t[m], acc[m]), textcoords="offset points", xytext=(5, -3), fontsize=7.5)
        if m + " (compiled)" in t:
            tc = t[m + " (compiled)"]
            ax.scatter([tc], [acc[m]], marker=st["marker"], facecolor="white", edgecolor="black", s=28, lw=0.7, zorder=3)
            ax.annotate("", xy=(tc * 1.08, acc[m]), xytext=(t[m] / 1.08, acc[m]),
                        arrowprops=dict(arrowstyle="->", lw=0.6, color="0.3", linestyle="--"))
    ax.annotate("open markers: compiled path,\nidentical descriptors", (0.02, 0.97), xycoords="axes fraction", va="top", fontsize=6.5)
    ax.set_xscale("log"); ax.set_xlabel("extraction time per keypoint (ms, one core)")
    ax.set_ylabel("Oxford-Affine MMA@3"); ax.set_ylim(0, 0.8)
    fig.tight_layout(); fig.savefig(os.path.join(out, "figures", "fig6_cost.pdf"), bbox_inches="tight"); plt.close(fig)
    return T


def main():
    rdir, pdir, sdir = sys.argv[1], sys.argv[2], sys.argv[3]
    os.makedirs(os.path.join(pdir, "tables"), exist_ok=True); os.makedirs(os.path.join(pdir, "figures"), exist_ok=True)
    M = load_jsonl(os.path.join(rdir, "mc_measurement.jsonl"))
    O = load_jsonl(os.path.join(rdir, "oxford_k300.jsonl"))
    L = load_jsonl(os.path.join(rdir, "learned_oxford.jsonl"))
    A = json.load(open(os.path.join(rdir, "ablation_mc.json"))) if os.path.exists(os.path.join(rdir, "ablation_mc.json")) else None
    T = json.load(open(os.path.join(rdir, "timing.json"))) if os.path.exists(os.path.join(rdir, "timing.json")) else None
    S = {"n_mc_images": len(M), "n_oxford_pairs": len(O)}
    S["megadepth"] = table_megadepth(os.path.join(sdir, "megadepth_real_results.json"), pdir)
    md = S["megadepth"]
    for m, tag in (("PW-Desc-rank", "PWR"), ("SIFT", "SIFT"), ("LoFTR", "LoFTR"), ("DISK", "DISK"), ("SuperPoint", "SP")):
        macro(f"MD{tag}Twenty", num(md[m]["auc20"]))
    if M:
        S["part_a"] = part_a(M, pdir)
        TAU = load_jsonl(os.path.join(rdir, "mc_tau.jsonl"))
        S["mc"] = mc(M, pdir, TAU if len(TAU) == len(M) else None)
    S["oxford"] = oxford(O, L, pdir)
    S["ablation"] = ablation(A, pdir)
    S["cost"] = cost(T, O, pdir)
    # constants of Remark 1
    r, sig, Lw = 8, 1 / 8, 1.0
    K = 2 * Lw + math.sqrt(5) / (sig * math.sqrt(math.e))
    Cmax = 2 * r * K * math.sqrt(sum((s * s - 1) ** 2 + (s - 1) ** 4 for s in (16, 24, 32)))
    macro("KPI", f"{K:.2f}"); macro("Cmax", sci(Cmax))
    macro("Kshared", "300"); macro("Kperturb", "100")
    with open(os.path.join(pdir, "results_macros.tex"), "w") as f:
        f.write("% generated by code/scripts/analyze_mc.py -- do not edit\n")
        for k, v in MAC.items():
            f.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")
    json.dump(S, open(os.path.join(pdir, "stats.json"), "w"), indent=1, default=float)
    print("macros:", len(MAC))





# ---------------------------------------------------------------- additions for the JMIV version
XCONDS = ["blur_1.0", "blur_2.0", "jpeg_50", "jpeg_20"]
XLAB = {"blur_1.0": r"blur $\sigma_b=1$", "blur_2.0": r"blur $\sigma_b=2$", "jpeg_50": "JPEG $Q=50$", "jpeg_20": "JPEG $Q=20$"}


def mc_extra(E, out):
    methods = [k for k in E[0]["mc"][0] if isinstance(E[0]["mc"][0][k], dict)]
    res = {}
    for n in methods:
        res[n] = {}
        for c in XCONDS:
            e = np.array([np.inf if r[n]["tre"] is None else r[n]["tre"] for m in E for r in m["mc"] if r["condition"] == c])
            res[n][c] = dict(gross=float(np.mean(e > GROSS)), u95=float(np.percentile(e, 95)))
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Registration under disturbances outside the hypotheses of the bound: Gaussian blur and JPEG compression (same images, homographies and protocol as Table~\ref{tab:mc}). Gross-error rate in percent and $U_{95}$ of the TRE in pixels.}",
             r"\label{tab:mcextra}", r"\setlength{\tabcolsep}{4pt}", r"\resizebox{\textwidth}{!}{\begin{tabular}{@{}lcccccccc@{}}", r"\toprule",
             r" & \multicolumn{4}{c}{Gross-error rate (\%)} & \multicolumn{4}{c}{$U_{95}$ (pixels)} \\", r"\cmidrule(lr){2-5}\cmidrule(l){6-9}",
             r"Method & " + " & ".join(XLAB[c] for c in XCONDS) + " & " + " & ".join(XLAB[c] for c in XCONDS) + r" \\", r"\midrule"]
    for n in methods:
        u = [res[n][c]["u95"] for c in XCONDS]
        lines.append(LAB.get(n, n) + " & " + " & ".join(f"{100 * res[n][c]['gross']:.1f}" for c in XCONDS) + " & " +
                     " & ".join((f"{x:.2f}" if math.isfinite(x) and x <= GROSS else r"$>$5") for x in u) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}}", r"\end{table}"]
    open(os.path.join(out, "tables", "tab_mc_extra.tex"), "w").write("\n".join(lines) + "\n")
    for n, tag in (("PW-Desc", "PW"), ("PW-Desc-rank", "PWR"), ("SIFT", "SIFT"), ("RawPatch", "Raw"), ("GradHist", "Grad"), ("ORB", "ORB"),
                   ("PW-Desc-rank-t0.1", "PWRTauB")):
        for c, ct in (("blur_1.0", "BlurOne"), ("blur_2.0", "BlurTwo"), ("jpeg_50", "JpegFifty"), ("jpeg_20", "JpegTwenty")):
            macro(f"Gross{tag}{ct}", f"{100 * res[n][c]['gross']:.1f}")
    return res


def tightness(B, out):
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Cardinality bound (Proposition~\ref{prop:stability}) against the thresholded bound (Proposition~\ref{prop:threshold}) for the unnormalized descriptor $\tilde x$ under uniform noise, 16 images, 100 keypoints each. Checks: bound satisfied / keypoints. Tightness: median of drift divided by bound (closer to one is tighter). For $\tau=0$ the thresholded bound reduces to the cardinality bound.}",
             r"\label{tab:tightness}", r"\setlength{\tabcolsep}{4pt}", r"\resizebox{\textwidth}{!}{\begin{tabular}{@{}cccccccc@{}}", r"\toprule",
             r"$\tau$ & $\varepsilon$ & Checks (Prop.~\ref{prop:stability}) & Checks (Prop.~\ref{prop:threshold}) & Median drift & Tightness (Prop.~\ref{prop:stability}) & Tightness (Prop.~\ref{prop:threshold}) & Gain \\", r"\midrule"]
    for t in ("0.0", "0.05", "0.1"):
        for e in ("0.005", "0.01", "0.02"):
            r = B[f"{t}_{e}"]
            lines.append(f"{t} & {sci(float(e))} & {r['card_ok']:,}/{r['n']:,} & {r['thr_ok']:,}/{r['n']:,} & {num(r['drift_median'])} & {sci(r['tight_card'])} & {sci(r['tight_thr'])} & {r['ratio_card_thr']:.1f} \\\\".replace(",", "{,}"))
        if t != "0.1":
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}}", r"\end{table}"]
    open(os.path.join(out, "tables", "tab_tightness.tex"), "w").write("\n".join(lines) + "\n")
    macro("TightGainTauB", f"{B['0.1_0.02']['ratio_card_thr']:.0f}")
    macro("TightGainMax", f"{max(v['ratio_card_thr'] for v in B.values()):.0f}")
    macro("TightGainTauBSmall", f"{B['0.1_0.005']['ratio_card_thr']:.0f}")
    macro("TightThrTauBSmall", sci(B['0.1_0.005']['tight_thr']))
    macro("TightCardTauBSmall", sci(B['0.1_0.005']['tight_card']))
    macro("TightCardTauB", sci(B['0.1_0.02']['tight_card']))
    macro("TightGainTauA", f"{B['0.05_0.02']['ratio_card_thr']:.0f}")
    macro("TightThrTauB", sci(B['0.1_0.02']['tight_thr']))
    macro("TightCardTauZero", sci(B['0.0_0.02']['tight_card']))


def complexity(C, out):
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Measured cost of the persistence computation per patch (both homological dimensions) as the patch side $s$ grows, 200 keypoint patches, one core.}",
             r"\label{tab:complexity}", r"\begin{tabular}{@{}rrrrr@{}}", r"\toprule",
             r"$s$ & Cells & Off-diagonal points (median) & From scratch (ms) & GUDHI (ms) \\", r"\midrule"]
    for s, r in C.items():
        lines.append(f"{s} & {r['cells']:,} & {r['offdiag_points_median']:.0f} & {r['bitpacked_ms']:.2f} & {r['gudhi_ms']:.2f} \\\\".replace(",", "{,}"))
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    open(os.path.join(out, "tables", "tab_complexity.tex"), "w").write("\n".join(lines) + "\n")
    s = list(C.keys())
    a, b = C[s[1]], C[s[-1]]
    expo = math.log(b["bitpacked_ms"] / a["bitpacked_ms"]) / math.log(b["cells"] / a["cells"])
    macro("ComplexExpo", f"{expo:.2f}")


def jmiv_main():
    rdir, pdir = sys.argv[2], sys.argv[3]
    E = load_jsonl(os.path.join(rdir, "mc_extra.jsonl"))
    if E:
        mc_extra(E, pdir)
    if os.path.exists(os.path.join(rdir, "bound_tightness.json")):
        tightness(json.load(open(os.path.join(rdir, "bound_tightness.json"))), pdir)
    if os.path.exists(os.path.join(rdir, "complexity.json")):
        complexity(json.load(open(os.path.join(rdir, "complexity.json"))), pdir)
    Mm = load_jsonl(os.path.join(rdir, "mc_measurement.jsonl"))
    if Mm:
        def rate(n, c, sel):
            e = [r[n]["tre"] for m in Mm for r in m["mc"] if r["condition"] == c and sel(r["trial"])]
            return np.mean([x is None or x > GROSS for x in e]), len(e)
        for n, tag in (("PW-Desc", "PW"), ("PW-Desc-rank", "PWR")):
            for c, ct in (("noise_0.05", "NFive"), ("noise_0.1", "NTen")):
                a, _ = rate(n, c, lambda t: t < 8); b, _ = rate(n, c, lambda t: t >= 8)
                macro(f"HalfA{tag}{ct}", f"{100 * a:.1f}"); macro(f"HalfB{tag}{ct}", f"{100 * b:.1f}")
        _, ntot = rate("SIFT", "clean", lambda t: True)
        macro("CPUpper", f"{100 * stats.beta.ppf(0.975, 1, ntot):.1f}"); macro("CPn", str(ntot))
    Tt = load_jsonl(os.path.join(rdir, "mc_tau.jsonl"))
    if Mm and Tt:
        tm = {t["image"]: t for t in Tt}
        dif = []
        for m in Mm:
            t = tm[m["image"]]
            base = [r["PW-Desc-rank"]["tre"] for r in m["mc"] if r["condition"].startswith("noise")]
            thr = [r["PW-Desc-rank-t0.1"]["tre"] for r in t["mc"] if r["condition"].startswith("noise")]
            g = lambda v: np.mean([x is None or x > GROSS for x in v])
            dif.append(g(thr) - g(base))
        mean, lo, hi = cluster_boot_diff(dif, np.zeros(len(dif)))
        p = stats.wilcoxon(dif).pvalue
        macro("TauDiff", f"{-100 * mean:.1f}"); macro("TauDiffLo", f"{100 * lo:.1f}"); macro("TauDiffHi", f"{100 * hi:.1f}")
        macro("TauDiffP", sci(p)); macro("TauDiffLower", str(int(np.sum(np.array(dif) < 0)))); macro("TauDiffHigher", str(int(np.sum(np.array(dif) > 0)))); macro("TauDiffN", str(len(dif)))
    cr = os.path.join(rdir, "certified_radius.json")
    if os.path.exists(cr):
        R = json.load(open(cr))
        for t, tag in (("0.05", "TauA"), ("0.1", "TauB")):
            r = R[t]
            macro(f"RadMed{tag}", sci(r["median"])); macro(f"RadPTen{tag}", sci(r["p10"])); macro(f"RadPNinety{tag}", sci(r["p90"]))
            macro(f"RadMax{tag}", sci(r["max"])); macro(f"RadMedGrey{tag}", f"{255 * r['median']:.3f}")
            macro(f"RadMaxGrey{tag}", f"{255 * r['max']:.2f}")
            macro(f"RadFracTenth{tag}", f"{100 * r['frac_tenth_level']:.1f}"); macro(f"RadFracHalf{tag}", f"{100 * r['frac_half_level']:.1f}")
            macro(f"RadZero{tag}", f"{100 * r['frac_zero']:.1f}")
            macro(f"RadChecks{tag}", f"{r['checked']:,}".replace(",", "{,}")); macro(f"RadViol{tag}", str(r["violations"]))
    pc = os.path.join(rdir, "pi_constant.json")
    if os.path.exists(pc):
        Pc = json.load(open(pc))
        macro("PIRatioPair", f"{max(v['max_ratio_pair'] for v in Pc.values()):.2f}")
        macro("PIRatioDiag", f"{max(v['max_ratio_diagonal'] for v in Pc.values()):.2f}")
    macro("EtaFactor", "6.5")
    sj = os.path.join(rdir, "sharpness.json")
    if os.path.exists(sj):
        Sh = json.load(open(sj))
        macro("SharpRatio", sci(Sh["ratio_limit"]) if Sh["ratio_limit"] < 0.1 else f"{Sh['ratio_limit']:.3f}")
        macro("SharpRealMed", sci(Sh["real_median_ratio"])); macro("SharpRealMax", sci(Sh["real_max_ratio"]))
        macro("SharpRealN", str(Sh["real_n"])); macro("SharpFactor", f"{Sh['ratio_limit'] / Sh['real_median_ratio']:.0f}")
    fv = os.path.join(rdir, "fastph_verify.json")
    if os.path.exists(fv):
        F = json.load(open(fv))
        macro("FastPatches", f"{F['n_patches']:,}".replace(",", "{,}")); macro("FastMismatch", str(F["mismatches"]))
    tg = os.path.join(rdir, "timing_pi_grid.json")
    if os.path.exists(tg):
        T = json.load(open(tg))
        macro("PIEightMs", f"{T['pi8_ms']:.2f}"); macro("PISixteenMs", f"{T['pi16_ms']:.2f}"); macro("PHMs", f"{T['ph_ms']:.2f}")
    md = os.path.join(HERE, "megadepth_real_results.json")
    if os.path.exists(md):
        recs = list(json.load(open(md))["per_pair"].values())
        for m, tag in (("PW-Desc", "PW"), ("PW-Desc-rank", "PWR"), ("SIFT", "SIFT"), ("ORB", "ORB")):
            e = np.array([r[m]["pose_err"] for r in recs]); nm = np.array([r[m]["n_matches"] for r in recs])
            macro(f"MDFail{tag}", f"{100 * np.mean(e >= 179.999):.0f}"); macro(f"MDBad{tag}", f"{100 * np.mean(e > 90):.0f}")
            macro(f"MDMatches{tag}", f"{np.median(nm):.0f}")
    with open(os.path.join(pdir, "results_macros_extra.tex"), "w") as f:
        for k, v in MAC.items():
            f.write(f"\\newcommand{{\\{k}}}{{{v}}}\n")
    print("extra macros", len(MAC))


if __name__ == "__main__":
    if sys.argv[1] == "--jmiv":
        jmiv_main()
    else:
        main()
