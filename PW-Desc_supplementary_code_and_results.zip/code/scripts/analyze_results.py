"""
analyze_results.py
==================

Turns the raw result files into every number, table and data figure of the
manuscript, so that each reported value is traceable to a result file.

Inputs (results_dir):
  hpatches_k300.jsonl, oxford_k300.jsonl      benchmark_shared_detector.py
  learned_native_hpatches.jsonl               learned_native_hpatches.py
  controlled_perturbation.jsonl               controlled_perturbation.py
  real_ablation.json                          real_ablation.py
  ../code/scripts/megadepth_real_results.json megadepth_real_evaluation.py (raw per-pair errors)
Outputs (paper_dir): results_macros.tex, tables/*.tex, figures/fig3..fig6 (PDF),
stats.json.

Usage: python analyze_results.py results_dir paper_dir code_scripts_dir
"""
import sys, os, json, math
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from phdesc.metrics import pose_auc

plt.rcParams.update({
    "font.family": "STIXGeneral", "mathtext.fontset": "stix", "font.size": 9,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5, "legend.fontsize": 7.5,
    "legend.frameon": False, "savefig.dpi": 600, "pdf.fonttype": 42,
    "axes.spines.top": False, "axes.spines.right": False,
})

P1 = ["PW-Desc", "PW-Desc-rank", "SIFT", "RawPatch", "GradHist", "ORB"]
STYLE = {  # monochrome: line style + marker + grey level
    "PW-Desc":      dict(color="black", ls="-",  marker="o", mfc="black"),
    "PW-Desc-rank": dict(color="black", ls="--", marker="o", mfc="white"),
    "SIFT":         dict(color="0.35",  ls="-",  marker="s", mfc="0.35"),
    "RawPatch":     dict(color="0.35",  ls=":",  marker="^", mfc="white"),
    "GradHist":     dict(color="0.55",  ls="-.", marker="D", mfc="white"),
    "ORB":          dict(color="0.65",  ls=(0, (5, 1, 1, 1, 1, 1)), marker="v", mfc="0.65"),
    "SuperPoint":   dict(color="0.2",   ls=(0, (1, 1)), marker="P", mfc="0.2"),
    "DISK":         dict(color="0.45",  ls=(0, (3, 1)), marker="X", mfc="0.45"),
}
HATCH = {"PW-Desc": "////", "PW-Desc-rank": "\\\\\\\\", "SIFT": "", "RawPatch": "....", "GradHist": "xx", "ORB": "--"}
FILL = {"PW-Desc": "0.25", "PW-Desc-rank": "white", "SIFT": "0.55", "RawPatch": "white", "GradHist": "0.85", "ORB": "0.95"}


def sci(x, digits=2):
    """Number for LaTeX: scientific notation below 0.1 (author preference), plain otherwise."""
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "--"
    if x == 0:
        return "0"
    if abs(x) < 0.1:
        e = int(math.floor(math.log10(abs(x))))
        m = x / 10 ** e
        if round(m, digits - 1) >= 10:
            m /= 10; e += 1
        return f"\\sci{{{m:.{digits - 1}f}}}{{{e}}}"
    if abs(x) >= 1e4:
        e = int(math.floor(math.log10(abs(x))))
        return f"\\sci{{{x / 10 ** e:.{digits - 1}f}}}{{{e}}}"
    return f"{x:.{digits + 1}f}" if abs(x) < 1 else f"{x:.{digits}f}"


def num(x, d=3):
    if x is None or (isinstance(x, float) and not math.isfinite(x)):
        return "--"
    return sci(x, 2) if abs(x) < 0.1 else f"{x:.{d}f}"


def load_jsonl(p):
    return [json.loads(l) for l in open(p)] if os.path.exists(p) else []


# ----------------------------------------------------------------- statistics
def seq_table(recs, methods, metric_fn):
    """per-sequence mean of a per-pair metric -> {method: {seq: value}}"""
    out = {m: {} for m in methods}
    for r in recs:
        for m in methods:
            if m in r["methods"]:
                out[m].setdefault(r["sequence"], []).append(metric_fn(r["methods"][m]))
    return {m: {s: float(np.mean(v)) for s, v in d.items()} for m, d in out.items()}


def cluster_boot_diff(a, b, n=10000, seed=0):
    rng = np.random.default_rng(seed)
    d = np.asarray(a) - np.asarray(b)
    idx = rng.integers(0, len(d), size=(n, len(d)))
    bs = d[idx].mean(axis=1)
    return float(d.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))


def rank_biserial(a, b):
    d = np.asarray(a) - np.asarray(b)
    d = d[d != 0]
    if len(d) == 0:
        return 0.0
    r = stats.rankdata(np.abs(d))
    return float((r[d > 0].sum() - r[d < 0].sum()) / r.sum())


def holm(pvals):
    order = np.argsort(pvals)
    m = len(pvals)
    adj = np.empty(m)
    run = 0.0
    for k, i in enumerate(order):
        run = max(run, min(1.0, (m - k) * pvals[i]))
        adj[i] = run
    return adj


def mce_ok(t):
    return lambda r: float(r.get("mean_corner_err") is not None and r["mean_corner_err"] <= t)


# ----------------------------------------------------------------- tables
def table_planar(H, O, L, out):
    """P1 results on HPatches (all / illumination / viewpoint) and Oxford; P2 reference rows."""
    def agg(recs, m, filt=lambda r: True):
        rs = [r["methods"][m] for r in recs if filt(r) and m in r["methods"]]
        if not rs:
            return None
        return dict(mma1=np.mean([x["mma"]["1"] for x in rs]), mma3=np.mean([x["mma"]["3"] for x in rs]),
                    mma5=np.mean([x["mma"]["5"] for x in rs]), ms=np.mean([x["matching_score"] for x in rs]),
                    ha3=np.mean([mce_ok(3)(x) for x in rs]), ha5=np.mean([mce_ok(5)(x) for x in rs]),
                    nm=np.mean([x["n_matches"] for x in rs]), n=len(rs))
    isI = lambda r: r["sequence"].startswith("i_")
    isV = lambda r: r["sequence"].startswith("v_")
    res = {}
    rows = []
    for proto, methods, recs in (("P1", P1, H), ("P2", ["SuperPoint", "DISK"], L)):
        for m in methods:
            a, i, v = agg(recs, m), agg(recs, m, isI), agg(recs, m, isV)
            o = agg(O, m) if proto == "P1" else None
            if a is None:
                continue
            res[m] = dict(all=a, illum=i, view=v, oxford=o)
            rows.append((proto, m, a, i, v, o))
    best = {k: max(r[2][k] for r in rows if r[0] == "P1") for k in ("mma1", "mma3", "mma5", "ms", "ha3", "ha5")}
    best_ox = {k: max(r[5][k] for r in rows if r[0] == "P1") for k in ("mma3", "ha5")}
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Planar matching, real images. P1: all descriptors at the same Harris keypoints ($K=" + str(KSH) + r"$ per image), so differences are due to the descriptor. P2: SuperPoint and DISK with their own detectors and the same budget; shown for reference, not ranked with P1. MMA@$t$: fraction of matches within $t$ pixels; MS: matching score; HA@$t$: fraction of pairs whose homography has a mean corner error of at most $t$ pixels. HPatches: 116 sequences, 580 pairs (i: 57 illumination, v: 59 viewpoint sequences); Oxford-Affine: 40 pairs. Best P1 value in bold.}",
             r"\label{tab:planar}", r"\setlength{\tabcolsep}{3.2pt}",
             r"\begin{tabular}{@{}llcccccccccc@{}}", r"\toprule",
             r" & & \multicolumn{6}{c}{HPatches, all pairs} & \multicolumn{2}{c}{MMA@3} & \multicolumn{2}{c}{Oxford-Affine} \\",
             r"\cmidrule(lr){3-8}\cmidrule(lr){9-10}\cmidrule(l){11-12}",
             r" & Method & MMA@1 & MMA@3 & MMA@5 & MS & HA@3 & HA@5 & i & v & MMA@3 & HA@5 \\", r"\midrule"]
    prev = None
    for proto, m, a, i, v, o in rows:
        if prev is not None and proto != prev:
            lines.append(r"\midrule")
        def f(x, k, b):
            s = num(x)
            return r"\textbf{" + s + "}" if (proto == "P1" and b is not None and abs(x - b[k]) < 1e-12) else s
        cells = [f(a[k], k, best) for k in ("mma1", "mma3", "mma5", "ms", "ha3", "ha5")]
        cells += [num(i["mma3"]), num(v["mma3"])]
        cells += [f(o["mma3"], "mma3", best_ox), f(o["ha5"], "ha5", best_ox)] if o else ["--", "--"]
        lines.append(f"{proto if proto != prev else ''} & {m} & " + " & ".join(cells) + r" \\")
        prev = proto
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    open(os.path.join(out, "tables", "tab_planar.tex"), "w").write("\n".join(lines) + "\n")
    return res


def table_stats(H, L, out):
    """Sequence-level paired comparisons on HPatches."""
    metrics = {"MMA@3": lambda r: r["mma"]["3"], "HA@5": mce_ok(5)}
    comps = [("PW-Desc-rank", "PW-Desc")] + [("PW-Desc-rank", b) for b in ("SIFT", "RawPatch", "GradHist", "ORB")]
    res = []
    for mname, fn in metrics.items():
        T = seq_table(H, P1, fn)
        seqs = sorted(T["PW-Desc"])
        raw_p = []
        block = []
        for a, b in comps:
            x = np.array([T[a][s] for s in seqs]); y = np.array([T[b][s] for s in seqs])
            mean, lo, hi = cluster_boot_diff(x, y)
            try:
                p = stats.wilcoxon(x, y, zero_method="wilcox").pvalue
            except ValueError:
                p = 1.0
            raw_p.append(p)
            block.append(dict(metric=mname, a=a, b=b, mean=mean, lo=lo, hi=hi, p=p, r=rank_biserial(x, y), n=len(seqs)))
        adj = holm(np.array(raw_p))
        for d, pa in zip(block, adj):
            d["p_holm"] = float(pa)
        res += block
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Paired comparisons on HPatches (protocol P1) with the sequence as statistical unit ($n=116$): mean per-sequence difference (first minus second method), 95\% cluster-bootstrap interval, Wilcoxon signed-rank $p$ after Holm correction within each metric, and rank-biserial effect size $r_{rb}$ ($-1$ to $1$).}",
             r"\label{tab:stats}", r"\begin{tabular}{@{}llcccc@{}}", r"\toprule",
             r"Metric & Comparison & Mean diff. & 95\% CI & $p_{\mathrm{Holm}}$ & $r_{rb}$ \\", r"\midrule"]
    prev = None
    for d in res:
        if prev is not None and d["metric"] != prev:
            lines.append(r"\midrule")
        p = d["p_holm"]
        ptxt = sci(p, 2) if p >= 1e-4 else r"$<\sci{1}{-4}$".replace("$", "")
        ptxt = ptxt if p >= 1e-4 else r"$<$" + r"\sci{1}{-4}"
        lines.append(f"{d['metric'] if d['metric'] != prev else ''} & {d['a']} $-$ {d['b']} & ${d['mean']:+.3f}$ & "
                     f"$[{d['lo']:+.3f},\\,{d['hi']:+.3f}]$ & {ptxt} & ${d['r']:+.2f}$ \\\\")
        prev = d["metric"]
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    open(os.path.join(out, "tables", "tab_stats.tex"), "w").write("\n".join(lines) + "\n")
    return res


def table_megadepth(md_path, out):
    d = json.load(open(md_path))["per_pair"]
    methods = ["PW-Desc", "PW-Desc-rank", "ORB", "SIFT", "SuperPoint", "DISK", "LoFTR"]
    res = {}
    for m in methods:
        e = np.array([d[k][m]["pose_err"] for k in d if m in d[k]], float)
        a = pose_auc(e, (5, 10, 20))
        ms = np.mean([d[k][m]["ms_per_kp"] for k in d if m in d[k]])
        res[m] = dict(auc5=a[5], auc10=a[10], auc20=a[20], n=len(e), ms_per_kp=float(ms),
                      median_err=float(np.median(e)))
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Wide-baseline relative pose on 40 evenly spaced pairs of the MegaDepth-1500 test split (images resized to 840 pixels on the long side). AUC of the pose error up to 5, 10 and $20^\circ$ (standard trapezoidal definition), and median pose error. PW-Desc, PW-Desc-rank: Harris keypoints (500 per image); ORB, SIFT, SuperPoint, DISK: own detectors; LoFTR: detector-free.}",
             r"\label{tab:megadepth}", r"\begin{tabular}{@{}lcccc@{}}", r"\toprule",
             r"Method & AUC@$5^\circ$ & AUC@$10^\circ$ & AUC@$20^\circ$ & Median error ($^\circ$) \\", r"\midrule"]
    for m in methods:
        r = res[m]
        lines.append(f"{m} & {num(r['auc5'])} & {num(r['auc10'])} & {num(r['auc20'])} & {r['median_err']:.1f} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    open(os.path.join(out, "tables", "tab_megadepth.tex"), "w").write("\n".join(lines) + "\n")
    return res


# ----------------------------------------------------------------- perturbation
def perturbation(C, out):
    names = ["PW-Desc", "PW-Desc-rank", "SIFT", "RawPatch", "GradHist"]
    eps = [0.005, 0.01, 0.02, 0.05, 0.1]
    gam = [0.5, 0.67, 1.5, 2.0]
    A = [c["part_a"] for c in C]
    agg = {"n_images": len(A), "n_kp": int(sum(a["n_kp"] for a in A)),
           "eta_min": float(min(a["eta_min"] for a in A)), "eta_median": float(np.median([a["eta_median"] for a in A]))}
    chk = {"cseh_pass": 0, "cseh_total": 0, "prop2_pass": 0, "lemma_pass": 0, "kp_total": 0, "rank_pass": 0, "rank_total": 0}
    ratio_max, tight_med, tight_max, rank_infl_med, rank_infl_p95 = [], {}, [], {}, {}
    curves = {n: {"noise": {}, "gamma": {}} for n in names}
    for a in A:
        for key, rec in a["perturbations"].items():
            kind, v = key.split("_"); v = float(v)
            c = rec["checks"]
            chk["cseh_pass"] += c["cseh_pass"]; chk["cseh_total"] += c["cseh_total"]
            chk["prop2_pass"] += c["prop2_pass"]; chk["lemma_pass"] += c["lemma_pass"]; chk["kp_total"] += c["total_kp"]
            chk["rank_pass"] += c["rank_pass"]; chk["rank_total"] += c["rank_total"]
            ratio_max.append(c["dB_over_delta_max"])
            tight_max.append(c["tightness_max"])
            if kind == "noise":
                tight_med.setdefault(v, []).append(c["tightness_median"])
                rank_infl_med.setdefault(v, []).append(c["rank_inflation_median"])
                rank_infl_p95.setdefault(v, []).append(c["rank_inflation_p95"])
            for n in names:
                curves[n][kind].setdefault(v, []).append((rec[n]["self_retrieval"], rec[n]["nu_median"], rec[n]["drift_median"]))
    agg.update(chk)
    agg["dB_over_delta_max"] = float(max(ratio_max))
    agg["tightness_max"] = float(max(tight_max))
    agg["tightness_median_by_eps"] = {str(k): float(np.median(v)) for k, v in tight_med.items()}
    agg["rank_inflation_median_by_eps"] = {str(k): float(np.median(v)) for k, v in rank_infl_med.items()}
    agg["rank_inflation_p95_by_eps"] = {str(k): float(np.median(v)) for k, v in rank_infl_p95.items()}
    summ = {n: {kind: {str(v): dict(self_retrieval=float(np.mean([x[0] for x in vals])),
                                     sr_lo=float(np.percentile(boot_mean([x[0] for x in vals]), 2.5)),
                                     sr_hi=float(np.percentile(boot_mean([x[0] for x in vals]), 97.5)),
                                     nu=float(np.median([x[1] for x in vals])),
                                     drift=float(np.median([x[2] for x in vals])))
                       for v, vals in d.items()} for kind, d in curves[n].items()} for n in names}
    agg["curves"] = summ

    # Part B: propagation
    B = [c["part_b"] for c in C]
    conds = ["clean", "noise_0.02", "noise_0.05", "noise_0.1", "gamma_0.5", "gamma_2.0"]
    prop = {}
    for n in P1:
        prop[n] = {}
        for cnd in conds:
            errs = [b[cnd][n]["mean_corner_err"] for b in B]
            e = np.array([x if x is not None else np.inf for x in errs])
            prop[n][cnd] = dict(median_mce=float(np.median(e)), ha3=float(np.mean(e <= 3)), ha5=float(np.mean(e <= 5)),
                                ha3_lo=float(np.percentile(boot_mean((e <= 3).astype(float)), 2.5)),
                                ha3_hi=float(np.percentile(boot_mean((e <= 3).astype(float)), 97.5)))
    agg["propagation"] = prop

    # --- Table: verification
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Verification of the certified sensitivity chain on real HPatches keypoints under bounded noise and gamma perturbations (protocol P3; " + f"{agg['n_images']} images, {agg['n_kp']} keypoints, 9 perturbations each" + r"). Each inequality is checked with the measured $\delta=\lVert P_s-P'_s\rVert_\infty$. Tightness is the ratio of the measured drift of the normalized descriptor to its certified bound.}",
             r"\label{tab:verify}", r"\begin{tabular}{@{}lc@{}}", r"\toprule", r"Quantity & Value \\", r"\midrule",
             f"Prop.~\\ref{{prop:cseh}}: $d_B\\le\\delta$, checks passed & {chk['cseh_pass']:,} / {chk['cseh_total']:,} \\\\".replace(",", "{,}"),
             f"Prop.~\\ref{{prop:stability}}, unnormalized bound, passed & {chk['lemma_pass']:,} / {chk['kp_total']:,} \\\\".replace(",", "{,}"),
             f"Prop.~\\ref{{prop:stability}}, normalized bound, passed & {chk['prop2_pass']:,} / {chk['kp_total']:,} \\\\".replace(",", "{,}"),
             f"Cor.~\\ref{{cor:rank-noise}}: rank change bound, passed & {chk['rank_pass']:,} / {chk['rank_total']:,} \\\\".replace(",", "{,}"),
             f"Largest measured $d_B/\\delta$ & {agg['dB_over_delta_max']:.3f} \\\\",
             f"Smallest $\\lVert\\tilde x\\rVert_2$ ($\\eta$ of Prop.~\\ref{{prop:stability}}) & {agg['eta_min']:.3f} \\\\",
             f"Tightness, median over keypoints ($\\varepsilon=\\sci{{2}}{{-2}}$) & {sci(agg['tightness_median_by_eps']['0.02'])} \\\\",
             f"Tightness, largest observed & {sci(agg['tightness_max'])} \\\\",
             f"Rank amplification $\\lVert r(P)-r(P')\\rVert_\\infty/\\delta$, median ($\\varepsilon=\\sci{{2}}{{-2}}$) & {agg['rank_inflation_median_by_eps']['0.02']:.1f} \\\\",
             r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    open(os.path.join(out, "tables", "tab_verify.tex"), "w").write("\n".join(lines) + "\n")

    # --- Table: propagation
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Propagation of a controlled perturbation of target image 2 into the registration of HPatches pairs (1,\,2) (58 sequences, protocol P1). Entries: HA@3, the fraction of pairs whose homography has a mean corner error of at most 3 pixels, and in parentheses the median mean corner error in pixels.}",
             r"\label{tab:propagation}", r"\setlength{\tabcolsep}{4pt}", r"\begin{tabular}{@{}lcccccc@{}}", r"\toprule",
             r"Method & clean & $\varepsilon=\sci{2}{-2}$ & $\varepsilon=\sci{5}{-2}$ & $\varepsilon=\sci{1}{-1}$ & $\gamma=0.5$ & $\gamma=2$ \\", r"\midrule"]
    for n in P1:
        cells = []
        for cnd in conds:
            p = prop[n][cnd]
            med = p["median_mce"]
            cells.append(f"{p['ha3']:.2f} ({med:.1f})" if math.isfinite(med) else f"{p['ha3']:.2f} (--)")
        lines.append(f"{n} & " + " & ".join(cells) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    open(os.path.join(out, "tables", "tab_propagation.tex"), "w").write("\n".join(lines) + "\n")

    # --- Figure: sensitivity curves
    fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.25), gridspec_kw=dict(width_ratios=[1, 1, 0.9]))
    for n in names:
        st = STYLE[n]
        xs = eps
        sr = [summ[n]["noise"][str(v)]["self_retrieval"] for v in xs]
        nu = [summ[n]["noise"][str(v)]["nu"] for v in xs]
        axs[0].plot(xs, sr, ls=st["ls"], color=st["color"], marker=st["marker"], mfc=st["mfc"], mec=st["color"], ms=4, lw=1, label=n)
        axs[1].plot(xs, nu, ls=st["ls"], color=st["color"], marker=st["marker"], mfc=st["mfc"], mec=st["color"], ms=4, lw=1)
    for ax in axs[:2]:
        ax.set_xscale("log"); ax.set_xlabel(r"noise bound $\varepsilon$")
    axs[0].set_ylabel("self-retrieval rate"); axs[0].set_ylim(0, 1.02)
    axs[1].set_ylabel(r"normalized drift $\nu$ (median)"); axs[1].set_yscale("log")
    axs[0].text(0.02, 0.03, "(a)", transform=axs[0].transAxes)
    axs[1].text(0.02, 0.9, "(b)", transform=axs[1].transAxes)
    # gamma panel: grouped bars of self-retrieval
    w = 0.16
    for i, n in enumerate(names):
        vals = [summ[n]["gamma"][str(g)]["self_retrieval"] for g in gam]
        axs[2].bar(np.arange(len(gam)) + (i - 2) * w, vals, width=w, color=FILL[n], edgecolor="black", lw=0.5, hatch=HATCH[n], label=n)
    axs[2].set_xticks(range(len(gam))); axs[2].set_xticklabels([r"$\gamma$=" + str(g) for g in gam])
    axs[2].set_ylabel("self-retrieval rate"); axs[2].set_ylim(0, 1.05)
    axs[2].text(0.02, 0.93, "(c)", transform=axs[2].transAxes)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=5, bbox_to_anchor=(0.5, 1.06), handlelength=2.6)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    fig.savefig(os.path.join(out, "figures", "fig3_sensitivity.pdf"), bbox_inches="tight")
    plt.close(fig)

    # --- Figure: propagation
    fig, ax = plt.subplots(figsize=(3.4, 2.3))
    xs_lab = ["clean", r"$\varepsilon$=0.02", r"$\varepsilon$=0.05", r"$\varepsilon$=0.1"]
    for n in P1:
        st = STYLE[n]
        ys = [prop[n][c]["ha3"] for c in conds[:4]]
        ax.plot(range(4), ys, ls=st["ls"], color=st["color"], marker=st["marker"], mfc=st["mfc"], mec=st["color"], ms=4, lw=1, label=n)
    ax.set_xticks(range(4)); ax.set_xticklabels(xs_lab)
    ax.set_ylabel("HA@3 (pairs 1-2)"); ax.set_ylim(0, 1.0)
    ax.legend(ncol=2, loc="upper right", handlelength=2.6)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "figures", "fig4_propagation.pdf"), bbox_inches="tight")
    plt.close(fig)
    return agg


def boot_mean(x, n=5000, seed=1):
    x = np.asarray(x, float)
    rng = np.random.default_rng(seed)
    return x[rng.integers(0, len(x), size=(n, len(x)))].mean(axis=1)


# ----------------------------------------------------------------- figures
def fig_mma(H, L, out):
    fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.2), sharey=True)
    thr = [1, 3, 5, 10]
    for ax, (title, filt) in zip(axs, (("all", lambda r: True), ("illumination", lambda r: r["sequence"].startswith("i_")),
                                        ("viewpoint", lambda r: r["sequence"].startswith("v_")))):
        for recs, methods in ((H, P1), (L, ["SuperPoint", "DISK"])):
            for m in methods:
                rs = [r["methods"][m] for r in recs if filt(r) and m in r["methods"]]
                if not rs:
                    continue
                ys = [np.mean([x["mma"][str(t)] for x in rs]) for t in thr]
                st = STYLE[m]
                ax.plot(thr, ys, ls=st["ls"], color=st["color"], marker=st["marker"], mfc=st["mfc"], mec=st["color"], ms=4, lw=1,
                        label=m + (" (P2)" if m in ("SuperPoint", "DISK") else ""))
        ax.set_xlabel("threshold $t$ (pixels)"); ax.set_xticks(thr)
        ax.set_title(f"HPatches, {title}", fontsize=9)
    axs[0].set_ylabel("MMA@$t$"); axs[0].set_ylim(0, 1)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=4, bbox_to_anchor=(0.5, 1.13), handlelength=2.6)
    fig.tight_layout(rect=(0, 0, 1, 0.9))
    fig.savefig(os.path.join(out, "figures", "fig5_mma.pdf"), bbox_inches="tight")
    plt.close(fig)


def fig_runtime(H, L, out):
    fig, ax = plt.subplots(figsize=(3.4, 2.4))
    pts = {}
    for m in P1:
        rs = [r["methods"][m] for r in H]
        pts[m] = (np.mean([x["ms_per_kp"] for x in rs]), np.mean([x["mma"]["3"] for x in rs]))
    for m in ("SuperPoint", "DISK"):
        rs = [r["methods"][m] for r in L if m in r["methods"]]
        if rs:
            pts[m] = (1000 * np.mean([x["seconds_per_image"] for x in rs]) / np.mean([x["n_kp_b"] for x in rs]),
                      np.mean([x["mma"]["3"] for x in rs]))
    for m, (t, a) in pts.items():
        st = STYLE[m]
        ax.scatter([t], [a], marker=st["marker"], facecolor=st["mfc"], edgecolor="black", s=28, lw=0.7, zorder=3)
        ax.annotate(m + (" (P2)" if m in ("SuperPoint", "DISK") else ""), (t, a), textcoords="offset points",
                    xytext=(5, -3 if m != "GradHist" else 4), fontsize=7.5)
    ax.set_xscale("log"); ax.set_xlabel("extraction time per keypoint (ms, CPU)")
    ax.set_ylabel("HPatches MMA@3"); ax.set_ylim(0, 1)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "figures", "fig6_runtime.pdf"), bbox_inches="tight")
    plt.close(fig)
    return {m: dict(ms_per_kp=float(t), mma3=float(a)) for m, (t, a) in pts.items()}


def table_ablation(A, out):
    if not A:
        return None
    ps = A["per_sequence"]
    order = [("full", r"Full: $H_0{+}H_1$, $s\in\{16,24,32\}$, $8{\times}8$, $\tau=0$ $\star$"),
             ("H0", r"$H_0$ only"), ("H1", r"$H_1$ only"),
             ("s16", r"single scale, $s=16$"), ("s24", r"single scale, $s=24$"), ("s32", r"single scale, $s=32$"),
             ("res4", r"resolution $4{\times}4$"), ("res16", r"resolution $16{\times}16$"),
             ("tau0.05", r"ramp threshold $\tau=0.05$"),
             ("proj_constrained", r"projection, $\lVert W\rVert_2\le1$ (trained on other sequences)"),
             ("proj_unconstrained", r"projection, unconstrained")]
    res = {}
    full_mma = {x["seq"]: x["mma3"] for x in ps["full"]}
    for k, _ in order:
        r = ps[k]
        mm = [x["mma3"] for x in r]
        d = np.array([x["mma3"] - full_mma[x["seq"]] for x in r])
        mean, lo, hi = cluster_boot_diff(d, np.zeros_like(d))
        res[k] = dict(mma3=float(np.mean(mm)), ha5=float(np.mean([x["ha5"] for x in r])),
                      sr=float(np.mean([x["self_retrieval"] for x in r])), nu=float(np.median([x["nu_median"] for x in r])),
                      dmma=mean, dlo=lo, dhi=hi)
    lines = [r"\begin{table}[t]", r"\centering\small",
             r"\caption{Real-data ablation on " + str(len(A["test_sequences"])) + r" HPatches sequences (every fourth, 145 pairs; protocol P1). $\Delta$MMA@3: mean per-sequence difference from the full configuration with 95\% cluster-bootstrap interval. Noise sensitivity on the reference images under $U[-0.02,0.02]$ noise: self-retrieval rate (SR, higher is better) and median normalized drift $\nu$ (lower is better). The projection was trained on a disjoint set of " + str(len(A["projection"]["train_sequences"])) + r" sequences.}",
             r"\label{tab:ablation}", r"\setlength{\tabcolsep}{3.5pt}", r"\begin{tabular}{@{}lccccc@{}}", r"\toprule",
             r"Configuration & MMA@3 & $\Delta$MMA@3 [95\% CI] & HA@5 & SR & $\nu$ \\", r"\midrule"]
    for k, lab in order:
        r = res[k]
        dtxt = "--" if k == "full" else f"${r['dmma']:+.3f}$ $[{r['dlo']:+.3f},{r['dhi']:+.3f}]$"
        lines.append(f"{lab} & {r['mma3']:.3f} & {dtxt} & {r['ha5']:.3f} & {r['sr']:.3f} & {r['nu']:.3f} \\\\")
        if k in ("full", "H1", "s32", "res16", "tau0.05"):
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    open(os.path.join(out, "tables", "tab_ablation.tex"), "w").write("\n".join(lines) + "\n")
    res["_proj"] = dict(train_pairs=A["projection"]["n_train_pairs"], norm_c=A["projection"]["constrained"]["spectral_norm"],
                        norm_u=A["projection"]["unconstrained"]["spectral_norm"], eta_W=A["eta_W"])
    return res


def main():
    rdir, pdir, sdir = sys.argv[1], sys.argv[2], sys.argv[3]
    os.makedirs(os.path.join(pdir, "tables"), exist_ok=True)
    os.makedirs(os.path.join(pdir, "figures"), exist_ok=True)
    H = load_jsonl(os.path.join(rdir, "hpatches_k300.jsonl"))
    O = load_jsonl(os.path.join(rdir, "oxford_k300.jsonl"))
    L = load_jsonl(os.path.join(rdir, "learned_native_hpatches.jsonl"))
    C = load_jsonl(os.path.join(rdir, "controlled_perturbation.jsonl"))
    A = json.load(open(os.path.join(rdir, "real_ablation.json"))) if os.path.exists(os.path.join(rdir, "real_ablation.json")) else None
    global KSH
    KSH = 300
    S = {"n_hpatches_pairs": len(H), "n_hpatches_seq": len({r["sequence"] for r in H}), "n_oxford_pairs": len(O),
         "n_learned_pairs": len(L), "n_perturb_seq": len(C)}
    S["planar"] = table_planar(H, O, L, pdir)
    S["stats"] = table_stats(H, L, pdir)
    S["megadepth"] = table_megadepth(os.path.join(sdir, "megadepth_real_results.json"), pdir)
    fig_mma(H, L, pdir)
    S["runtime"] = fig_runtime(H, L, pdir)
    if C:
        S["perturbation"] = perturbation(C, pdir)
    S["ablation"] = table_ablation(A, pdir)
    json.dump(S, open(os.path.join(pdir, "stats.json"), "w"), indent=1, default=float)
    print(json.dumps({k: v for k, v in S.items() if k.startswith("n_")}, indent=1))


if __name__ == "__main__":
    main()
