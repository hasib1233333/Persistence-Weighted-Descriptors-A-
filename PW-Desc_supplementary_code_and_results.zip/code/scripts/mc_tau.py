"""
mc_tau.py -- the Monte Carlo registration experiment of mc_measurement.py
(identical images, homographies, disturbances and seeds) for PW-Desc-rank
with the thresholded ramp weight, tau in {0.05, 0.1}. Motivated by the
cardinality term of Lemma 1: features of persistence at most tau receive
zero weight, which suppresses the many short-lived features created by noise.
Usage: python mc_tau.py /path/to/oxford out_dir [trials] [workers]
"""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
import json, time
from multiprocessing import Pool
import mc_measurement as M
from phdesc.descriptor import DescriptorConfig, compute_pw_descriptors_batch


def variant(tau):
    return (lambda im, kp: compute_pw_descriptors_batch(im, kp, DescriptorConfig(rank_normalize=True, backend="gudhi", tau=tau)), False)


M.METHODS = {"PW-Desc-rank-t0.05": variant(0.05), "PW-Desc-rank-t0.1": variant(0.1)}
M.RUN_PART_A = False

if __name__ == "__main__":
    root, out_dir = sys.argv[1], sys.argv[2]
    trials = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    workers = int(sys.argv[4]) if len(sys.argv) > 4 else 2
    imgs = []
    for s in sorted(os.listdir(root)):
        for k in (1, 4):
            p = os.path.join(root, s, f"img{k}.png")
            if os.path.exists(p):
                imgs.append(p)
    out_path = os.path.join(out_dir, "mc_tau.jsonl")
    t0 = time.time()
    with Pool(workers) as pool, open(out_path, "w") as f:
        for i, r in enumerate(pool.imap_unordered(M.run_image, [(p, imgs.index(p), trials) for p in imgs])):
            f.write(json.dumps(r) + "\n"); f.flush()
            print(f"[{i + 1}/{len(imgs)}] {r['image']} {time.time() - t0:.0f}s", flush=True)
