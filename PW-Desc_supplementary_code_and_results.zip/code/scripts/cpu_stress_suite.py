"""
cpu_stress_suite.py
=====================

Comprehensive CPU-only experiment suite, requiring no GPU and no external
datasets: fine-grained parameter sweeps (noise, blur, illumination, affine
shear, non-rigid elastic strain), a patch-size/resolution Pareto sweep,
and a keypoint-detector repeatability comparison using REAL, library-
standard implementations (OpenCV SIFT/ORB, scikit-image FAST/DoG-blob),
not reimplementations or literature-cited numbers.

Every number this script prints and saves is produced by actually running
the code in this repository. Run: python code/scripts/cpu_stress_suite.py
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np
from scipy import ndimage as ndi

from phdesc import (harris_keypoints, nn_ratio_match, mean_matching_accuracy,
                     compute_pw_descriptors_batch, DescriptorConfig)
from phdesc import baselines
from phdesc.profiling import (profile_single_descriptor, detect_fast, detect_dog_blob,
                               detect_cv2_sift, detect_cv2_orb,
                               cv2_sift_describe, cv2_orb_describe)
from synthetic_validation import make_synthetic_scene, random_homography, warp_image

import cv2


# ---------------------------------------------------------------------
# Descriptor batch wrappers (uniform interface: image, keypoints -> desc)
# ---------------------------------------------------------------------
def pw_batch(image, keypoints, scales=(16, 24, 32), resolution=8, rank=False):
    cfg = DescriptorConfig(scales=scales, resolution=resolution, rank_normalize=rank)
    return compute_pw_descriptors_batch(image, keypoints, cfg)


def raw_batch(image, keypoints):
    return baselines.batch_descriptor(baselines.raw_patch_descriptor, image, keypoints, size=16)


def gradhist_batch(image, keypoints):
    return baselines.batch_descriptor(baselines.gradient_histogram_descriptor, image, keypoints, size=16)


def sift_batch(image, keypoints):
    return cv2_sift_describe(image, keypoints)


def orb_batch(image, keypoints):
    return cv2_orb_describe(image, keypoints)


def match_and_score(da, db, kp_a, kp_b, H_gt, binary=False):
    if len(da) == 0 or len(db) == 0:
        return 0.0
    if binary:
        # Hamming-distance mutual nearest neighbour for ORB's binary descriptors
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        matches = bf.match(da, db)
        if len(matches) == 0:
            return 0.0
        idx_a = np.array([m.queryIdx for m in matches])
        idx_b = np.array([m.trainIdx for m in matches])
    else:
        m = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
        if len(m) == 0:
            return 0.0
        idx_a, idx_b = m[:, 0], m[:, 1]
    pts_a = kp_a[idx_a][:, ::-1].astype(np.float64)
    pts_b = kp_b[idx_b][:, ::-1].astype(np.float64)
    mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
    return mma[3]


METHODS = {
    "PW-Desc": (pw_batch, False),
    "PW-Desc-rank": (lambda im, kp: pw_batch(im, kp, rank=True), False),
    "RawPatch": (raw_batch, False),
    "GradHist": (gradhist_batch, False),
    "SIFT": (sift_batch, False),
    "ORB": (orb_batch, True),
}


def eval_condition(base, distorted, H_gt, kp_a=None):
    """Detect Harris keypoints (shared across methods) and evaluate every
    method in METHODS on this (base, distorted) pair. Returns dict of
    method -> MMA@3."""
    if kp_a is None:
        kp_a = harris_keypoints(base, max_keypoints=25, min_distance=8)
    kp_b = harris_keypoints(distorted, max_keypoints=25, min_distance=8)
    out = {}
    if len(kp_a) < 6 or len(kp_b) < 6:
        return {name: 0.0 for name in METHODS}, kp_a
    for name, (fn, binary) in METHODS.items():
        try:
            da = fn(base, kp_a)
            db = fn(distorted, kp_b)
            out[name] = match_and_score(da, db, kp_a, kp_b, H_gt, binary=binary)
        except Exception as e:
            out[name] = None
    return out, kp_a


# ---------------------------------------------------------------------
# Distortion generators
# ---------------------------------------------------------------------
def add_noise(img, sigma):
    rng = np.random.default_rng(int(sigma * 10000) + 1)
    return np.clip(img + rng.normal(0, sigma, size=img.shape), 0, 1)


def add_blur(img, ksize):
    if ksize <= 1:
        return img.copy()
    return ndi.gaussian_filter(img, sigma=ksize / 3.0)


def apply_gamma(img, gamma):
    return np.clip(img, 1e-6, 1.0) ** gamma


def apply_linear_gain(img, gain, bias=0.0):
    return np.clip(img * gain + bias, 0, 1)


def apply_spatial_gradient_light(img, strength):
    H, W = img.shape
    grad = np.linspace(1 - strength, 1 + strength, W)[None, :]
    return np.clip(img * grad, 0, 1)


def apply_affine_shear(img, angle_deg):
    from skimage.transform import AffineTransform, warp
    shear = np.deg2rad(angle_deg)
    t = AffineTransform(shear=shear)
    warped = warp(img, t.inverse, mode="reflect")
    return warped, t.params  # t.params IS the correct forward ground-truth homography


def apply_elastic(img, alpha, seed=0):
    rng = np.random.default_rng(seed)
    shape = img.shape
    dx = ndi.gaussian_filter((rng.random(shape) * 2 - 1), 10) * alpha
    dy = ndi.gaussian_filter((rng.random(shape) * 2 - 1), 10) * alpha
    yy, xx = np.mgrid[0:shape[0], 0:shape[1]]
    coords = np.array([yy + dy, xx + dx])
    return ndi.map_coordinates(img, coords, order=1, mode="reflect")


N_SCENES = 2
SCENE_SIZE = 140


def make_scenes():
    return [make_synthetic_scene(size=SCENE_SIZE, n_shapes=25, seed=s) for s in range(N_SCENES)]


def run_sweep(name, levels, distort_fn, identity_H=True):
    print(f"\n=== Sweep: {name} ===")
    scenes = make_scenes()
    results = {str(lv): {m: [] for m in METHODS} for lv in levels}
    H_gt = np.eye(3)
    for scene_idx, base in enumerate(scenes):
        for lv in levels:
            distorted = distort_fn(base, lv)
            scores, _ = eval_condition(base, distorted, H_gt)
            for m, v in scores.items():
                if v is not None:
                    results[str(lv)][m].append(v)
        print(f"  scene {scene_idx+1}/{N_SCENES} done")
    summary = {lv: {m: float(np.mean(vs)) if vs else None for m, vs in md.items()}
               for lv, md in results.items()}
    return summary


def run_affine_sweep(angles):
    print(f"\n=== Sweep: affine shear ===")
    scenes = make_scenes()
    results = {str(a): {m: [] for m in METHODS} for a in angles}
    for scene_idx, base in enumerate(scenes):
        for a in angles:
            distorted, H_gt = apply_affine_shear(base, a)
            scores, _ = eval_condition(base, distorted, H_gt)
            for m, v in scores.items():
                if v is not None:
                    results[str(a)][m].append(v)
        print(f"  scene {scene_idx+1}/{N_SCENES} done")
    summary = {a: {m: float(np.mean(vs)) if vs else None for m, vs in md.items()}
               for a, md in results.items()}
    return summary


def run_elastic_sweep(alphas):
    print(f"\n=== Sweep: elastic strain ===")
    scenes = make_scenes()
    results = {str(a): {m: [] for m in METHODS} for a in alphas}
    for scene_idx, base in enumerate(scenes):
        for a in alphas:
            distorted = apply_elastic(base, a, seed=scene_idx * 100 + int(a * 10))
            H_gt = np.eye(3)
            scores, _ = eval_condition(base, distorted, H_gt)
            for m, v in scores.items():
                if v is not None:
                    results[str(a)][m].append(v)
        print(f"  scene {scene_idx+1}/{N_SCENES} done")
    summary = {a: {m: float(np.mean(vs)) if vs else None for m, vs in md.items()}
               for a, md in results.items()}
    return summary


def run_component_timing():
    print("\n=== Component-wise timing breakdown ===")
    rng = np.random.default_rng(0)
    img = make_synthetic_scene(size=140, n_shapes=25, seed=0)
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8)
    _ = profile_single_descriptor(img, 70, 70, cfg)  # warm cache
    kps = harris_keypoints(img, max_keypoints=20, min_distance=8)
    trials = [profile_single_descriptor(img, int(y), int(x), cfg) for (y, x) in kps]
    keys = trials[0].keys()
    summary = {k: dict(mean_ms=float(np.mean([t[k] for t in trials])),
                        std_ms=float(np.std([t[k] for t in trials])))
               for k in keys}
    for k, v in summary.items():
        print(f"  {k}: {v['mean_ms']:.3f} +/- {v['std_ms']:.3f} ms")
    return summary


def run_patch_size_sweep(sizes, resolution=8):
    print("\n=== Patch-size / Pareto sweep ===")
    scenes = make_scenes()
    results = {}
    for size in sizes:
        mmas, times = [], []
        for scene_idx, base in enumerate(scenes):
            H_gt = random_homography(SCENE_SIZE, max_shift=10, seed=300 + scene_idx)
            warped = np.clip(warp_image(base, H_gt), 0, 1)
            kp_a = harris_keypoints(base, max_keypoints=25, min_distance=8)
            kp_b = harris_keypoints(warped, max_keypoints=25, min_distance=8)
            if len(kp_a) < 6 or len(kp_b) < 6:
                continue
            cfg = DescriptorConfig(scales=(size,), resolution=resolution)
            t0 = time.time()
            da = compute_pw_descriptors_batch(base, kp_a, cfg)
            db = compute_pw_descriptors_batch(warped, kp_b, cfg)
            dt = (time.time() - t0) / max(len(kp_a) + len(kp_b), 1) * 1000
            times.append(dt)
            score = match_and_score(da, db, kp_a, kp_b, H_gt, binary=False)
            mmas.append(score)
        results[size] = dict(mean_mma3=float(np.mean(mmas)) if mmas else 0.0,
                              mean_ms_per_kp=float(np.mean(times)) if times else 0.0)
        print(f"  size={size}: MMA@3={results[size]['mean_mma3']:.3f}, "
              f"time={results[size]['mean_ms_per_kp']:.2f} ms/kp")
    return results


def run_detector_repeatability():
    print("\n=== Detector repeatability comparison ===")
    from phdesc import metrics as M
    scenes = make_scenes()
    detectors = {
        "Harris (ours, from scratch)": lambda im: harris_keypoints(im, max_keypoints=100, min_distance=8),
        "FAST (skimage)": lambda im: detect_fast(im, max_keypoints=100),
        "DoG-blob (skimage)": lambda im: detect_dog_blob(im, max_keypoints=100),
        "SIFT detector (OpenCV)": lambda im: detect_cv2_sift(im, max_keypoints=100).astype(np.int64) if len(detect_cv2_sift(im)) else np.zeros((0, 2), dtype=np.int64),
        "ORB detector (OpenCV)": lambda im: detect_cv2_orb(im, max_keypoints=100).astype(np.int64) if len(detect_cv2_orb(im)) else np.zeros((0, 2), dtype=np.int64),
    }
    results = {name: [] for name in detectors}
    n_kps = {name: [] for name in detectors}
    for scene_idx, base in enumerate(scenes):
        H_gt = random_homography(SCENE_SIZE, max_shift=10, seed=400 + scene_idx)
        warped = np.clip(warp_image(base, H_gt), 0, 1)
        for name, fn in detectors.items():
            kp_a = fn(base)
            kp_b = fn(warped)
            n_kps[name].append(len(kp_a))
            if len(kp_a) == 0 or len(kp_b) == 0:
                results[name].append(0.0)
                continue
            rep = M.repeatability(np.array(kp_a), np.array(kp_b), H_gt, base.shape, pixel_thresh=3.0)
            results[name].append(rep)
        print(f"  scene {scene_idx+1}/{N_SCENES} done")
    summary = {name: dict(mean_repeatability=float(np.mean(v)), mean_n_keypoints=float(np.mean(n_kps[name])))
               for name, v in results.items()}
    return summary


def main():
    out = {}
    out_path = os.path.join(os.path.dirname(__file__), "cpu_stress_suite_results.json")

    def checkpoint():
        with open(out_path, "w") as f:
            json.dump(out, f, indent=2)
        print(f"  [checkpoint saved -> {out_path}]")

    out["component_timing"] = run_component_timing(); checkpoint()
    out["detector_repeatability"] = run_detector_repeatability(); checkpoint()
    out["patch_size_sweep"] = run_patch_size_sweep([15, 21, 31, 41], resolution=8); checkpoint()
    out["noise_sweep"] = run_sweep("gaussian_noise", [0.0, 0.07, 0.14, 0.2], add_noise); checkpoint()
    out["blur_sweep"] = run_sweep("gaussian_blur", [1, 3, 6, 9], add_blur); checkpoint()
    out["gamma_sweep"] = run_sweep("gamma", [1.0, 0.6, 1.8, 3.0], apply_gamma); checkpoint()
    out["affine_shear_sweep"] = run_affine_sweep([0, 15, 30, 45]); checkpoint()
    out["elastic_strain_sweep"] = run_elastic_sweep([0, 3, 6, 9]); checkpoint()

    print(f"\n\nAll sweeps complete. Saved -> {out_path}")


if __name__ == "__main__":
    main()
