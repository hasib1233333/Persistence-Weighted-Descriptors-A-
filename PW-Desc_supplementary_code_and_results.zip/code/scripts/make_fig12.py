"""
make_fig12.py
=============

Computes every data panel of Figs. 1 and 2 of the manuscript from one real
keypoint of the Oxford-Affine image boat/img1 (resized to 640 pixels and
quantized to 8 bits, exactly as in the experiments), using the released
descriptor code. The TikZ files figures/fig1_pipeline.tex and
figures/fig2_theory.tex arrange the panels and draw the schematic parts.
All numbers quoted in the two figures and their captions are written to
figures/fig12_values.tex.

Monochrome, serif (STIX) fonts, vector PDF; raster panels (image patches,
persistence images) are embedded at their native pixel resolution.

Usage: python make_fig12.py /path/to/oxford out_dir
"""
import sys, os, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon

from phdesc.descriptor import extract_patch, rank_normalize_patch, persistence_image
from phdesc.persistence import PersistenceDiagram
from phdesc.fastph import diagrams
from mc_measurement import load_resized

plt.rcParams.update({
    "font.family": "STIXGeneral", "mathtext.fontset": "stix", "font.size": 8,
    "axes.linewidth": 0.5, "xtick.major.width": 0.5, "ytick.major.width": 0.5,
    "xtick.major.size": 2, "ytick.major.size": 2, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "axes.labelsize": 8, "axes.labelpad": 1.5, "savefig.dpi": 600, "pdf.fonttype": 42,
    "lines.linewidth": 0.7,
})
CM = 1 / 2.54
SCALES = (16, 24, 32)
R = 8
SIG = 1.0 / R
KEY = (197, 397)          # Harris keypoint of boat/img1 with many long-lived H0 and H1 features
EPS = 0.03                # noise bound of Fig. 2 (2*delta < tau = 0.1, so Proposition 4 applies)
TAU = 0.1


def Kc(tau):
    return 2.0 / (1.0 - tau) + np.sqrt(5) / (SIG * np.sqrt(np.e))


def save(fig, out, name):
    fig.savefig(os.path.join(out, name), bbox_inches=None, pad_inches=0)
    plt.close(fig)


def raster(arr, out, name, w_cm, vmin=0, vmax=1, grid=False, frame=True):
    h, w = arr.shape
    fig = plt.figure(figsize=(w_cm * CM, w_cm * CM * h / w))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.imshow(arr, cmap="gray_r" if grid else "gray", vmin=vmin, vmax=vmax, interpolation="nearest")
    if grid:
        for k in range(1, w):
            ax.axvline(k - 0.5, color="0.55", lw=0.25)
        for k in range(1, h):
            ax.axhline(k - 0.5, color="0.55", lw=0.25)
    ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_visible(frame); sp.set_linewidth(0.6)
    save(fig, out, name)


def axes_cm(w, h, l=0.85, b=0.78, r=0.1, t=0.1):
    fig = plt.figure(figsize=(w * CM, h * CM))
    ax = fig.add_axes([l / w, b / h, (w - l - r) / w, (h - b - t) / h])
    return fig, ax


def diag_axes(w_cm, h_cm, xlabel="birth $b$", ylabel="death $d$", lim=(0, 1)):
    fig, ax = axes_cm(w_cm, w_cm - 0.85 - 0.1 + 0.78 + 0.1)
    ax.plot(lim, lim, color="black", lw=0.5, ls=(0, (3, 2)))
    ax.set_xlim(*lim); ax.set_ylim(*lim)
    ax.set_xticks([0, 0.5, 1]); ax.set_yticks([0, 0.5, 1]); ax.set_xticklabels(["0", "0.5", "1"]); ax.set_yticklabels(["0", "0.5", "1"])
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    return fig, ax


def pi(D, tau=0.0):
    return persistence_image(PersistenceDiagram(0, D), (0, 1), (0, 1), R, tau=tau)


def block_vec(Ps, tau):
    v = []
    for P in Ps:
        d0, d1 = diagrams(P)
        v += [pi(d0, tau).ravel(), pi(d1, tau).ravel()]
    return np.concatenate(v)


def main():
    root, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    I = load_resized(os.path.join(root, "boat", "img1.png"))
    y, x = KEY
    V = {}

    # ------------------------------------------------------------- Fig. 1
    # (a) image with keypoint and the three patch windows
    H, W = I.shape
    w_cm = 3.3
    fig = plt.figure(figsize=(w_cm * CM, w_cm * CM * H / W))
    ax = fig.add_axes([0, 0, 1, 1]); ax.imshow(I, cmap="gray", vmin=0, vmax=1, interpolation="lanczos")
    for s, ls in zip(SCALES, ((0, (1.2, 1.2)), (0, (3, 1.5)), "-")):
        for col, lw in (("white", 1.6), ("black", 0.7)):
            ax.add_patch(Rectangle((x - s / 2 - 0.5, y - s / 2 - 0.5), s, s, fill=False, ec=col, lw=lw, ls=ls if col == "black" else "-"))
    ax.plot([x], [y], marker="+", color="white", ms=5, mew=1.6); ax.plot([x], [y], marker="+", color="black", ms=4, mew=0.7)
    ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_linewidth(0.6)
    save(fig, out, "f1_image.pdf")
    V["ImgH"], V["ImgW"], V["KeyY"], V["KeyX"] = H, W, y, x

    Ps = [extract_patch(I, y, x, s) for s in SCALES]
    for s, P in zip(SCALES, Ps):
        raster(P, out, f"f1_patch{s}.pdf", 0.55 * s / 16)
    P = Ps[2]
    Rk = rank_normalize_patch(P)
    raster(Rk, out, "f1_rank32.pdf", 1.65)

    # (d) cubical complex on a 3x3 block of real pixel values (values for TikZ)
    blk = P[14:17, 14:17]
    q = np.round(blk * 255).astype(int)
    for i in range(3):
        for j in range(3):
            V[f"Px{i}{j}"] = f"{blk[i, j]:.2f}"
    V["EdgeVal"] = f"{max(blk[0, 0], blk[0, 1]):.2f}"
    V["SqVal"] = f"{blk[0:2, 0:2].max():.2f}"

    # (e) sublevel sets of P at four thresholds (quantiles)
    d0, d1 = diagrams(P)
    ts = np.quantile(P, [0.2, 0.4, 0.6, 0.8])
    for k, t in enumerate(ts):
        raster((P <= t).astype(float) * -1 + 1, out, f"f1_sub{k}.pdf", 1.0)
        V[f"T{k}"] = f"{t:.2f}"

    # (f) diagrams
    fig, ax = diag_axes(2.9, 2.9)
    ax.scatter(d0[:, 0], d0[:, 1], s=6, marker="o", facecolor="black", edgecolor="black", lw=0.4, label="$D_0$", zorder=3)
    ax.scatter(d1[:, 0], d1[:, 1], s=8, marker="^", facecolor="white", edgecolor="black", lw=0.5, label="$D_1$", zorder=3)
    ax.legend(loc="lower right", frameon=False, handletextpad=0.1, borderaxespad=0.1, fontsize=7)
    save(fig, out, "f1_diag.pdf")
    V["NzeroDiag"], V["NoneDiag"] = len(d0), len(d1)

    # (g) birth-persistence plane
    fig, ax = axes_cm(2.9, 2.9)
    ax.scatter(d0[:, 0], d0[:, 1] - d0[:, 0], s=6, marker="o", facecolor="black", edgecolor="black", lw=0.4, zorder=3)
    ax.scatter(d1[:, 0], d1[:, 1] - d1[:, 0], s=8, marker="^", facecolor="white", edgecolor="black", lw=0.5, zorder=3)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.set_xticks([0, 0.5, 1]); ax.set_yticks([0, 0.5, 1])
    ax.set_xticklabels(["0", "0.5", "1"]); ax.set_yticklabels(["0", "0.5", "1"])
    ax.set_xlabel("birth $b$"); ax.set_ylabel("persistence $p$")
    save(fig, out, "f1_bp.pdf")
    # (h) weight function
    fig, ax = axes_cm(2.2, 2.9)
    pp = np.linspace(0, 1, 400)
    ax.plot(pp, np.clip(pp, 0, 1), color="black", lw=0.8, label=r"$\tau=0$")
    ax.plot(pp, np.clip((pp - TAU) / (1 - TAU), 0, 1), color="black", lw=0.8, ls=(0, (3, 1.5)), label=r"$\tau=0.1$")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.05); ax.set_xticks([0, 0.5, 1]); ax.set_yticks([0, 0.5, 1])
    ax.set_xticklabels(["0", "0.5", "1"]); ax.set_yticklabels(["0", "0.5", "1"])
    ax.set_xlabel("persistence $p$"); ax.set_ylabel("weight $w(p)$")
    ax.legend(frameon=False, fontsize=6, loc="upper left", handlelength=1.3, handletextpad=0.3, borderaxespad=0.1)
    save(fig, out, "f1_w.pdf")

    # (h) persistence images
    p0, p1 = pi(d0), pi(d1)
    vmax = max(p0.max(), p1.max())
    raster(p0[::-1], out, "f1_pi0.pdf", 1.25, vmin=0, vmax=vmax, grid=True)
    raster(p1[::-1], out, "f1_pi1.pdf", 1.25, vmin=0, vmax=vmax, grid=True)

    # (i) descriptor strip (384 entries, block boundaries)
    xt = block_vec(Ps, 0.0)
    nx = np.linalg.norm(xt)
    fig = plt.figure(figsize=(4.6 * CM, 0.8 * CM))
    ax = fig.add_axes([0.0, 0.05, 1.0, 0.9])
    ax.bar(np.arange(384), xt / xt.max(), width=1.0, color="black", lw=0)
    for b in range(1, 6):
        ax.axvline(64 * b - 0.5, color="0.5", lw=0.5, ls=(0, (2, 1)))
    ax.set_xlim(-0.5, 383.5); ax.set_ylim(0, 1.05); ax.axis("off")
    save(fig, out, "f1_strip.pdf")
    V["XtNorm"] = f"{nx:.2f}"

    # ------------------------------------------------------------- Fig. 2
    rng = np.random.default_rng(3)
    J = np.clip(I + rng.uniform(-EPS, EPS, I.shape), 0, 1)
    Qs = [extract_patch(J, y, x, s) for s in SCALES]
    deltas = [float(np.max(np.abs(a - b))) for a, b in zip(Ps, Qs)]
    delta = max(deltas)
    Q = Qs[2]
    e0, e1 = diagrams(Q)
    raster(P, out, "f2_P.pdf", 1.9)
    raster(Q, out, "f2_Q.pdf", 1.9)
    raster(np.abs(Q - P) / delta, out, "f2_diff.pdf", 1.9)
    V["Delta"] = f"{delta:.3f}"; V["Eps"] = f"{EPS:.2f}"; V["Tau"] = f"{TAU:.1f}"

    import gudhi
    for k, (D, E, name, mk) in enumerate(((d0, e0, "f2_d0.pdf", "o"), (d1, e1, "f2_d1.pdf", "^"))):
        fig, ax = diag_axes(3.3, 3.3)
        band = Polygon([[0, 0], [1, 1], [1 - 2 * delta, 1], [0, 2 * delta]], closed=True, fc="0.85", ec="none", zorder=0)
        ax.add_patch(band)
        for (b, d) in D:
            ax.add_patch(Rectangle((b - delta, d - delta), 2 * delta, 2 * delta, fill=False, ec="0.35", lw=0.35, zorder=1))
        ax.scatter(D[:, 0], D[:, 1], s=7, marker=mk, facecolor="black", edgecolor="black", lw=0.4, zorder=3)
        ax.scatter(E[:, 0], E[:, 1], s=9, marker=mk, facecolor="white", edgecolor="black", lw=0.5, zorder=4)
        save(fig, out, name)
        V[f"Bott{k}"] = f"{gudhi.bottleneck_distance(D, E):.3f}"
        V[f"Nclean{k}"], V[f"Nnoisy{k}"] = len(D), len(E)

    # (e) Proposition 4: which clean points are counted
    fig, ax = axes_cm(3.6, 3.3, l=0.95)
    th = TAU - 2 * delta
    allD = [(d0, "o"), (d1, "^")]
    for D, mk in allD:
        p = D[:, 1] - D[:, 0]
        c = p > th
        ax.scatter(D[c, 0], p[c], s=8 if mk == "^" else 6, marker=mk, facecolor="black", edgecolor="black", lw=0.4, zorder=3)
        ax.scatter(D[~c, 0], p[~c], s=8 if mk == "^" else 6, marker=mk, facecolor="white", edgecolor="0.4", lw=0.4, zorder=2)
    ax.axhline(TAU, color="black", lw=0.6)
    ax.axhline(th, color="black", lw=0.6, ls=(0, (3, 1.5)))
    ax.axhspan(0, 2 * delta, color="0.88", lw=0, zorder=0)
    ax.text(0.985, 0.685, r"solid: $p=\tau$" + "\n" + r"dashed: $p=\tau-2\delta$" + "\n" + r"grey: $p\leq2\delta$", ha="right", va="top", fontsize=6.3,
            bbox=dict(fc="white", ec="0.6", lw=0.4, pad=1.5))
    ax.set_xlim(0, 1); ax.set_ylim(0, 0.7); ax.set_xticks([0, 0.5, 1]); ax.set_xticklabels(["0", "0.5", "1"])
    ax.set_yticks([0, 0.25, 0.5]); ax.set_yticklabels(["0", "0.25", "0.5"])
    ax.set_xlabel("birth $b$"); ax.set_ylabel("persistence $p$")
    save(fig, out, "f2_thr.pdf")
    n_cnt = sum(int(np.sum((D[:, 1] - D[:, 0]) > th)) for D, _ in allD)
    V["Ncount"] = n_cnt; V["Nall"] = len(d0) + len(d1) + len(e0) + len(e1)

    # (f),(g) change of the persistence images for tau = 0 and tau = 0.1 (H0, s = 32)
    c0 = np.abs(pi(d0) - pi(e0)); c1 = np.abs(pi(d0, TAU) - pi(e0, TAU))
    vm = max(c0.max(), c1.max())
    raster(c0[::-1], out, "f2_chg0.pdf", 1.45, vmin=0, vmax=vm, grid=True)
    raster(c1[::-1], out, "f2_chg1.pdf", 1.45, vmin=0, vmax=vm, grid=True)
    V["ChgMaxZero"] = f"{c0.max():.3f}"; V["ChgMaxTau"] = f"{c1.max():.3f}"

    # (h) drift against the two bounds, full descriptor at this keypoint
    rows = {}
    for tau in (0.0, TAU):
        a, b = block_vec(Ps, tau), block_vec(Qs, tau)
        drift = float(np.linalg.norm(a - b))
        card = thr = 0.0
        for j, (Pc, Pn) in enumerate(zip(Ps, Qs)):
            dc, dn = diagrams(Pc), diagrams(Pn)
            for kk in (0, 1):
                card += (R * Kc(tau) * (len(dc[kk]) + len(dn[kk])) * delta) ** 2
                if tau > 0:
                    thr += (R * Kc(tau) * np.sum((dc[kk][:, 1] - dc[kk][:, 0]) > tau - 2 * delta) * delta) ** 2
        rows[tau] = dict(drift=drift, card=np.sqrt(card), thr=np.sqrt(thr) if tau > 0 else np.sqrt(card))
    fig, ax = axes_cm(4.6, 3.5, l=1.0, t=0.5)
    labels = [r"$\tau=0$", r"$\tau=%.1f$" % TAU]
    xs = np.arange(2)
    bw = 0.26
    hatches = ["", "////", "...."]
    names = ["drift", "Prop. 2", "Prop. 4"]
    for j, key in enumerate(("drift", "card", "thr")):
        vals = [rows[0.0][key], rows[TAU][key]]
        if key == "thr":
            vals[0] = np.nan
        ax.bar(xs + (j - 1) * bw, vals, bw, color="black" if j == 0 else "white", edgecolor="black", hatch=hatches[j], lw=0.5, label=names[j])
    ax.set_yscale("log"); ax.set_ylim(1e-2, 3e3)
    ax.set_xticks(xs); ax.set_xticklabels(labels)
    ax.set_ylabel(r"$\|\tilde x(P)-\tilde x(P')\|_2$")
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), frameon=False, fontsize=6.3, ncol=3, handlelength=1.1, columnspacing=0.5, handletextpad=0.3, borderaxespad=0.15)
    save(fig, out, "f2_bars.pdf")
    for tau, tag in ((0.0, "Zero"), (TAU, "Tau")):
        V[f"Drift{tag}"] = f"{rows[tau]['drift']:.3f}"; V[f"Card{tag}"] = f"{rows[tau]['card']:.0f}"; V[f"Thr{tag}"] = f"{rows[tau]['thr']:.0f}"

    with open(os.path.join(out, "..", "fig12_values.tex"), "w") as f:
        f.write("% generated by code/scripts/make_fig12.py\n")
        for k, v in V.items():
            kk = k.translate(str.maketrans("0123456789", "ABCDEFGHIJ"))
            f.write(f"\\newcommand{{\\Fig{kk}}}{{{v}}}\n")
    json.dump({k: (v if isinstance(v, str) else int(v)) for k, v in V.items()}, open(os.path.join(out, "values.json"), "w"), indent=1)
    print(V)


if __name__ == "__main__":
    main()
