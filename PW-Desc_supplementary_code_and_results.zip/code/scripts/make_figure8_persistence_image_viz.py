import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from phdesc.persistence import compute_persistence_diagrams
from phdesc.descriptor import persistence_image, extract_patch, compute_pw_descriptor, DescriptorConfig
from synthetic_validation import make_synthetic_scene

# Example 1: analytic annulus (exact ground truth)
N = 21
cy, cx = N // 2, N // 2
yy, xx = np.mgrid[0:N, 0:N]
r = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
annulus = np.full((N, N), 5.0)
annulus[r <= 8.0] = 2.0
annulus[r <= 5.0] = 5.0
annulus[(r > 5.0) & (r <= 8.0)] = 0.0
pd0_a, pd1_a = compute_persistence_diagrams(annulus)

# Example 2: a real patch from the synthetic validation scene
scene = make_synthetic_scene(size=160, n_shapes=30, seed=3)
scene_n = (scene - scene.min()) / (scene.max() - scene.min() + 1e-9)
patch_b = extract_patch(scene_n, 64, 96, 32)
pd0_b, pd1_b = compute_persistence_diagrams(patch_b)

fig, axes = plt.subplots(2, 4, figsize=(14, 6.6))

for row, (patch, pd0, pd1, brange, prange, title) in enumerate([
        (annulus, pd0_a, pd1_a, (0.0, 5.0), (0.0, 5.0), "Analytic annulus (exact ground truth)"),
        (patch_b, pd0_b, pd1_b, (0.0, 1.0), (0.0, 1.0), "Real patch, synthetic scene (seed=3, y=64,x=96)")]):

    ax = axes[row, 0]
    im = ax.imshow(patch, cmap="viridis")
    ax.set_title(f"{title}\nInput patch $P$", fontsize=9)
    ax.set_xticks([]); ax.set_yticks([])
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    ax = axes[row, 1]
    f1 = pd1.finite()
    lims = [brange[0] - 0.05 * (brange[1] - brange[0]), brange[1] + 0.2 * (brange[1] - brange[0])]
    if len(f1):
        life = f1[:, 1] - f1[:, 0]
        sizes = 25 + 200 * (life / (life.max() + 1e-9))
        sc = ax.scatter(f1[:, 0], f1[:, 1], s=sizes, c=life, cmap="magma", edgecolor="k", linewidth=0.3)
        plt.colorbar(sc, ax=ax, fraction=0.046, pad=0.04, label="lifetime")
    else:
        ax.text(0.5, 0.5, "no finite\n$H_1$ features", ha="center", va="center", transform=ax.transAxes)
    ax.plot(lims, lims, "k--", linewidth=0.8)
    ax.set_xlim(lims); ax.set_ylim(lims)
    ax.set_xlabel("birth"); ax.set_ylabel("death")
    ax.set_title("Step 1: $H_1$ persistence\ndiagram $D_1(P)$", fontsize=9)

    ax = axes[row, 2]
    img1 = persistence_image(pd1, brange, prange, resolution=8)
    im2 = ax.imshow(img1, origin="lower", cmap="magma",
                     extent=[brange[0], brange[1], prange[0], prange[1]])
    ax.set_xlabel("birth"); ax.set_ylabel("persistence")
    ax.set_title("Step 2: persistence image\n$\\rho(D_1(P))$, $8\\times8$", fontsize=9)
    plt.colorbar(im2, ax=ax, fraction=0.046, pad=0.04)

    ax = axes[row, 3]
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8)
    y_c, x_c = patch.shape[0] // 2, patch.shape[1] // 2
    # embed the small analytic patch in a larger canvas for multi-scale extraction if needed
    if patch.shape[0] < 32:
        canvas = np.zeros((64, 64))
        canvas[:patch.shape[0], :patch.shape[1]] = patch / patch.max()
        desc = compute_pw_descriptor(canvas, 32, 32, cfg)
    else:
        desc = compute_pw_descriptor(patch, y_c, x_c, cfg)
    im3 = ax.imshow(desc.reshape(1, -1), aspect="auto", cmap="coolwarm")
    ax.set_yticks([])
    ax.set_xlabel("descriptor dimension (384)")
    ax.set_title("Step 3: full concatenated\ndescriptor vector (heatmap)", fontsize=9)
    plt.colorbar(im3, ax=ax, fraction=0.02, pad=0.04)

fig.suptitle("Persistence image visualization: diagram $\\to$ image $\\to$ descriptor heatmap "
             "(both rows: real computed output)", fontsize=11.5, y=1.03)
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure8.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
