"""
merge_mc16.py -- merges trials 0-7 (mc_measurement.jsonl, mc_tau.jsonl) with
trials 8-15 (mc_more.jsonl) into results16/, which analyze_mc.py then reads
in place of results/. Other result files are linked unchanged.
Usage: python merge_mc16.py results results16
"""
import sys, os, json
src, dst = sys.argv[1], sys.argv[2]
os.makedirs(dst, exist_ok=True)
load = lambda f: [json.loads(l) for l in open(os.path.join(src, f))]
M, T, X = load("mc_measurement.jsonl"), load("mc_tau.jsonl"), {r["image"]: r for r in load("mc_more.jsonl")}
tau_names = [k for k in T[0]["mc"][0] if isinstance(T[0]["mc"][0][k], dict)]
p1_names = [k for k in M[0]["mc"][0] if isinstance(M[0]["mc"][0][k], dict)]
tmap = {t["image"]: t for t in T}
with open(os.path.join(dst, "mc_measurement.jsonl"), "w") as fm, open(os.path.join(dst, "mc_tau.jsonl"), "w") as ft:
    for m in M:
        x = X[m["image"]]; t = tmap[m["image"]]
        for rec in x["mc"]:
            m["mc"].append({k: v for k, v in rec.items() if k in ("trial", "condition") or k in p1_names})
            t["mc"].append({k: v for k, v in rec.items() if k in ("trial", "condition") or k in tau_names})
        fm.write(json.dumps(m) + "\n"); ft.write(json.dumps(t) + "\n")
for f in os.listdir(src):
    if f not in ("mc_measurement.jsonl", "mc_tau.jsonl") and not os.path.exists(os.path.join(dst, f)):
        os.symlink(os.path.join(os.path.abspath(src), f), os.path.join(dst, f))
print("merged", len(M), "images;", len(M[0]["mc"]), "records per image")
