import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from phdesc.descriptor import compute_pw_descriptor, DescriptorConfig, extract_patch
from synthetic_validation import make_synthetic_scene

scene = make_synthetic_scene(size=160, n_shapes=30, seed=2)
y, x = 80, 80
gammas = [0.3, 0.5, 0.7, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0]

cfg_plain = DescriptorConfig(scales=(16, 24, 32), resolution=8, rank_normalize=False)
cfg_rank = DescriptorConfig(scales=(16, 24, 32), resolution=8, rank_normalize=True)

base_plain = compute_pw_descriptor(scene, y, x, cfg_plain)
base_rank = compute_pw_descriptor(scene, y, x, cfg_rank)

dist_plain, dist_rank = [], []
for g in gammas:
    distorted = np.clip(scene, 1e-9, 1.0) ** g
    d_plain = compute_pw_descriptor(distorted, y, x, cfg_plain)
    d_rank = compute_pw_descriptor(distorted, y, x, cfg_rank)
    dist_plain.append(float(np.linalg.norm(d_plain - base_plain)))
    dist_rank.append(float(np.linalg.norm(d_rank - base_rank)))

# Proper managed layout: a 2-row grid. Row 1 = three small patch thumbnails
# (their own real subplots, not floating absolute-coordinate axes -- this
# is the fix: matplotlib's own GridSpec sizing guarantees no overlap with
# row 2, unlike fig.add_axes([...]) with hand-picked figure-fraction
# coordinates, which tight_layout() does not know about and which
# collided with the row-2 plots in the previous version of this figure).
fig = plt.figure(figsize=(11, 6.4))
gs = fig.add_gridspec(2, 3, height_ratios=[1, 2.6], hspace=0.5, wspace=0.4)

patches_to_show = [0.3, 1.0, 3.0]
for i, g in enumerate(patches_to_show):
    ax_inset = fig.add_subplot(gs[0, i])
    distorted = np.clip(scene, 1e-9, 1.0) ** g
    patch = extract_patch(distorted, y, x, 32)
    ax_inset.imshow(patch, cmap="gray", vmin=0, vmax=1)
    ax_inset.set_title(f"Patch at $\\gamma$={g}", fontsize=9)
    ax_inset.set_xticks([]); ax_inset.set_yticks([])

ax = fig.add_subplot(gs[1, 0:2])
ax.plot(gammas, dist_plain, "o-", color="#2c6fbb", label="PW-Desc (plain)")
ax.plot(gammas, dist_rank, "o-", color="#8e44ad", label="PW-Desc-rank")
ax.axvline(1.0, color="gray", linestyle=":", linewidth=1)
ax.set_xlabel("Gamma distortion applied ($\\gamma$)")
ax.set_ylabel("Descriptor distance from $\\gamma{=}1$ baseline")
ax.set_title("(a) Descriptor drift under monotonic intensity transform, single keypoint", fontsize=9.5)
ax.legend(fontsize=8)
ax.grid(alpha=0.3)

ax = fig.add_subplot(gs[1, 2])
ax.plot(gammas, dist_plain, "o-", color="#2c6fbb", label="Plain: diverges")
ax.plot(gammas, dist_rank, "o-", color="#8e44ad", label="Rank: flat (Prop. 4)")
ax.set_yscale("log")
ax.set_xlabel("$\\gamma$")
ax.set_ylabel("Distance (log)")
ax.set_title("(b) Log scale: rank-\nnormalized drift is\nexactly zero", fontsize=9)
ax.legend(fontsize=7.5, loc="center left")
ax.grid(alpha=0.3, which="both")

fig.suptitle("Monotonic intensity invariance: plain PW-Desc diverges under gamma distortion,\n"
             "PW-Desc-rank provably does not (Proposition 4)", fontsize=11)
out = "/home/claude/phdesc_project/paper/figure12.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
print("dist_plain:", dist_plain)
print("dist_rank:", dist_rank)
