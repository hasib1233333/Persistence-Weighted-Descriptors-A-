"""
oxford_affine_real_evaluation.py
===================================

THE real benchmark evaluation, on the actual, real, uploaded Oxford-Affine
dataset (8 scenes, 40 image pairs, genuine homography ground truth from
the original 2004/2005 release) -- not synthetic, not a substitute.

Computes the full metric suite used throughout this paper's protocol:
MMA@1/3/5/10, repeatability, precision, recall, F1, RANSAC inlier ratio,
homography corner-reprojection error, and runtime per keypoint.

Primary protocol: shared Harris detector across PW-Desc, PW-Desc-rank,
RawPatch, GradHist, SIFT, ORB (consistent with Sec. 8's synthetic/real-
image protocols elsewhere in this repository).

PW-Desc/PW-Desc-rank use the GUDHI backend (bit-for-bit verified identical
to the default from-scratch backend, code/tests/test_gudhi_cross_
validation.py) purely for practicality on this larger real run -- stated
explicitly, not hidden.

Run: python code/scripts/oxford_affine_real_evaluation.py
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np

from phdesc import (harris_keypoints, nn_ratio_match, mean_matching_accuracy,
                     repeatability as repeatability_fn, geometric_verify_homography,
                     homography_estimation_auc)
from phdesc.descriptor import DescriptorConfig, compute_pw_descriptors_batch
from phdesc import baselines
from phdesc.datasets import OxfordAffineLoader
from phdesc.profiling import cv2_sift_describe, cv2_orb_describe
import cv2


def pw_batch(image, keypoints, rank=False):
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8, rank_normalize=rank, backend="gudhi")
    return compute_pw_descriptors_batch(image, keypoints, cfg)


def raw_batch(image, keypoints):
    return baselines.batch_descriptor(baselines.raw_patch_descriptor, image, keypoints, size=16)


def gradhist_batch(image, keypoints):
    return baselines.batch_descriptor(baselines.gradient_histogram_descriptor, image, keypoints, size=16)


METHODS = {
    "PW-Desc": (lambda im, kp: pw_batch(im, kp, rank=False), False),
    "PW-Desc-rank": (lambda im, kp: pw_batch(im, kp, rank=True), False),
    "RawPatch": (raw_batch, False),
    "GradHist": (gradhist_batch, False),
    "SIFT": (cv2_sift_describe, False),
    "ORB": (cv2_orb_describe, True),
}


def match(da, db, binary):
    if len(da) == 0 or len(db) == 0:
        return np.zeros((0, 2), dtype=np.int64)
    if binary:
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        matches = bf.match(da, db)
        return np.array([[m.queryIdx, m.trainIdx] for m in matches], dtype=np.int64).reshape(-1, 2)
    m = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
    return m


def corner_error(H_est, H_gt, image_shape):
    """Max corner displacement between H_est and H_gt applied to the 4
    image corners of image A -- the standard SuperGlue/LoFTR-style
    homography error metric."""
    H_img, W_img = image_shape
    corners = np.array([[0, 0], [W_img - 1, 0], [W_img - 1, H_img - 1], [0, H_img - 1]], dtype=np.float64)
    ones = np.ones((4, 1))
    corners_h = np.concatenate([corners, ones], axis=1)
    if H_est is None:
        return float("inf")
    proj_est = corners_h @ H_est.T
    proj_est = proj_est[:, :2] / (proj_est[:, 2:3] + 1e-12)
    proj_gt = corners_h @ H_gt.T
    proj_gt = proj_gt[:, :2] / (proj_gt[:, 2:3] + 1e-12)
    return float(np.max(np.linalg.norm(proj_est - proj_gt, axis=1)))


def evaluate_pair(sample, max_kp=40):
    """Run all methods on one real Oxford-Affine pair, real Harris
    keypoints shared across all methods (primary protocol)."""
    img_a, img_b, H_gt = sample.image_a, sample.image_b, sample.H_gt
    kp_a = harris_keypoints(img_a, max_keypoints=max_kp, min_distance=8)
    kp_b = harris_keypoints(img_b, max_keypoints=max_kp, min_distance=8)

    rep = repeatability_fn(kp_a, kp_b, H_gt, img_a.shape, pixel_thresh=3.0)

    out = {}
    if len(kp_a) < 6 or len(kp_b) < 6:
        for name in METHODS:
            out[name] = dict(mma={1: 0.0, 3: 0.0, 5: 0.0, 10: 0.0}, precision=0.0,
                              recall=0.0, f1=0.0, inlier_ratio=0.0, corner_err=float("inf"),
                              n_matches=0, ms_per_kp=0.0)
        return out, rep, len(kp_a), len(kp_b)

    for name, (fn, binary) in METHODS.items():
        t0 = time.perf_counter()
        da = fn(img_a, kp_a)
        db = fn(img_b, kp_b)
        dt = time.perf_counter() - t0
        n_kp = len(kp_a) + len(kp_b)
        ms_per_kp = 1000 * dt / max(n_kp, 1)

        matches = match(da, db, binary)
        n_matches = len(matches)
        if n_matches == 0:
            out[name] = dict(mma={1: 0.0, 3: 0.0, 5: 0.0, 10: 0.0}, precision=0.0,
                              recall=0.0, f1=0.0, inlier_ratio=0.0, corner_err=float("inf"),
                              n_matches=0, ms_per_kp=ms_per_kp)
            continue

        pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
        pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
        mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(1, 3, 5, 10))

        # precision: fraction of putative matches correct at 3px
        ones = np.ones((len(pts_a), 1))
        warped = np.concatenate([pts_a, ones], axis=1) @ H_gt.T
        warped = warped[:, :2] / (warped[:, 2:3] + 1e-12)
        err = np.linalg.norm(warped - pts_b, axis=1)
        tp = int(np.sum(err <= 3.0))
        precision = tp / len(pts_a)

        # recall: fraction of the repeatable keypoint set recovered
        kp_a_xy = kp_a[:, ::-1].astype(np.float64)
        ones_all = np.ones((len(kp_a), 1))
        warped_all = np.concatenate([kp_a_xy, ones_all], axis=1) @ H_gt.T
        warped_all = warped_all[:, :2] / (warped_all[:, 2:3] + 1e-12)
        kp_b_xy = kp_b[:, ::-1].astype(np.float64)
        d_all = np.linalg.norm(warped_all[:, None, :] - kp_b_xy[None, :, :], axis=2)
        n_repeatable = int(np.sum(np.any(d_all <= 3.0, axis=1)))
        recall = tp / n_repeatable if n_repeatable > 0 else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        H_est, inliers = geometric_verify_homography(pts_a, pts_b)
        inlier_ratio = float(np.mean(inliers)) if inliers is not None and len(inliers) else 0.0
        cerr = corner_error(H_est, H_gt, img_a.shape)

        out[name] = dict(mma=mma, precision=precision, recall=recall, f1=f1,
                          inlier_ratio=inlier_ratio, corner_err=cerr,
                          n_matches=n_matches, ms_per_kp=ms_per_kp)

    return out, rep, len(kp_a), len(kp_b)


def main():
    loader = OxfordAffineLoader("/home/claude/phdesc_project/data/oxford_affine")
    pairs = list(loader.iter_pairs())
    print(f"Loaded {len(pairs)} real Oxford-Affine pairs across scenes: "
          f"{sorted(set(p.pair_id.split('_')[0] for p in pairs))}")

    per_method_scores = {name: {"mma1": [], "mma3": [], "mma5": [], "mma10": [],
                                 "precision": [], "recall": [], "f1": [],
                                 "inlier_ratio": [], "corner_err": [], "n_matches": [],
                                 "ms_per_kp": []}
                          for name in METHODS}
    repeatabilities = []
    per_scene_results = {}

    for i, sample in enumerate(pairs):
        scene = sample.pair_id.split("_")[0]
        out, rep, nka, nkb = evaluate_pair(sample, max_kp=40)
        repeatabilities.append(rep)
        per_scene_results.setdefault(scene, []).append((sample.pair_id, out, rep))
        for name, res in out.items():
            per_method_scores[name]["mma1"].append(res["mma"][1])
            per_method_scores[name]["mma3"].append(res["mma"][3])
            per_method_scores[name]["mma5"].append(res["mma"][5])
            per_method_scores[name]["mma10"].append(res["mma"][10])
            per_method_scores[name]["precision"].append(res["precision"])
            per_method_scores[name]["recall"].append(res["recall"])
            per_method_scores[name]["f1"].append(res["f1"])
            per_method_scores[name]["inlier_ratio"].append(res["inlier_ratio"])
            per_method_scores[name]["corner_err"].append(res["corner_err"])
            per_method_scores[name]["n_matches"].append(res["n_matches"])
            per_method_scores[name]["ms_per_kp"].append(res["ms_per_kp"])
        print(f"  [{i+1}/{len(pairs)}] {sample.pair_id}: kp_a={nka} kp_b={nkb} rep={rep:.3f} "
              f"PW-Desc MMA@3={out['PW-Desc']['mma'][3]:.3f}")

    summary = {}
    for name, scores in per_method_scores.items():
        finite_corner_err = [e for e in scores["corner_err"] if np.isfinite(e)]
        summary[name] = dict(
            mma1=float(np.mean(scores["mma1"])), mma1_std=float(np.std(scores["mma1"])),
            mma3=float(np.mean(scores["mma3"])), mma3_std=float(np.std(scores["mma3"])),
            mma5=float(np.mean(scores["mma5"])), mma5_std=float(np.std(scores["mma5"])),
            mma10=float(np.mean(scores["mma10"])), mma10_std=float(np.std(scores["mma10"])),
            precision=float(np.mean(scores["precision"])),
            recall=float(np.mean(scores["recall"])),
            f1=float(np.mean(scores["f1"])),
            inlier_ratio=float(np.mean(scores["inlier_ratio"])),
            mean_corner_err=float(np.mean(finite_corner_err)) if finite_corner_err else None,
            median_corner_err=float(np.median(finite_corner_err)) if finite_corner_err else None,
            n_finite_corner_err=len(finite_corner_err),
            homography_auc=homography_estimation_auc(finite_corner_err, thresholds=(3, 5, 10)) if finite_corner_err else None,
            mean_n_matches=float(np.mean(scores["n_matches"])),
            mean_ms_per_kp=float(np.mean(scores["ms_per_kp"])),
            n_pairs=len(scores["mma3"]),
        )

    summary["_repeatability"] = dict(mean=float(np.mean(repeatabilities)),
                                      std=float(np.std(repeatabilities)),
                                      n=len(repeatabilities))

    # per-scene breakdown for PW-Desc and PW-Desc-rank (for the paper's table)
    per_scene_summary = {}
    for scene, results in per_scene_results.items():
        pw_mma3 = [out["PW-Desc"]["mma"][3] for _, out, _ in results]
        pwrank_mma3 = [out["PW-Desc-rank"]["mma"][3] for _, out, _ in results]
        sift_mma3 = [out["SIFT"]["mma"][3] for _, out, _ in results]
        reps = [r for _, _, r in results]
        per_scene_summary[scene] = dict(
            pw_desc_mma3=float(np.mean(pw_mma3)),
            pw_desc_rank_mma3=float(np.mean(pwrank_mma3)),
            sift_mma3=float(np.mean(sift_mma3)),
            repeatability=float(np.mean(reps)),
            n_pairs=len(results),
        )

    print("\n=== SUMMARY ===")
    print(json.dumps(summary, indent=2))
    print("\n=== PER-SCENE ===")
    print(json.dumps(per_scene_summary, indent=2))

    out_path = os.path.join(os.path.dirname(__file__), "oxford_affine_real_evaluation_results.json")
    with open(out_path, "w") as f:
        json.dump({"summary": summary, "per_scene": per_scene_summary}, f, indent=2)
    print(f"\nSaved -> {out_path}")


if __name__ == "__main__":
    main()
