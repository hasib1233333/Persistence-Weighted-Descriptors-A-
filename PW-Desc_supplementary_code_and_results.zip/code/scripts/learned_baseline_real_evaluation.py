"""
learned_baseline_real_evaluation.py
======================================

REAL SuperPoint and DISK evaluation on the real, uploaded Oxford-Affine
benchmark. Both are joint detector+descriptor networks, so -- consistent
with how this repository already handles BRISK/AKAZE/KAZE
(Sec. 8.10) -- they use their own native detection rather than the
shared-Harris protocol used for PW-Desc/SIFT/ORB elsewhere.

LoFTR is NOT included: its official checkpoint is hosted at
cmp.felk.cvut.cz, confirmed unreachable from this sandbox (403,
host_not_allowed) -- verified directly, not assumed.

Run: python code/scripts/learned_baseline_real_evaluation.py
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np

from phdesc import nn_ratio_match, mean_matching_accuracy, geometric_verify_homography
from phdesc.datasets import OxfordAffineLoader
from phdesc.learned_baselines import SuperPointWrapper, DISKWrapper
from oxford_affine_real_evaluation import corner_error

RESULTS_PATH = os.path.join(os.path.dirname(__file__), "learned_baseline_real_results.json")


def evaluate_pair(sample, models, max_kp=40):
    img_a, img_b, H_gt = sample.image_a, sample.image_b, sample.H_gt
    out = {}
    for name, model in models.items():
        t0 = time.perf_counter()
        kp_a, da = model.detect_and_describe(img_a)
        kp_b, db = model.detect_and_describe(img_b)
        dt = time.perf_counter() - t0
        n_kp = len(kp_a) + len(kp_b)
        ms_per_kp = 1000 * dt / max(n_kp, 1)

        if len(kp_a) == 0 or len(kp_b) == 0:
            out[name] = dict(mma={"1": 0.0, "3": 0.0, "5": 0.0, "10": 0.0},
                              n_matches=0, inlier_ratio=0.0, corner_err=None,
                              ms_per_kp=ms_per_kp, n_kp_a=len(kp_a), n_kp_b=len(kp_b))
            continue

        matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
        if len(matches) == 0:
            out[name] = dict(mma={"1": 0.0, "3": 0.0, "5": 0.0, "10": 0.0},
                              n_matches=0, inlier_ratio=0.0, corner_err=None,
                              ms_per_kp=ms_per_kp, n_kp_a=len(kp_a), n_kp_b=len(kp_b))
            continue

        pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
        pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
        mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(1, 3, 5, 10))
        H_est, inliers = geometric_verify_homography(pts_a, pts_b)
        inlier_ratio = float(np.mean(inliers)) if inliers is not None and len(inliers) else 0.0
        cerr = corner_error(H_est, H_gt, img_a.shape)
        cerr = cerr if np.isfinite(cerr) else None

        out[name] = dict(mma={str(k): v for k, v in mma.items()}, n_matches=len(matches),
                          inlier_ratio=inlier_ratio, corner_err=cerr, ms_per_kp=ms_per_kp,
                          n_kp_a=len(kp_a), n_kp_b=len(kp_b))
    return out


def main():
    loader = OxfordAffineLoader("/home/claude/phdesc_project/data/oxford_affine")
    pairs = list(loader.iter_pairs())
    print(f"Loaded {len(pairs)} real Oxford-Affine pairs")

    print("Loading SuperPoint...")
    sp = SuperPointWrapper()
    print("Loading DISK...")
    disk = DISKWrapper(n_keypoints=500)
    models = {"SuperPoint": sp, "DISK": disk}

    if os.path.exists(RESULTS_PATH):
        with open(RESULTS_PATH) as f:
            saved = json.load(f)
        results = saved.get("per_pair", saved if "summary" not in saved else {})
        print(f"Resuming: {len(results)} pairs already done")
    else:
        results = {}

    for i, sample in enumerate(pairs):
        if sample.pair_id in results:
            continue
        out = evaluate_pair(sample, models, max_kp=40)
        results[sample.pair_id] = out
        print(f"  [{i+1}/{len(pairs)}] {sample.pair_id}: "
              f"SuperPoint MMA@3={out['SuperPoint']['mma']['3']:.3f} "
              f"DISK MMA@3={out['DISK']['mma']['3']:.3f}")
        with open(RESULTS_PATH, "w") as f:
            json.dump({"per_pair": results}, f)

    summary = {}
    for name in models:
        mma1 = [r[name]['mma']['1'] for r in results.values()]
        mma3 = [r[name]['mma']['3'] for r in results.values()]
        mma5 = [r[name]['mma']['5'] for r in results.values()]
        mma10 = [r[name]['mma']['10'] for r in results.values()]
        inl = [r[name]['inlier_ratio'] for r in results.values()]
        cerr = [r[name]['corner_err'] for r in results.values() if r[name]['corner_err'] is not None]
        mstime = [r[name]['ms_per_kp'] for r in results.values()]
        nmatch = [r[name]['n_matches'] for r in results.values()]
        summary[name] = dict(mma1=float(np.mean(mma1)), mma3=float(np.mean(mma3)),
                              mma5=float(np.mean(mma5)), mma10=float(np.mean(mma10)),
                              mma3_std=float(np.std(mma3)),
                              inlier_ratio=float(np.mean(inl)),
                              median_corner_err=float(np.median(cerr)) if cerr else None,
                              mean_ms_per_kp=float(np.mean(mstime)),
                              mean_n_matches=float(np.mean(nmatch)), n_pairs=len(mma3))
    print("\n=== SUMMARY ===")
    print(json.dumps(summary, indent=2))
    with open(RESULTS_PATH, "w") as f:
        json.dump({"per_pair": results, "summary": summary}, f, indent=2)
    print(f"Saved -> {RESULTS_PATH}")


if __name__ == "__main__":
    main()
