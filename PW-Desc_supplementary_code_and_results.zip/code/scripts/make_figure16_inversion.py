import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from phdesc.descriptor import compute_pw_descriptor, DescriptorConfig, extract_patch
from phdesc.baselines import raw_patch_descriptor
from phdesc.profiling import cv2_sift_describe
from synthetic_validation import make_synthetic_scene

scene = make_synthetic_scene(size=140, n_shapes=25, seed=6)
y, x = 70, 70
patch = extract_patch(scene, y, x, 32)
inverted_scene = 1.0 - scene

cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8)
cfg_rank = DescriptorConfig(scales=(16, 24, 32), resolution=8, rank_normalize=True)

d_plain = compute_pw_descriptor(scene, y, x, cfg)
d_plain_inv = compute_pw_descriptor(inverted_scene, y, x, cfg)
d_rank = compute_pw_descriptor(scene, y, x, cfg_rank)
d_rank_inv = compute_pw_descriptor(inverted_scene, y, x, cfg_rank)

raw = raw_patch_descriptor(scene, y, x, size=16)
raw_inv = raw_patch_descriptor(inverted_scene, y, x, size=16)

sift = cv2_sift_describe(scene, np.array([[y, x]]))
sift_inv = cv2_sift_describe(inverted_scene, np.array([[y, x]]))

names = ["PW-Desc", "PW-Desc-rank", "RawPatch", "SIFT"]
dists = [
    np.linalg.norm(d_plain - d_plain_inv),
    np.linalg.norm(d_rank - d_rank_inv),
    np.linalg.norm(raw - raw_inv),
    np.linalg.norm(sift[0] - sift_inv[0]) if len(sift) and len(sift_inv) else np.nan,
]
max_possible = [2.0, 2.0, 2.0, np.linalg.norm(sift[0]) * 2 if len(sift) else np.nan]

fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.2), gridspec_kw={"width_ratios": [1, 1, 1.3]})

axes[0].imshow(patch, cmap="gray")
axes[0].set_title("Original patch", fontsize=10)
axes[0].axis("off")

axes[1].imshow(1.0 - patch, cmap="gray")
axes[1].set_title("Inverted ($1 - P$)\n(simulates polarity-flipped\ncross-modal imaging)", fontsize=10)
axes[1].axis("off")

ax = axes[2]
colors = ["#2c6fbb", "#8e44ad", "#e07b39", "#c0392b"]
bars = ax.bar(names, dists, color=colors)
for b, d, mx in zip(bars, dists, max_possible):
    frac = d / mx if mx and not np.isnan(mx) else float("nan")
    ax.text(b.get_x() + b.get_width() / 2, d + 0.02, f"{d:.3f}", ha="center", fontsize=8.5)
ax.set_ylabel("Descriptor distance, patch vs.\\ its inversion")
ax.set_title("Descriptor drift under pure intensity\ninversion (real measured)", fontsize=10)
ax.grid(axis="y", alpha=0.3)

fig.suptitle("Cross-modal (inversion) robustness: an honest negative result. "
             "Rank normalization is proved (Prop.\\ 4) invariant to monotonic \\emph{increasing}\n"
             "transforms only; inversion is monotonic \\emph{decreasing}, and empirically NONE of "
             "these four descriptors are invariant to it by default.", fontsize=10, y=1.08)
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure_inversion.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
print(dict(zip(names, dists)))
