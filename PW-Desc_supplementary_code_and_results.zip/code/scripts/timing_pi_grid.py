"""timing_pi_grid.py -- time of the persistence computation and of the persistence-image
vectorization (r = 8 and r = 16) per keypoint, 100 Harris keypoints of graf/img1, one core.
Usage: python timing_pi_grid.py /path/to/oxford out.json"""
import sys, os, time, json
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
from phdesc import harris_keypoints
from phdesc.descriptor import extract_patch, persistence_image
from phdesc.persistence import compute_persistence_diagrams
from mc_measurement import load_resized
im = load_resized(os.path.join(sys.argv[1], "graf", "img1.png")); kp = harris_keypoints(im, max_keypoints=100, min_distance=8)
P = [extract_patch(im, y, x, s) for (y, x) in kp for s in (16, 24, 32)]
t = time.perf_counter(); D = [compute_persistence_diagrams(p, backend="gudhi") for p in P]; out = {"ph_ms": 1000 * (time.perf_counter() - t) / len(kp)}
for r in (8, 16):
    t = time.perf_counter(); [persistence_image(d, (0, 1), (0, 1), r) for dd in D for d in dd]
    out[f"pi{r}_ms"] = 1000 * (time.perf_counter() - t) / len(kp)
print(out); json.dump(out, open(sys.argv[2], "w"), indent=1)
