import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

sdir = "/home/claude/phdesc_project/code/scripts"
with open(os.path.join(sdir, "stress_curve_sweeps_results.json")) as f:
    stress = json.load(f)
with open(os.path.join(sdir, "photometric_robustness_results.json")) as f:
    photo = json.load(f)
with open(os.path.join(sdir, "synthetic_validation_results.json")) as f:
    sval = json.load(f)

methods = ["PW-Desc", "PW-Desc-rank", "RawPatch", "GradHist"]
colors = {"PW-Desc": "#2c6fbb", "PW-Desc-rank": "#8e44ad", "RawPatch": "#e07b39",
          "GradHist": "#3fa34d", "SIFT (real)": "#c0392b", "SIFT": "#c0392b"}

fig, axes = plt.subplots(2, 2, figsize=(11, 8.5))

# (a) noise
ax = axes[0, 0]
sigmas = sorted(float(k.split("=")[1]) for k in stress["noise"].keys())
for m in methods + ["SIFT (real)"]:
    vals = [stress["noise"][f"sigma={s}"][m] for s in sigmas]
    ax.plot(sigmas, vals, "o-", label=m, color=colors[m])
ax.set_xlabel("Gaussian noise $\\sigma$"); ax.set_ylabel("MMA@3px")
ax.set_title("(a) Additive noise sweep\n(n=2 scenes, 35 keypoints -- small-scale, high-variance)", fontsize=9.5)
ax.set_ylim(-0.05, 1.05); ax.grid(alpha=0.3)

# (b) gamma (reuse existing real data)
ax = axes[0, 1]
gammas = sorted(float(k.split("=")[1]) for k in photo.keys())
for m in ["PW-Desc", "PW-Desc-rank", "RawPatch", "GradHist"]:
    vals = [photo[f"gamma={g}"][m]["mean_mma3"] for g in gammas]
    ax.plot(gammas, vals, "o-", label=m, color=colors[m])
ax.axvline(1.0, color="gray", linestyle=":", linewidth=1)
ax.set_xlabel("Gamma distortion (1.0=none)"); ax.set_ylabel("MMA@3px")
ax.set_title("(b) Photometric (gamma) sweep\n(n=4 scenes -- same data as Table 12)", fontsize=9.5)
ax.set_ylim(-0.05, 1.05); ax.grid(alpha=0.3)

# (c) rotation
ax = axes[1, 0]
angles = sorted(int(k.split("=")[1]) for k in stress["rotation"].keys())
for m in methods + ["SIFT (real)"]:
    vals = [stress["rotation"][f"theta={a}"][m] for a in angles]
    ax.plot(angles, vals, "o-", label=m, color=colors[m])
ax.set_xlabel("Rotation angle (degrees)"); ax.set_ylabel("MMA@3px")
ax.set_title("(c) Affine rotation sweep\n(n=2 scenes, 35 keypoints -- small-scale, high-variance)", fontsize=9.5)
ax.set_ylim(-0.05, 1.05); ax.grid(alpha=0.3)

# (d) elastic (homography-only vs homography+elastic, real data from Table 11)
ax = axes[1, 1]
regimes = ["homography_only", "homography_plus_elastic"]
x = np.arange(len(regimes))
width = 0.2
for i, m in enumerate(methods):
    vals = [sval[r][m]["mean_mma3"] for r in regimes]
    ax.bar(x + (i - 1.5) * width, vals, width, color=colors[m], label=m)
ax.set_xticks(x); ax.set_xticklabels(["Homography\nonly", "Homography +\nelastic (non-rigid)"])
ax.set_ylabel("MMA@3px")
ax.set_title("(d) Non-rigid deformation\n(n=4 scenes -- same data as Table 11)", fontsize=9.5)
ax.set_ylim(0, 1.05); ax.grid(axis="y", alpha=0.3)

handles, labels = axes[0, 0].get_legend_handles_labels()
fig.legend(handles, labels, loc="lower center", ncol=5, fontsize=8.5, bbox_to_anchor=(0.5, -0.02))
fig.suptitle("Fine-grained synthetic stress curves across four perturbation axes", fontsize=12, y=1.01)
plt.tight_layout(rect=[0, 0.04, 1, 1])
out = "/home/claude/phdesc_project/paper/figure_stress_curves.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
