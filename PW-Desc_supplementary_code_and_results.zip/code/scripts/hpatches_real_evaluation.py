"""
hpatches_real_evaluation.py
==============================

THE real HPatches evaluation, on the actual, complete, uploaded HPatches
dataset (116 sequences, 580 real image pairs, genuine homography ground
truth) -- streamed (never materializing the full dataset in memory,
unlike the smaller Oxford-Affine run) and checkpointed (saves progress
after every sequence, so this can be safely interrupted and resumed
without losing completed work, given the much larger scale here).

Run: python code/scripts/hpatches_real_evaluation.py
Resumes automatically from hpatches_real_evaluation_results.json if present.
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np

from phdesc import (harris_keypoints, nn_ratio_match, mean_matching_accuracy,
                     repeatability as repeatability_fn, geometric_verify_homography,
                     homography_estimation_auc)
from phdesc.datasets import HPatchesLoader
from oxford_affine_real_evaluation import METHODS, match, corner_error

RESULTS_PATH = os.path.join(os.path.dirname(__file__), "hpatches_real_evaluation_results.json")
DATA_ROOT = "/home/claude/phdesc_project/data/hpatches_sequences"
MAX_KP = 30  # reduced from Oxford-Affine's 40 given the much larger pair count


def evaluate_one_pair(img_a, img_b, H_gt, pair_id):
    kp_a = harris_keypoints(img_a, max_keypoints=MAX_KP, min_distance=8)
    kp_b = harris_keypoints(img_b, max_keypoints=MAX_KP, min_distance=8)
    rep = repeatability_fn(kp_a, kp_b, H_gt, img_a.shape, pixel_thresh=3.0)

    out = {}
    if len(kp_a) < 6 or len(kp_b) < 6:
        for name in METHODS:
            out[name] = dict(mma={"1": 0.0, "3": 0.0, "5": 0.0, "10": 0.0}, precision=0.0,
                              recall=0.0, f1=0.0, inlier_ratio=0.0, corner_err=None,
                              n_matches=0, ms_per_kp=0.0)
        return out, rep

    for name, (fn, binary) in METHODS.items():
        t0 = time.perf_counter()
        da = fn(img_a, kp_a)
        db = fn(img_b, kp_b)
        dt = time.perf_counter() - t0
        n_kp = len(kp_a) + len(kp_b)
        ms_per_kp = 1000 * dt / max(n_kp, 1)

        matches = match(da, db, binary)
        n_matches = len(matches)
        if n_matches == 0:
            out[name] = dict(mma={"1": 0.0, "3": 0.0, "5": 0.0, "10": 0.0}, precision=0.0,
                              recall=0.0, f1=0.0, inlier_ratio=0.0, corner_err=None,
                              n_matches=0, ms_per_kp=ms_per_kp)
            continue

        pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
        pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
        mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(1, 3, 5, 10))

        ones = np.ones((len(pts_a), 1))
        warped = np.concatenate([pts_a, ones], axis=1) @ H_gt.T
        warped = warped[:, :2] / (warped[:, 2:3] + 1e-12)
        err = np.linalg.norm(warped - pts_b, axis=1)
        tp = int(np.sum(err <= 3.0))
        precision = tp / len(pts_a)

        kp_a_xy = kp_a[:, ::-1].astype(np.float64)
        ones_all = np.ones((len(kp_a), 1))
        warped_all = np.concatenate([kp_a_xy, ones_all], axis=1) @ H_gt.T
        warped_all = warped_all[:, :2] / (warped_all[:, 2:3] + 1e-12)
        kp_b_xy = kp_b[:, ::-1].astype(np.float64)
        d_all = np.linalg.norm(warped_all[:, None, :] - kp_b_xy[None, :, :], axis=2)
        n_repeatable = int(np.sum(np.any(d_all <= 3.0, axis=1)))
        recall = tp / n_repeatable if n_repeatable > 0 else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

        H_est, inliers = geometric_verify_homography(pts_a, pts_b)
        inlier_ratio = float(np.mean(inliers)) if inliers is not None and len(inliers) else 0.0
        cerr = corner_error(H_est, H_gt, img_a.shape)
        cerr = cerr if np.isfinite(cerr) else None

        out[name] = dict(mma={str(k): v for k, v in mma.items()}, precision=precision,
                          recall=recall, f1=f1, inlier_ratio=inlier_ratio, corner_err=cerr,
                          n_matches=n_matches, ms_per_kp=ms_per_kp)
    return out, rep


def main():
    loader = HPatchesLoader(DATA_ROOT)
    sequences = loader.list_sequences()
    print(f"Found {len(sequences)} real HPatches sequences")

    if os.path.exists(RESULTS_PATH):
        with open(RESULTS_PATH) as f:
            results = json.load(f)
        print(f"Resuming: {len(results['per_pair'])} pairs already done")
    else:
        results = {"per_pair": {}, "done_sequences": []}

    from skimage.io import imread
    from skimage.color import rgb2gray

    t_start = time.time()
    for si, seq in enumerate(sequences):
        if seq in results["done_sequences"]:
            continue
        seq_dir = os.path.join(DATA_ROOT, seq)
        ref_raw = imread(os.path.join(seq_dir, "1.ppm"))
        ref = rgb2gray(ref_raw).astype(np.float64) if ref_raw.ndim == 3 else ref_raw.astype(np.float64) / 255.0

        for k in range(2, 7):
            img_path = os.path.join(seq_dir, f"{k}.ppm")
            h_path = os.path.join(seq_dir, f"H_1_{k}")
            if not (os.path.exists(img_path) and os.path.exists(h_path)):
                continue
            other_raw = imread(img_path)
            other = rgb2gray(other_raw).astype(np.float64) if other_raw.ndim == 3 else other_raw.astype(np.float64) / 255.0
            H_gt = np.loadtxt(h_path)
            pair_id = f"{seq}_1_{k}"

            out, rep = evaluate_one_pair(ref, other, H_gt, pair_id)
            results["per_pair"][pair_id] = {"methods": out, "repeatability": rep, "scene_type": seq[0]}
            del other, other_raw

        results["done_sequences"].append(seq)
        del ref, ref_raw

        elapsed = time.time() - t_start
        print(f"  [{si+1}/{len(sequences)}] {seq} done ({elapsed:.0f}s elapsed, "
              f"{len(results['per_pair'])} pairs total)")

        # checkpoint after every sequence
        with open(RESULTS_PATH, "w") as f:
            json.dump(results, f)

    print(f"\nALL DONE: {len(results['per_pair'])} pairs, {len(results['done_sequences'])} sequences")


if __name__ == "__main__":
    main()
