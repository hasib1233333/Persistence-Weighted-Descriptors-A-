import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from phdesc import harris_keypoints, nn_ratio_match, geometric_verify_homography
from synthetic_validation import make_synthetic_scene, random_homography, warp_image, elastic_deform, pw_batch

base = make_synthetic_scene(size=160, n_shapes=30, seed=2)
H_gt = random_homography(160, max_shift=14, seed=102)
warped = warp_image(base, H_gt)
warped = elastic_deform(warped, alpha=3.0, sigma=10.0, seed=202)
warped = np.clip(warped, 0, 1)

kp_a = harris_keypoints(base, max_keypoints=70, min_distance=8)
kp_b = harris_keypoints(warped, max_keypoints=70, min_distance=8)

da = pw_batch(base, kp_a)
db = pw_batch(warped, kp_b)
matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)

pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
H_est, inliers = geometric_verify_homography(pts_a, pts_b)

fig, ax = plt.subplots(figsize=(11, 5.2))
canvas = np.concatenate([base, np.ones((base.shape[0], 6)), warped], axis=1)
ax.imshow(canvas, cmap="gray")
offset = base.shape[1] + 6

for i, (a_idx, b_idx) in enumerate(matches):
    y1, x1 = kp_a[a_idx]
    y2, x2 = kp_b[b_idx]
    is_inlier = bool(inliers[i]) if inliers is not None and i < len(inliers) else False
    color = "#2ecc71" if is_inlier else "#e74c3c"
    ax.plot([x1, x2 + offset], [y1, y2], color=color, linewidth=0.7, alpha=0.75)
    ax.plot(x1, y1, "o", color=color, markersize=3)
    ax.plot(x2 + offset, y2, "o", color=color, markersize=3)

ax.set_title(
    f"PW-Desc matches under homography + non-rigid (elastic) deformation\n"
    f"{len(matches)} putative matches, {int(np.sum(inliers)) if inliers is not None else 0} "
    f"RANSAC inliers (green) / {int(np.sum(~inliers)) if inliers is not None else 0} outliers (red)",
    fontsize=10)
ax.axis("off")
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure13.pdf"
plt.savefig(out, bbox_inches="tight", dpi=150)
print("saved", out, " n_matches=", len(matches), " n_inliers=", int(np.sum(inliers)) if inliers is not None else 0)
