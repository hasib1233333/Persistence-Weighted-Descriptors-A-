"""
ablation_mc.py
==============

Real-image ablation with known ground truth. Each of the 16 reference
photographs of mc_measurement.py (img1, img4 of the eight Oxford-Affine
scenes, 640 px, 8-bit) forms one sequence with five targets obtained by known
random homographies (same generator as mc_measurement.py, different seeds).
Variants and metrics follow real_ablation.py (exact slices of the full
descriptor for H0/H1/single-scale; recomputation for 4x4, 16x16 and tau =
0.05). The learned projection is trained on the sequences of four scenes
(bark, bikes, boat, graf) and evaluated on the other four (leuven, trees,
ubc, wall), so that it is always tested on scenes it never saw.

Usage: python ablation_mc.py /path/to/oxford_dir out_dir [workers]
"""
import sys, os, time, json, zlib
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

import numpy as np
import cv2

from phdesc import harris_keypoints
from benchmark_shared_detector import warp
from mc_measurement import load_resized, random_homography, quantize
from real_ablation import (RECOMPUTE, NOISE, slice_variant, pw, pair_metrics, noise_metrics,
                           train_projection, project)

K = 300
TRAIN_SCENES = {"bark", "bikes", "boat", "graf"}


def describe(args):
    path, idx = args
    cv2.setNumThreads(1)
    I = load_resized(path)
    rng = np.random.default_rng(zlib.crc32(path.encode()))
    imgs = {1: (I, np.eye(3))}
    for k in range(2, 7):
        H = random_homography(np.random.default_rng(50_000 + 100 * idx + k), I.shape)
        J = quantize(cv2.warpPerspective(I, H, (I.shape[1], I.shape[0]), flags=cv2.INTER_LINEAR,
                                         borderMode=cv2.BORDER_CONSTANT, borderValue=0))
        imgs[k] = (J, H)
    out = {"path": path, "scene": path.split(os.sep)[-2], "images": {}}
    for k, (img, H) in imgs.items():
        kp = harris_keypoints(img, max_keypoints=K, min_distance=8)
        rec = {"kp": kp, "H": H, "shape": img.shape, "full": pw(img, kp)}
        for v, kw in RECOMPUTE.items():
            rec[v] = pw(img, kp, **kw)
        if k == 1:
            noisy = np.clip(img + rng.uniform(-NOISE, NOISE, img.shape), 0, 1)
            rec["noisy_full"] = pw(noisy, kp)
            for v, kw in RECOMPUTE.items():
                rec["noisy_" + v] = pw(noisy, kp, **kw)
        out["images"][k] = rec
    return out


def train_pairs(seqs, rng, max_pos=150):
    Xa, Xb, y = [], [], []
    for sd in seqs:
        A = sd["images"][1]
        for k in range(2, 7):
            B = sd["images"][k]
            wa = warp(A["kp"][:, ::-1].astype(float), B["H"])
            dd = np.linalg.norm(wa[:, None] - B["kp"][:, ::-1][None].astype(float), axis=2)
            j = dd.argmin(1)
            ok = rng.permutation(np.where(dd[np.arange(len(j)), j] <= 2.0)[0])[:max_pos]
            for i in ok:
                Xa.append(A["full"][i]); Xb.append(B["full"][j[i]]); y.append(1)
                jn = rng.integers(len(B["kp"]))
                while jn == j[i]:
                    jn = rng.integers(len(B["kp"]))
                Xa.append(A["full"][i]); Xb.append(B["full"][jn]); y.append(0)
    return np.array(Xa), np.array(Xb), np.array(y)


def main():
    root, out_dir = sys.argv[1], sys.argv[2]
    workers = int(sys.argv[3]) if len(sys.argv) > 3 else 2
    paths = []
    for s in sorted(os.listdir(root)):
        for k in (1, 4):
            p = next((os.path.join(root, s, f"img{k}.{e}") for e in ("png", "ppm", "pgm")
                      if os.path.exists(os.path.join(root, s, f"img{k}.{e}"))), None)
            if p:
                paths.append(p)
    from multiprocessing import Pool
    t0 = time.time()
    seqs = []
    with Pool(workers) as pool:
        for i, r in enumerate(pool.imap_unordered(describe, [(p, i) for i, p in enumerate(paths)])):
            seqs.append(r); print(f"[{i + 1}/{len(paths)}] {r['path']} {time.time() - t0:.0f}s", flush=True)
    seqs.sort(key=lambda r: r["path"])
    train = [s for s in seqs if s["scene"] in TRAIN_SCENES]
    test = [s for s in seqs if s["scene"] not in TRAIN_SCENES]
    Xa, Xb, y = train_pairs(train, np.random.default_rng(0))
    Wc, hc = train_projection(Xa, Xb, y, constrained=True)
    Wu, hu = train_projection(Xa, Xb, y, constrained=False)

    def get(rec, v, noisy=False):
        pre = "noisy_" if noisy else ""
        if v == "full" or v in RECOMPUTE:
            return rec[pre + v]
        if v.startswith("proj"):
            return project(Wc if v == "proj_constrained" else Wu, rec[pre + "full"])[0]
        return slice_variant(rec[pre + "full"], v)

    def evaluate(seq_list, variants):
        res = {v: [] for v in variants}
        for sd in seq_list:
            A = sd["images"][1]
            for v in variants:
                da = get(A, v)
                prs = [pair_metrics(A["kp"], da, sd["images"][k]["kp"], get(sd["images"][k], v),
                                    sd["images"][k]["H"], A["shape"]) for k in range(2, 7)]
                nm = noise_metrics(da, get(A, v, noisy=True))
                res[v].append(dict(seq=sd["path"], mma3=float(np.mean([p["mma3"] for p in prs])),
                                   ms=float(np.mean([p["ms"] for p in prs])),
                                   ha3=float(np.mean([p["mce"] is not None and p["mce"] <= 3 for p in prs])),
                                   ha5=float(np.mean([p["mce"] is not None and p["mce"] <= 5 for p in prs])), **nm))
        return res

    base_variants = ["full", "H0", "H1", "s16", "s24", "s32"] + list(RECOMPUTE)
    all_res = evaluate(seqs, base_variants)
    proj_res = evaluate(test, ["full", "proj_constrained", "proj_unconstrained"])
    eta_W = np.concatenate([project(Wc, s["images"][1]["full"])[1] for s in test])
    out = dict(K=K, n_sequences=len(seqs), test_scenes=sorted({s["scene"] for s in test}),
               projection=dict(n_train_pairs=int(len(y)), n_pos=int(y.sum()),
                               constrained=dict(spectral_norm=float(np.linalg.norm(Wc, 2)), loss=hc),
                               unconstrained=dict(spectral_norm=float(np.linalg.norm(Wu, 2)), loss=hu)),
               eta_W=dict(min=float(eta_W.min()), p1=float(np.percentile(eta_W, 1)), median=float(np.median(eta_W))),
               per_sequence=all_res, projection_eval=proj_res)
    json.dump(out, open(os.path.join(out_dir, "ablation_mc.json"), "w"), indent=1)
    for v, r in list(all_res.items()) + [("(test) " + k, v) for k, v in proj_res.items()]:
        print(f"{v:28s} MMA3={np.mean([x['mma3'] for x in r]):.3f} HA3={np.mean([x['ha3'] for x in r]):.3f} "
              f"SR={np.mean([x['self_retrieval'] for x in r]):.3f} nu={np.median([x['nu_median'] for x in r]):.3f}")
    print("done", time.time() - t0)


if __name__ == "__main__":
    main()
