"""
real_image_projection_ablation.py
====================================

Directly answers a reviewer question: does the spectral-norm constraint
(Proposition 2) cost discriminative power on REAL images, not just the
synthetic scenes the original ablation (Table 14) used?

Trains a spectrally-constrained and an unconstrained linear projection on
real-image-derived training pairs, evaluates both on real images (the
same suite as Table 13), real measured results.

Run: python code/scripts/real_image_projection_ablation.py
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np

from phdesc import harris_keypoints, nn_ratio_match, mean_matching_accuracy
from phdesc.descriptor import DescriptorConfig, compute_pw_descriptors_batch
from phdesc.metric_learning import ContrastiveLinearProjection, ContrastiveProjectionConfig
from real_image_validation import load_real_image, REAL_IMAGES
from synthetic_validation import random_homography, warp_image


class UnconstrainedProjection(ContrastiveLinearProjection):
    """Identical training loop to ContrastiveLinearProjection but WITHOUT
    the per-step spectral normalization -- the ablation."""
    def fit(self, X_a, X_b, labels):
        rng = np.random.default_rng(self.cfg.seed)
        N, d = X_a.shape
        out_dim = min(self.cfg.out_dim, d)
        W = rng.normal(scale=1.0 / np.sqrt(d), size=(out_dim, d))
        m_pos, m_neg = self.cfg.margin, 2 * self.cfg.margin
        for epoch in range(self.cfg.epochs):
            Za, Zb = (W @ X_a.T).T, (W @ X_b.T).T
            na = np.linalg.norm(Za, axis=1, keepdims=True) + 1e-9
            nb = np.linalg.norm(Zb, axis=1, keepdims=True) + 1e-9
            Za_n, Zb_n = Za / na, Zb / nb
            diff = Za_n - Zb_n
            dist = np.linalg.norm(diff, axis=1)
            grad_W = np.zeros_like(W)
            for i in range(N):
                if labels[i] == 1 and dist[i] > m_pos:
                    coeff = 2 * (dist[i] - m_pos)
                    d_ = diff[i] / (dist[i] + 1e-9)
                    grad_W += np.outer(coeff * d_, X_a[i]) - np.outer(coeff * d_, X_b[i])
                elif labels[i] == 0 and dist[i] < m_neg:
                    coeff = -2 * (m_neg - dist[i])
                    d_ = diff[i] / (dist[i] + 1e-9)
                    grad_W += np.outer(coeff * d_, X_a[i]) - np.outer(coeff * d_, X_b[i])
            grad_W /= max(N, 1)
            grad_W += self.cfg.weight_decay * W
            W = W - self.cfg.lr * grad_W
            # NO spectral normalization -- this is the ablation
        self.W = W
        return self


def build_training_pairs(cfg_base, n_images=4):
    """Build positive/negative descriptor pairs from REAL images (not
    synthetic scenes), for training the projection."""
    X_a, X_b, labels = [], [], []
    rng = np.random.default_rng(0)
    for idx in range(n_images):
        name = REAL_IMAGES[idx]
        base = load_real_image(name)
        H_gt = random_homography(base.shape[0], max_shift=int(0.08 * base.shape[0]), seed=1000 + idx)
        warped = np.clip(warp_image(base, H_gt), 0, 1)
        kp_a = harris_keypoints(base, max_keypoints=20, min_distance=8)
        if len(kp_a) == 0:
            continue
        da = compute_pw_descriptors_batch(base, kp_a, cfg_base)
        ones = np.ones((len(kp_a), 1))
        kp_a_xy = kp_a[:, ::-1].astype(np.float64)
        warped_xy = np.concatenate([kp_a_xy, ones], axis=1) @ H_gt.T
        warped_xy = warped_xy[:, :2] / (warped_xy[:, 2:3] + 1e-12)
        kp_b = harris_keypoints(warped, max_keypoints=20, min_distance=8)
        if len(kp_b) == 0:
            continue
        db = compute_pw_descriptors_batch(warped, kp_b, cfg_base)
        kp_b_xy = kp_b[:, ::-1].astype(np.float64)
        for j in range(len(kp_a)):
            d = np.linalg.norm(warped_xy[j] - kp_b_xy, axis=1)
            nearest = np.argmin(d)
            if d[nearest] < 3.0:
                X_a.append(da[j]); X_b.append(db[nearest]); labels.append(1)
            neg_idx = rng.integers(0, len(kp_b))
            X_a.append(da[j]); X_b.append(db[neg_idx]); labels.append(0)
    return np.array(X_a), np.array(X_b), np.array(labels)


def eval_with_projection(proj, cfg_base, n_images, seed_offset):
    scores = []
    for idx in range(n_images):
        name = REAL_IMAGES[idx]
        base = load_real_image(name)
        H_gt = random_homography(base.shape[0], max_shift=int(0.08 * base.shape[0]), seed=800 + seed_offset + idx)
        warped = np.clip(warp_image(base, H_gt), 0, 1)
        kp_a = harris_keypoints(base, max_keypoints=30, min_distance=8)
        kp_b = harris_keypoints(warped, max_keypoints=30, min_distance=8)
        if len(kp_a) < 6 or len(kp_b) < 6:
            continue
        da = compute_pw_descriptors_batch(base, kp_a, cfg_base)
        db = compute_pw_descriptors_batch(warped, kp_b, cfg_base)
        da_p, db_p = proj.transform(da), proj.transform(db)
        matches = nn_ratio_match(da_p, db_p, ratio_thresh=0.85, mutual=True)
        if len(matches) == 0:
            scores.append(0.0)
            continue
        pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
        pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
        mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
        scores.append(mma[3])
    return dict(mean_mma3=float(np.mean(scores)) if scores else 0.0,
                std_mma3=float(np.std(scores)) if scores else 0.0, n=len(scores))


def main():
    cfg_base = DescriptorConfig(scales=(16, 24, 32), resolution=8)
    print("Building training pairs from real images...")
    X_a, X_b, labels = build_training_pairs(cfg_base, n_images=4)
    print(f"  {len(labels)} pairs ({int(labels.sum())} positive)")

    out = {}

    # No projection baseline (raw descriptor)
    print("Evaluating: no projection (raw)...")
    no_proj_scores = []
    for idx in range(len(REAL_IMAGES)):
        name = REAL_IMAGES[idx]
        base = load_real_image(name)
        H_gt = random_homography(base.shape[0], max_shift=int(0.08 * base.shape[0]), seed=800 + idx)
        warped = np.clip(warp_image(base, H_gt), 0, 1)
        kp_a = harris_keypoints(base, max_keypoints=30, min_distance=8)
        kp_b = harris_keypoints(warped, max_keypoints=30, min_distance=8)
        if len(kp_a) < 6 or len(kp_b) < 6:
            continue
        da = compute_pw_descriptors_batch(base, kp_a, cfg_base)
        db = compute_pw_descriptors_batch(warped, kp_b, cfg_base)
        matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
        if len(matches) == 0:
            no_proj_scores.append(0.0)
            continue
        pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
        pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
        mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
        no_proj_scores.append(mma[3])
    out["No projection (raw)"] = dict(mean_mma3=float(np.mean(no_proj_scores)),
                                        std_mma3=float(np.std(no_proj_scores)),
                                        n=len(no_proj_scores))
    print(f"  {out['No projection (raw)']}")

    print("Training spectrally-constrained projection...")
    proj_cfg = ContrastiveProjectionConfig(out_dim=128, epochs=80, seed=0)
    proj_constrained = ContrastiveLinearProjection(proj_cfg).fit(X_a, X_b, labels)
    out["Spectrally-constrained"] = eval_with_projection(proj_constrained, cfg_base, len(REAL_IMAGES), 0)
    print(f"  {out['Spectrally-constrained']}")

    print("Training unconstrained projection...")
    proj_unconstrained = UnconstrainedProjection(proj_cfg).fit(X_a, X_b, labels)
    spectral_norm = float(np.linalg.norm(proj_unconstrained.W, ord=2))
    out["Unconstrained"] = eval_with_projection(proj_unconstrained, cfg_base, len(REAL_IMAGES), 0)
    out["Unconstrained"]["measured_spectral_norm"] = spectral_norm
    print(f"  {out['Unconstrained']} (||W||_2={spectral_norm:.3f})")

    out_path = os.path.join(os.path.dirname(__file__), "real_image_projection_ablation_results.json")
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved -> {out_path}")


if __name__ == "__main__":
    main()
