import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from phdesc.persistence import compute_persistence_diagrams
from phdesc.descriptor import persistence_image, extract_patch, compute_pw_descriptor, DescriptorConfig
from synthetic_validation import make_synthetic_scene

scene = make_synthetic_scene(size=160, n_shapes=30, seed=1)
patch_clean = extract_patch(scene, 70, 90, 32)
rng = np.random.default_rng(5)
patch_noisy = np.clip(patch_clean + rng.normal(0, 0.05, size=patch_clean.shape), 0, 1)

pd0_c, pd1_c = compute_persistence_diagrams(patch_clean)
pd0_n, pd1_n = compute_persistence_diagrams(patch_noisy)

cfg = DescriptorConfig(scales=(32,), resolution=8)
canvas_c = np.zeros((64, 64)); canvas_c[:32, :32] = patch_clean
canvas_n = np.zeros((64, 64)); canvas_n[:32, :32] = patch_noisy
v1 = compute_pw_descriptor(canvas_c, 32, 32, cfg)
v2 = compute_pw_descriptor(canvas_n, 32, 32, cfg)
l2_dist = float(np.linalg.norm(v1 - v2))
sup_norm_perturbation = float(np.max(np.abs(patch_clean - patch_noisy)))

fig, axes = plt.subplots(3, 3, figsize=(11, 9.5))

for col, (patch, pd1, title) in enumerate([
        (patch_clean, pd1_c, "Column A: Clean patch"),
        (patch_noisy, pd1_n, "Column B: Perturbed ($\\sigma$=0.05 noise)")]):
    ax = axes[0, col]
    im = ax.imshow(patch, cmap="viridis", vmin=0, vmax=1)
    ax.set_title(title, fontsize=9.5); ax.set_xticks([]); ax.set_yticks([])
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    ax = axes[1, col]
    f1 = pd1.finite()
    if len(f1):
        life = f1[:, 1] - f1[:, 0]
        sizes = 20 + 300 * (life / (life.max() + 1e-9))
        colors = np.where(life > 0.05, "#2c6fbb", "#e07b39")  # high- vs low-persistence
        ax.scatter(f1[:, 0], f1[:, 1], s=sizes, c=colors, edgecolor="k", linewidth=0.3, alpha=0.8)
    lims = [-0.05, 1.05]
    ax.plot(lims, lims, "k--", linewidth=0.8)
    ax.set_xlim(lims); ax.set_ylim(lims)
    ax.set_xlabel("birth"); ax.set_ylabel("death")
    ax.set_title("$H_1$ diagram (blue=high-persistence,\norange=low-persistence noise)", fontsize=8.5)

    ax = axes[2, col]
    v = v1 if col == 0 else v2
    im2 = ax.imshow(v.reshape(1, -1), aspect="auto", cmap="coolwarm")
    ax.set_yticks([]); ax.set_xlabel("descriptor dim")
    ax.set_title(f"Descriptor $v_{col+1}$", fontsize=9)

# Column C: difference
ax = axes[0, 2]
diff_img = np.abs(patch_clean - patch_noisy)
im = ax.imshow(diff_img, cmap="hot", vmin=0, vmax=sup_norm_perturbation)
ax.set_title(f"Column C: |patch A - patch B|\n(sup-norm = {sup_norm_perturbation:.3f})", fontsize=9.5)
ax.set_xticks([]); ax.set_yticks([])
plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

ax = axes[1, 2]
f1c, f1n = pd1_c.finite(), pd1_n.finite()
if len(f1c):
    life_c = f1c[:, 1] - f1c[:, 0]
    ax.scatter(f1c[:, 0], f1c[:, 1], s=20 + 300 * (life_c / (life_c.max() + 1e-9)),
               c="#2c6fbb", alpha=0.5, label="clean $D_1$", edgecolor="k", linewidth=0.2)
if len(f1n):
    life_n = f1n[:, 1] - f1n[:, 0]
    ax.scatter(f1n[:, 0], f1n[:, 1], s=20 + 300 * (life_n / (life_n.max() + 1e-9)),
               c="#e07b39", alpha=0.5, marker="^", label="noisy $D_1$", edgecolor="k", linewidth=0.2)
lims = [-0.05, 1.05]
ax.plot(lims, lims, "k--", linewidth=0.8)
ax.set_xlim(lims); ax.set_ylim(lims)
ax.legend(fontsize=7)
ax.set_title("Overlay: high-persistence points barely\nmove; low-persistence ones are noise", fontsize=8.5)
ax.set_xlabel("birth"); ax.set_ylabel("death")

ax = axes[2, 2]
diff_v = np.abs(v1 - v2)
im3 = ax.imshow(diff_v.reshape(1, -1), aspect="auto", cmap="hot")
ax.set_yticks([]); ax.set_xlabel("descriptor dim")
ax.set_title(f"|$v_1 - v_2$| ($\\ell_2$={l2_dist:.4f})\ncf. sup-norm perturbation={sup_norm_perturbation:.3f}", fontsize=8.5)

fig.suptitle("Topological stability visual proof: descriptor distance stays proportionate\n"
              "to the sup-norm patch perturbation (real computed example, Proposition 1)",
              fontsize=11.5, y=1.01)
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure_stability_proof.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
print(f"l2_descriptor_distance={l2_dist:.5f}  sup_norm_perturbation={sup_norm_perturbation:.5f}")
