"""
bound_tightness.py
==================

Compares the cardinality bound of Proposition 2 with the thresholded bound of
Proposition 3 (ramp weight vanishing on [0, tau], 2 delta < tau) on the 16
reference images of mc_measurement.py.

For each image, 100 Harris keypoints, noise bounds eps in {0.005, 0.01, 0.02}
and tau in {0, 0.05, 0.1}, it records for the unnormalized descriptor x~:
  drift          ||x~(P) - x~(P')||_2
  bound_card     r K_tau (sum_{s,k} (N + N')^2)^{1/2} delta        (Prop. 2)
  bound_thr      r K_tau (sum_{s,k} N_{tau-2delta}(D)^2)^{1/2} delta (Prop. 3)
with delta measured per scale, and whether each bound holds.

Usage: python bound_tightness.py /path/to/oxford out.json
"""
import sys, os, json
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
import numpy as np

from phdesc import harris_keypoints
from phdesc.descriptor import extract_patch, persistence_image
from phdesc.persistence import compute_persistence_diagrams
from mc_measurement import load_resized

SCALES = (16, 24, 32)
R = 8
SIGMA = 1.0 / R
EPS = [0.005, 0.01, 0.02]
TAUS = [0.0, 0.05, 0.1]


def K(tau):
    return 2.0 / (1.0 - tau) + np.sqrt(5) / (SIGMA * np.sqrt(np.e))


def fin(pd):
    p = pd.finite()
    return p[(p[:, 1] - p[:, 0]) > 0] if len(p) else np.zeros((0, 2))


def blocks(patches, tau):
    out = []
    for P in patches:
        for pd in compute_persistence_diagrams(P, backend="gudhi"):
            out.append((fin(pd), persistence_image(pd, (0, 1), (0, 1), R, tau=tau).reshape(-1)))
    return out


def main():
    root, out = sys.argv[1], sys.argv[2]
    paths = [os.path.join(root, s, f"img{k}.png") for s in sorted(os.listdir(root)) for k in (1, 4)]
    res = {f"{t}_{e}": dict(drift=[], card=[], thr=[], card_ok=0, thr_ok=0, n=0) for t in TAUS for e in EPS}
    for idx, p in enumerate(paths):
        img = load_resized(p)
        kp = harris_keypoints(img, max_keypoints=100, min_distance=8)
        rng = np.random.default_rng(7000 + idx)
        clean = [[extract_patch(img, y, x, s) for s in SCALES] for (y, x) in kp]
        for e in EPS:
            noisy_img = np.clip(img + rng.uniform(-e, e, img.shape), 0, 1)
            for i, (y, x) in enumerate(kp):
                Pn = [extract_patch(noisy_img, y, x, s) for s in SCALES]
                deltas = [float(np.max(np.abs(a - b))) for a, b in zip(clean[i], Pn)]
                for t in TAUS:
                    bc, bn = blocks(clean[i], t), blocks(Pn, t)
                    drift = float(np.linalg.norm(np.concatenate([b[1] for b in bc]) - np.concatenate([b[1] for b in bn])))
                    c2 = t2 = 0.0
                    for j, ((D, _), (Dn, _)) in enumerate(zip(bc, bn)):
                        d = deltas[j // 2]
                        c2 += (R * K(t) * (len(D) + len(Dn)) * d) ** 2
                        n_thr = int(np.sum((D[:, 1] - D[:, 0]) > t - 2 * d)) if t > 0 else len(D) + len(Dn)
                        t2 += (R * K(t) * n_thr * d) ** 2
                    r = res[f"{t}_{e}"]
                    r["drift"].append(drift); r["card"].append(np.sqrt(c2)); r["thr"].append(np.sqrt(t2))
                    r["card_ok"] += int(drift <= np.sqrt(c2) + 1e-9); r["thr_ok"] += int(drift <= np.sqrt(t2) + 1e-9)
                    r["n"] += 1
        print(p, flush=True)
    summ = {}
    for k, r in res.items():
        d, c, t = map(np.array, (r["drift"], r["card"], r["thr"]))
        summ[k] = dict(n=r["n"], card_ok=r["card_ok"], thr_ok=r["thr_ok"],
                       drift_median=float(np.median(d)), card_median=float(np.median(c)), thr_median=float(np.median(t)),
                       tight_card=float(np.median(d / np.maximum(c, 1e-12))), tight_thr=float(np.median(d / np.maximum(t, 1e-12))),
                       ratio_card_thr=float(np.median(c / np.maximum(t, 1e-12))))
    json.dump(summ, open(out, "w"), indent=1)
    for k, v in summ.items():
        print(k, v)


if __name__ == "__main__":
    main()
