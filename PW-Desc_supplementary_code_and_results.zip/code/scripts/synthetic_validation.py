"""
synthetic_validation.py
========================

Runs the COMPLETE PW-Desc pipeline (keypoint detection -> multi-scale
persistence descriptor -> matching -> RANSAC verification -> metrics)
end-to-end on procedurally generated synthetic images under controlled,
KNOWN ground-truth homographies and non-rigid deformations.

Purpose and honesty note
-------------------------
This script is a CORRECTNESS / SANITY-CHECK study, NOT a substitute for
the four public benchmarks (HPatches, MegaDepth, ScanNet, Oxford-Affine)
required by the manuscript's experimental protocol. It exists to (a)
verify the full pipeline actually runs and produces sane, non-degenerate
numbers, and (b) give a first, fully-reproducible, zero-download empirical
look at the deformation-robustness behaviour the method is designed for.
All numbers below are produced by ACTUALLY RUNNING the code in this
repository, not invented.

Run: python code/scripts/synthetic_validation.py
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
from scipy import ndimage as ndi

from phdesc import (compute_pw_descriptors_batch, DescriptorConfig,
                     harris_keypoints, nn_ratio_match, geometric_verify_homography,
                     mean_matching_accuracy, repeatability,
                     paired_bootstrap_ci, wilcoxon_signed_rank)
from phdesc import baselines


# --------------------------------------------------------------------------
# Synthetic scene generation
# --------------------------------------------------------------------------
def make_synthetic_scene(size=256, n_shapes=40, seed=0) -> np.ndarray:
    """Procedurally generated grayscale image with rich multi-scale texture
    (blobs, rings, gradients) -- gives Harris corners and non-trivial local
    topology so the persistence descriptor has something to describe."""
    rng = np.random.default_rng(seed)
    img = np.zeros((size, size), dtype=np.float64)
    yy, xx = np.mgrid[0:size, 0:size]
    for _ in range(n_shapes):
        cy, cx = rng.uniform(0, size, size=2)
        r = rng.uniform(6, 22)
        val = rng.uniform(0.3, 1.0)
        kind = rng.integers(0, 3)
        d = np.sqrt((yy - cy) ** 2 + (xx - cx) ** 2)
        if kind == 0:
            img += val * np.exp(-(d ** 2) / (2 * (r / 2) ** 2))          # Gaussian blob
        elif kind == 1:
            ring = np.exp(-((d - r) ** 2) / (2 * (r / 5) ** 2))
            img += val * ring                                            # ring
        else:
            img += val * (d < r)                                          # flat disk
    img += 0.05 * rng.normal(size=img.shape)
    img -= img.min()
    img /= (img.max() + 1e-9)
    return np.clip(img, 0, 1)


def random_homography(size, max_shift=18, seed=0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    src = np.array([[0, 0], [size, 0], [size, size], [0, size]], dtype=np.float64)
    dst = src + rng.uniform(-max_shift, max_shift, size=src.shape)
    from skimage.transform import ProjectiveTransform
    t = ProjectiveTransform()
    t.estimate(src, dst)
    return t.params


def warp_image(img, H):
    from skimage.transform import warp, ProjectiveTransform
    t = ProjectiveTransform(matrix=H)
    return warp(img, t.inverse, output_shape=img.shape, order=1, mode="edge")


def elastic_deform(img, alpha=8.0, sigma=12.0, seed=0):
    """Smooth random non-rigid displacement field (Simard et al.-style),
    used purely as a controlled robustness stressor -- not a benchmark."""
    rng = np.random.default_rng(seed)
    shape = img.shape
    dx = ndi.gaussian_filter((rng.random(shape) * 2 - 1), sigma) * alpha
    dy = ndi.gaussian_filter((rng.random(shape) * 2 - 1), sigma) * alpha
    yy, xx = np.mgrid[0:shape[0], 0:shape[1]]
    coords = np.array([yy + dy, xx + dx])
    return ndi.map_coordinates(img, coords, order=1, mode="reflect")


def warp_points(pts_xy, H):
    ones = np.ones((len(pts_xy), 1))
    h = np.concatenate([pts_xy, ones], axis=1) @ H.T
    return h[:, :2] / (h[:, 2:3] + 1e-12)


# --------------------------------------------------------------------------
# Descriptor evaluation harness
# --------------------------------------------------------------------------
def evaluate_descriptor(name, desc_fn_batch, img_a, img_b, kp_a, kp_b, H_gt,
                         ratio_thresh=0.85):
    t0 = time.time()
    da = desc_fn_batch(img_a, kp_a)
    db = desc_fn_batch(img_b, kp_b)
    t_desc = time.time() - t0

    matches = nn_ratio_match(da, db, ratio_thresh=ratio_thresh, mutual=True)
    if len(matches) == 0:
        return dict(name=name, n_matches=0, mma={1: 0, 3: 0, 5: 0}, inlier_ratio=0.0,
                    t_desc_per_kp_ms=1000 * t_desc / max(len(kp_a), 1))

    pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)  # (x, y)
    pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
    mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(1, 3, 5))

    H_est, inliers = geometric_verify_homography(pts_a, pts_b)
    inlier_ratio = float(np.mean(inliers)) if len(inliers) else 0.0

    return dict(name=name, n_matches=int(len(matches)), mma=mma,
                inlier_ratio=inlier_ratio,
                t_desc_per_kp_ms=1000 * t_desc / max(len(kp_a), 1))


def pw_batch(image, keypoints):
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8)
    return compute_pw_descriptors_batch(image, keypoints, cfg)


def pw_rank_batch(image, keypoints):
    cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8, rank_normalize=True)
    return compute_pw_descriptors_batch(image, keypoints, cfg)


def raw_batch(image, keypoints):
    return baselines.batch_descriptor(baselines.raw_patch_descriptor, image, keypoints, size=16)


def gradhist_batch(image, keypoints):
    return baselines.batch_descriptor(baselines.gradient_histogram_descriptor, image, keypoints, size=16)


def main():
    results = {"homography_only": [], "homography_plus_elastic": []}

    N_SCENES = 4
    for scene_id in range(N_SCENES):
        base = make_synthetic_scene(size=160, n_shapes=30, seed=scene_id)
        H_gt = random_homography(160, max_shift=12, seed=100 + scene_id)

        for regime in ["homography_only", "homography_plus_elastic"]:
            warped = warp_image(base, H_gt)
            if regime == "homography_plus_elastic":
                warped = elastic_deform(warped, alpha=3.0, sigma=10.0, seed=200 + scene_id)
            warped = np.clip(warped, 0, 1)

            kp_a = harris_keypoints(base, max_keypoints=70, min_distance=8)
            kp_b = harris_keypoints(warped, max_keypoints=70, min_distance=8)
            if len(kp_a) < 8 or len(kp_b) < 8:
                continue

            rep = repeatability(kp_a, kp_b, H_gt, base.shape, pixel_thresh=3.0)

            for name, fn in [("PW-Desc", pw_batch),
                              ("PW-Desc-rank", pw_rank_batch),
                              ("RawPatch", raw_batch),
                              ("GradHist", gradhist_batch)]:
                r = evaluate_descriptor(name, fn, base, warped, kp_a, kp_b, H_gt)
                r["scene_id"] = scene_id
                r["repeatability"] = rep
                results[regime].append(r)

        print(f"scene {scene_id+1}/{N_SCENES} done")

    # ---- aggregate + significance test (PW-Desc vs GradHist, MMA@3) -----
    summary = {}
    for regime, rows in results.items():
        summary[regime] = {}
        for name in ["PW-Desc", "PW-Desc-rank", "RawPatch", "GradHist"]:
            sub = [r for r in rows if r["name"] == name]
            mma3 = np.array([r["mma"][3] for r in sub])
            inlier = np.array([r["inlier_ratio"] for r in sub])
            nmatch = np.array([r["n_matches"] for r in sub])
            t_ms = np.array([r["t_desc_per_kp_ms"] for r in sub])
            summary[regime][name] = dict(
                mean_mma3=float(np.mean(mma3)), std_mma3=float(np.std(mma3)),
                mean_inlier_ratio=float(np.mean(inlier)),
                mean_n_matches=float(np.mean(nmatch)),
                mean_ms_per_kp=float(np.mean(t_ms)),
                n_scenes=len(sub),
            )

        pw = np.array([r["mma"][3] for r in rows if r["name"] == "PW-Desc"])
        gh = np.array([r["mma"][3] for r in rows if r["name"] == "GradHist"])
        if len(pw) == len(gh) and len(pw) > 1:
            mean_diff, lo, hi = paired_bootstrap_ci(pw, gh, n_boot=5000, seed=0)
            z, p = wilcoxon_signed_rank(pw, gh)
            summary[regime]["PW-Desc_vs_GradHist_MMA3"] = dict(
                mean_diff=mean_diff, ci95=[lo, hi], wilcoxon_z=z, wilcoxon_p=p)

    print(json.dumps(summary, indent=2))
    out_path = os.path.join(os.path.dirname(__file__), "synthetic_validation_results.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nSaved -> {out_path}")


if __name__ == "__main__":
    main()
