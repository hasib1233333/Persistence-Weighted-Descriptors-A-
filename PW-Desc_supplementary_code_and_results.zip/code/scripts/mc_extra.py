"""
mc_extra.py -- the Monte Carlo registration experiment of mc_measurement.py
(same images, homographies and seeds) under two further disturbances that are
outside the hypotheses of the stability bound: Gaussian blur (sigma = 1, 2
pixels) and JPEG compression (quality 50, 20). All descriptors of protocol P1
and the thresholded PW-Desc-rank variants are evaluated.
Usage: python mc_extra.py /path/to/oxford out_dir [trials] [workers]
"""
import sys, os, json, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
from multiprocessing import Pool
import mc_measurement as M
from benchmark_shared_detector import METHODS
from mc_tau import variant

M.METHODS = dict(METHODS)
M.METHODS["PW-Desc-rank-t0.05"] = variant(0.05)
M.METHODS["PW-Desc-rank-t0.1"] = variant(0.1)
M.RUN_PART_A = False
M.CONDITIONS = [("blur", 1.0), ("blur", 2.0), ("jpeg", 50), ("jpeg", 20)]

if __name__ == "__main__":
    root, out_dir = sys.argv[1], sys.argv[2]
    trials = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    workers = int(sys.argv[4]) if len(sys.argv) > 4 else 2
    imgs = [os.path.join(root, s, f"img{k}.png") for s in sorted(os.listdir(root)) for k in (1, 4)]
    imgs = [p for p in imgs if os.path.exists(p)]
    t0 = time.time()
    with Pool(workers) as pool, open(os.path.join(out_dir, "mc_extra.jsonl"), "w") as f:
        for i, r in enumerate(pool.imap_unordered(M.run_image, [(p, imgs.index(p), trials) for p in imgs])):
            f.write(json.dumps(r) + "\n"); f.flush()
            print(f"[{i + 1}/{len(imgs)}] {r['image']} {time.time() - t0:.0f}s", flush=True)
