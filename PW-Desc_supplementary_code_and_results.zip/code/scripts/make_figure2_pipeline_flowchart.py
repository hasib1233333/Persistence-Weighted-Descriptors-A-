import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(12.5, 2.6))
ax.set_xlim(0, 13)
ax.set_ylim(0, 2.6)
ax.axis("off")

steps = [
    ("Image", "#eef3fb"),
    ("Patch\nextraction", "#eef3fb"),
    ("Cubical\ncomplex", "#eef3fb"),
    ("Persistence\ndiagram", "#f5eefb"),
    ("Persistence\nimage", "#f5eefb"),
    ("Descriptor", "#eafbf0"),
]

n = len(steps)
box_w, box_h, gap = 1.7, 1.3, 0.55
total_w = n * box_w + (n - 1) * gap
x0 = (13 - total_w) / 2
y0 = 0.65

centers = []
for i, (label, color) in enumerate(steps):
    x = x0 + i * (box_w + gap)
    b = FancyBboxPatch((x, y0), box_w, box_h, boxstyle="round,pad=0.06,rounding_size=0.1",
                        linewidth=1.4, edgecolor="#2c3e6b", facecolor=color)
    ax.add_patch(b)
    ax.text(x + box_w / 2, y0 + box_h / 2, label, ha="center", va="center", fontsize=10)
    centers.append((x, x + box_w))

for i in range(n - 1):
    x_start = centers[i][1]
    x_end = centers[i + 1][0]
    a = FancyArrowPatch((x_start, y0 + box_h / 2), (x_end, y0 + box_h / 2),
                         arrowstyle="-|>", mutation_scale=15, linewidth=1.4, color="#2c3e6b")
    ax.add_patch(a)

ax.text(6.5, 2.35, "Persistent-homology pipeline (single scale $s$; repeated for each $s \\in \\mathcal{S}$)",
        ha="center", va="center", fontsize=11.5, fontweight="bold")

plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure2.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
