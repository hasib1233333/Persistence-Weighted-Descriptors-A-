"""
check_pi_constant.py -- numerical check of the per-pair inequality in the
proof of Lemma 2: |w(p_u)phi(g-u') - w(p_v)phi(g-v')| <= K ||u-v||_inf for
random points u, v of [0,1]^2 above the diagonal and every grid point g,
and w(p_u)phi(g-u') <= K p_u/2 for a point matched to the diagonal.
Usage: python check_pi_constant.py out.json
"""
import sys, json
import numpy as np
r = 8; sig = 1 / r
g = np.linspace(0, 1, r)  # the grid of phdesc.descriptor.persistence_image
G = np.stack(np.meshgrid(g, g, indexing="ij"), -1).reshape(-1, 2)
out = {}
rng = np.random.default_rng(1)
for tau in (0.0, 0.05, 0.1):
    Lw = 1 / (1 - tau); K = 2 * Lw + np.sqrt(5) / (sig * np.sqrt(np.e))
    w = lambda p: np.clip((p - tau) / (1 - tau), 0, 1)
    def term(b, d):
        p = d - b
        return w(p)[:, None] * np.exp(-((G[None, :, 0] - b[:, None]) ** 2 + (G[None, :, 1] - p[:, None]) ** 2) / (2 * sig ** 2))
    worst = 0.0; worst_diag = 0.0
    for _ in range(20):
        n = 50_000
        b = rng.uniform(0, 1, n); d = np.minimum(1, b + rng.uniform(0, 1, n))
        e = 10 ** rng.uniform(-4, -1, n)
        b2 = b + rng.uniform(-1, 1, n) * e; d2 = d + rng.uniform(-1, 1, n) * e
        keep = d2 > b2
        b, d, b2, d2 = b[keep], d[keep], b2[keep], d2[keep]
        eps = np.maximum(np.abs(b - b2), np.abs(d - d2))
        lhs = np.abs(term(b, d) - term(b2, d2)).max(1)
        worst = max(worst, float(np.max(lhs / (K * eps))))
        lhs_d = term(b, d).max(1)
        worst_diag = max(worst_diag, float(np.max(lhs_d / (K * (d - b) / 2))))
    out[str(tau)] = dict(K=float(K), max_ratio_pair=worst, max_ratio_diagonal=worst_diag)
    print(tau, out[str(tau)])
json.dump(out, open(sys.argv[1], "w"), indent=1)
