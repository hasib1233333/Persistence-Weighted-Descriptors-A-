"""
stress_curve_sweeps.py
========================

Fine-grained parameter sweeps (noise severity, rotation angle) to
complement the existing gamma sweep (photometric_robustness.py) and
geometric/elastic sweep (synthetic_validation.py), producing the data for
the 2x2 stress-curve figure. Real SIFT (OpenCV) is included as a strong,
real reference point alongside PW-Desc/PW-Desc-rank/RawPatch/GradHist.

Run: python code/scripts/stress_curve_sweeps.py
"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np

from phdesc import harris_keypoints, nn_ratio_match, mean_matching_accuracy
from phdesc.learned_baselines import sift_detect_and_describe
from synthetic_validation import make_synthetic_scene, pw_batch, pw_rank_batch, raw_batch, gradhist_batch, warp_image


def identity_H():
    return np.eye(3)


def rotation_H(size, theta_deg):
    theta = np.deg2rad(theta_deg)
    c, s = np.cos(theta), np.sin(theta)
    cx, cy = size / 2, size / 2
    T1 = np.array([[1, 0, -cx], [0, 1, -cy], [0, 0, 1]])
    R = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
    T2 = np.array([[1, 0, cx], [0, 1, cy], [0, 0, 1]])
    return T2 @ R @ T1


def eval_pw_family(base, warped, H_gt, n_scenes_kp_max=35):
    kp_a = harris_keypoints(base, max_keypoints=n_scenes_kp_max, min_distance=10)
    kp_b = harris_keypoints(warped, max_keypoints=n_scenes_kp_max, min_distance=10)
    out = {}
    if len(kp_a) < 8 or len(kp_b) < 8:
        for name in ["PW-Desc", "PW-Desc-rank", "RawPatch", "GradHist"]:
            out[name] = 0.0
        return out
    for name, fn in [("PW-Desc", pw_batch), ("PW-Desc-rank", pw_rank_batch),
                      ("RawPatch", raw_batch), ("GradHist", gradhist_batch)]:
        da = fn(base, kp_a); db = fn(warped, kp_b)
        matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
        if len(matches) == 0:
            out[name] = 0.0; continue
        pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
        pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
        mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
        out[name] = mma[3]
    return out


def eval_sift(base, warped, H_gt):
    kp_a, da = sift_detect_and_describe(base, max_keypoints=150)
    kp_b, db = sift_detect_and_describe(warped, max_keypoints=150)
    if len(kp_a) == 0 or len(kp_b) == 0:
        return 0.0
    matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
    if len(matches) == 0:
        return 0.0
    pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
    pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
    mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
    return mma[3]


def main():
    n_scenes = 2
    summary = {"noise": {}, "rotation": {}}

    sigmas = [0.0, 0.05, 0.1, 0.2]
    for sigma in sigmas:
        rows = {"PW-Desc": [], "PW-Desc-rank": [], "RawPatch": [], "GradHist": [], "SIFT (real)": []}
        for scene_id in range(n_scenes):
            base = make_synthetic_scene(size=160, n_shapes=30, seed=scene_id)
            rng = np.random.default_rng(300 + scene_id)
            noisy = np.clip(base + rng.normal(0, sigma, size=base.shape), 0, 1)
            H_gt = identity_H()
            pw_res = eval_pw_family(base, noisy, H_gt)
            for k, v in pw_res.items():
                rows[k].append(v)
            rows["SIFT (real)"].append(eval_sift(base, noisy, H_gt))
        summary["noise"][f"sigma={sigma}"] = {k: float(np.mean(v)) for k, v in rows.items()}
        print(f"noise sigma={sigma} done:", summary["noise"][f"sigma={sigma}"])

    angles = [0, 15, 30, 45]
    for theta in angles:
        rows = {"PW-Desc": [], "PW-Desc-rank": [], "RawPatch": [], "GradHist": [], "SIFT (real)": []}
        for scene_id in range(n_scenes):
            base = make_synthetic_scene(size=160, n_shapes=30, seed=scene_id)
            H_gt = rotation_H(160, theta)
            rotated = np.clip(warp_image(base, H_gt), 0, 1)
            pw_res = eval_pw_family(base, rotated, H_gt)
            for k, v in pw_res.items():
                rows[k].append(v)
            rows["SIFT (real)"].append(eval_sift(base, rotated, H_gt))
        summary["rotation"][f"theta={theta}"] = {k: float(np.mean(v)) for k, v in rows.items()}
        print(f"rotation theta={theta} done:", summary["rotation"][f"theta={theta}"])

    out_path = os.path.join(os.path.dirname(__file__), "stress_curve_sweeps_results.json")
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\nSaved -> {out_path}")


if __name__ == "__main__":
    main()
