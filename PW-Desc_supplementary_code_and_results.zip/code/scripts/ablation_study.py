"""
ablation_study.py
===================

Comprehensive ablation study, CPU-only, real measured results on the
synthetic sanity-check suite:

  1. H0-only vs H1-only vs H0+H1 (full)
  2. Single-scale (32px, 16px) vs multi-scale (16,24,32px)
  3. Persistence-image resolution: 4x4, 8x8, 16x16
  4. Learned projection: none vs spectrally-constrained (default) vs
     unconstrained (tests whether Proposition 2's theoretical requirement
     also matters empirically, not merely theoretically)

Rank normalization on/off is already reported elsewhere (PW-Desc vs
PW-Desc-rank throughout the paper) and is not repeated here.

Run: python code/scripts/ablation_study.py
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

import numpy as np

from phdesc import harris_keypoints, nn_ratio_match, mean_matching_accuracy
from phdesc.descriptor import DescriptorConfig, compute_pw_descriptors_batch
from phdesc.metric_learning import ContrastiveLinearProjection, ContrastiveProjectionConfig
from synthetic_validation import make_synthetic_scene, random_homography, warp_image


def eval_config(cfg, n_scenes, seed_offset=0):
    """Evaluate one DescriptorConfig across several synthetic scenes,
    homography-only regime, shared Harris keypoints, MMA@3."""
    scores, times = [], []
    for i in range(n_scenes):
        base = make_synthetic_scene(size=140, n_shapes=25, seed=i)
        H_gt = random_homography(140, max_shift=int(0.08 * 140), seed=800 + seed_offset + i)
        warped = np.clip(warp_image(base, H_gt), 0, 1)

        kp_a = harris_keypoints(base, max_keypoints=30, min_distance=8)
        kp_b = harris_keypoints(warped, max_keypoints=30, min_distance=8)
        if len(kp_a) < 6 or len(kp_b) < 6:
            continue

        t0 = time.perf_counter()
        da = compute_pw_descriptors_batch(base, kp_a, cfg)
        db = compute_pw_descriptors_batch(warped, kp_b, cfg)
        dt = time.perf_counter() - t0
        n_kp = len(kp_a) + len(kp_b)

        matches = nn_ratio_match(da, db, ratio_thresh=0.85, mutual=True)
        if len(matches) == 0:
            scores.append(0.0)
            times.append(1000 * dt / max(n_kp, 1))
            continue
        pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
        pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
        mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
        scores.append(mma[3])
        times.append(1000 * dt / max(n_kp, 1))

    return dict(mean_mma3=float(np.mean(scores)) if scores else 0.0,
                std_mma3=float(np.std(scores)) if scores else 0.0,
                mean_ms_per_kp=float(np.mean(times)) if times else 0.0,
                n=len(scores))


def run_h0_h1_ablation(n_scenes=4):
    print("=== Ablation 1: H0 vs H1 vs H0+H1 ===")
    out = {}
    for name, dims in [("H0 only", (0,)), ("H1 only", (1,)), ("H0+H1 (full)", (0, 1))]:
        cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8, use_dims=dims)
        out[name] = eval_config(cfg, n_scenes, seed_offset=0)
        print(f"  {name}: {out[name]}")
    return out


def run_scale_ablation(n_scenes=4):
    print("=== Ablation 2: single-scale vs multi-scale ===")
    out = {}
    for name, scales in [("Single-scale (32px)", (32,)),
                          ("Single-scale (16px)", (16,)),
                          ("Multi-scale (16,24,32px, full)", (16, 24, 32))]:
        cfg = DescriptorConfig(scales=scales, resolution=8)
        out[name] = eval_config(cfg, n_scenes, seed_offset=10)
        print(f"  {name}: {out[name]}")
    return out


def run_resolution_ablation(n_scenes=4):
    print("=== Ablation 3: persistence-image resolution ===")
    out = {}
    for res in [4, 8, 16]:
        cfg = DescriptorConfig(scales=(16, 24, 32), resolution=res)
        out[f"resolution={res}x{res}"] = eval_config(cfg, n_scenes, seed_offset=20)
        print(f"  resolution={res}: {out[f'resolution={res}x{res}']}")
    return out


def run_projection_ablation(n_scenes=4):
    """Trains a small contrastive projection with and without the
    spectral-norm constraint (Proposition 2), then evaluates downstream
    matching accuracy -- tests whether the constraint (required for the
    theoretical guarantee) also correlates with empirical robustness, not
    just theory."""
    print("=== Ablation 4: learned projection (none / spectral-constrained / unconstrained) ===")
    out = {}

    cfg_base = DescriptorConfig(scales=(16, 24, 32), resolution=8)
    X_a, X_b, labels = [], [], []
    rng = np.random.default_rng(0)
    for i in range(3):
        base = make_synthetic_scene(size=140, n_shapes=25, seed=100 + i)
        H_gt = random_homography(140, max_shift=12, seed=900 + i)
        warped = np.clip(warp_image(base, H_gt), 0, 1)
        kp_a = harris_keypoints(base, max_keypoints=20, min_distance=8)
        da = compute_pw_descriptors_batch(base, kp_a, cfg_base)
        ones = np.ones((len(kp_a), 1))
        kp_a_xy = kp_a[:, ::-1].astype(np.float64)
        warped_xy = np.concatenate([kp_a_xy, ones], axis=1) @ H_gt.T
        warped_xy = warped_xy[:, :2] / (warped_xy[:, 2:3] + 1e-12)
        kp_b = harris_keypoints(warped, max_keypoints=20, min_distance=8)
        if len(kp_b) == 0:
            continue
        db = compute_pw_descriptors_batch(warped, kp_b, cfg_base)
        kp_b_xy = kp_b[:, ::-1].astype(np.float64)
        for j in range(len(kp_a)):
            d = np.linalg.norm(warped_xy[j] - kp_b_xy, axis=1)
            nearest = np.argmin(d)
            if d[nearest] < 3.0:
                X_a.append(da[j]); X_b.append(db[nearest]); labels.append(1)
            neg_idx = rng.integers(0, len(kp_b))
            X_a.append(da[j]); X_b.append(db[neg_idx]); labels.append(0)

    X_a, X_b, labels = np.array(X_a), np.array(X_b), np.array(labels)
    print(f"  training pairs: {len(labels)} ({int(labels.sum())} positive)")

    scenes_eval = 4
    cfg_none = DescriptorConfig(scales=(16, 24, 32), resolution=8)
    out["No projection (raw)"] = eval_config(cfg_none, scenes_eval, seed_offset=30)
    print(f"  No projection: {out['No projection (raw)']}")

    proj_cfg = ContrastiveProjectionConfig(out_dim=128, epochs=80, seed=0)
    proj_constrained = ContrastiveLinearProjection(proj_cfg).fit(X_a, X_b, labels)

    def eval_with_projection(proj, n_scenes, seed_offset):
        scores = []
        for i in range(n_scenes):
            base = make_synthetic_scene(size=140, n_shapes=25, seed=i)
            H_gt = random_homography(140, max_shift=int(0.08 * 140), seed=800 + seed_offset + i)
            warped = np.clip(warp_image(base, H_gt), 0, 1)
            kp_a = harris_keypoints(base, max_keypoints=30, min_distance=8)
            kp_b = harris_keypoints(warped, max_keypoints=30, min_distance=8)
            if len(kp_a) < 6 or len(kp_b) < 6:
                continue
            da = compute_pw_descriptors_batch(base, kp_a, cfg_none)
            db = compute_pw_descriptors_batch(warped, kp_b, cfg_none)
            da_p, db_p = proj.transform(da), proj.transform(db)
            matches = nn_ratio_match(da_p, db_p, ratio_thresh=0.85, mutual=True)
            if len(matches) == 0:
                scores.append(0.0)
                continue
            pts_a = kp_a[matches[:, 0]][:, ::-1].astype(np.float64)
            pts_b = kp_b[matches[:, 1]][:, ::-1].astype(np.float64)
            mma = mean_matching_accuracy(pts_a, pts_b, H_gt, thresholds=(3,))
            scores.append(mma[3])
        return dict(mean_mma3=float(np.mean(scores)) if scores else 0.0,
                    std_mma3=float(np.std(scores)) if scores else 0.0, n=len(scores))

    out["Spectrally-constrained projection (default)"] = eval_with_projection(proj_constrained, scenes_eval, 30)
    print(f"  Spectrally-constrained: {out['Spectrally-constrained projection (default)']}")

    class UnconstrainedProjection(ContrastiveLinearProjection):
        def fit(self, X_a, X_b, labels):
            rng = np.random.default_rng(self.cfg.seed)
            N, d = X_a.shape
            out_dim = min(self.cfg.out_dim, d)
            W = rng.normal(scale=1.0 / np.sqrt(d), size=(out_dim, d))
            m_pos, m_neg = self.cfg.margin, 2 * self.cfg.margin
            for epoch in range(self.cfg.epochs):
                Za, Zb = (W @ X_a.T).T, (W @ X_b.T).T
                na = np.linalg.norm(Za, axis=1, keepdims=True) + 1e-9
                nb = np.linalg.norm(Zb, axis=1, keepdims=True) + 1e-9
                Za_n, Zb_n = Za / na, Zb / nb
                diff = Za_n - Zb_n
                dist = np.linalg.norm(diff, axis=1)
                grad_W = np.zeros_like(W)
                for i in range(N):
                    if labels[i] == 1 and dist[i] > m_pos:
                        coeff = 2 * (dist[i] - m_pos)
                        d_ = diff[i] / (dist[i] + 1e-9)
                        grad_W += np.outer(coeff * d_, X_a[i]) - np.outer(coeff * d_, X_b[i])
                    elif labels[i] == 0 and dist[i] < m_neg:
                        coeff = -2 * (m_neg - dist[i])
                        d_ = diff[i] / (dist[i] + 1e-9)
                        grad_W += np.outer(coeff * d_, X_a[i]) - np.outer(coeff * d_, X_b[i])
                grad_W /= max(N, 1)
                grad_W += self.cfg.weight_decay * W
                W = W - self.cfg.lr * grad_W
                # NO spectral normalization here -- this is the ablation
            self.W = W
            return self

    proj_unconstrained = UnconstrainedProjection(proj_cfg).fit(X_a, X_b, labels)
    spectral_norm = float(np.linalg.norm(proj_unconstrained.W, ord=2))
    out["Unconstrained projection"] = eval_with_projection(proj_unconstrained, scenes_eval, 30)
    out["Unconstrained projection"]["measured_spectral_norm"] = spectral_norm
    print(f"  Unconstrained (||W||_2={spectral_norm:.3f}): {out['Unconstrained projection']}")

    return out


def main():
    out = {}
    out["h0_h1_ablation"] = run_h0_h1_ablation()
    out["scale_ablation"] = run_scale_ablation()
    out["resolution_ablation"] = run_resolution_ablation()
    out["projection_ablation"] = run_projection_ablation()

    out_path = os.path.join(os.path.dirname(__file__), "ablation_study_results.json")
    with open(out_path, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved -> {out_path}")


if __name__ == "__main__":
    main()
