"""
mc_more.py -- extends the Monte Carlo registration experiment of
mc_measurement.py from 8 to 16 draws per image and disturbance: trials 8-15
(new seeds, same generators) for all P1 descriptors and the thresholded
PW-Desc-rank variants, under the six original conditions.
Usage: python mc_more.py /path/to/oxford out_dir [workers]
"""
import sys, os, json, time
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
from multiprocessing import Pool
import mc_measurement as M
from benchmark_shared_detector import METHODS
from mc_tau import variant

M.METHODS = dict(METHODS)
M.METHODS["PW-Desc-rank-t0.05"] = variant(0.05)
M.METHODS["PW-Desc-rank-t0.1"] = variant(0.1)
M.RUN_PART_A = False
M.T_START = 8

if __name__ == "__main__":
    root, out_dir = sys.argv[1], sys.argv[2]
    workers = int(sys.argv[3]) if len(sys.argv) > 3 else 2
    imgs = [os.path.join(root, s, f"img{k}.png") for s in sorted(os.listdir(root)) for k in (1, 4)]
    imgs = [p for p in imgs if os.path.exists(p)]
    t0 = time.time()
    with Pool(workers) as pool, open(os.path.join(out_dir, "mc_more.jsonl"), "w") as f:
        for i, r in enumerate(pool.imap_unordered(M.run_image, [(p, imgs.index(p), 8) for p in imgs])):
            f.write(json.dumps(r) + "\n"); f.flush()
            print(f"[{i + 1}/{len(imgs)}] {r['image']} {time.time() - t0:.0f}s", flush=True)
