import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from phdesc.persistence import compute_persistence_diagrams
from phdesc.descriptor import compute_pw_descriptor, DescriptorConfig, extract_patch
from phdesc.bottleneck import bottleneck_distance, _significant_points
from phdesc.profiling import cv2_sift_describe
from phdesc.baselines import raw_patch_descriptor
from synthetic_validation import make_synthetic_scene

# A scene with real corner/edge structure (not flat), so drift has a
# genuine effect -- centred on a location with clear local structure.
scene = make_synthetic_scene(size=160, n_shapes=30, seed=4)
y0, x0 = 80, 80

cfg = DescriptorConfig(scales=(16, 24, 32), resolution=8)
d0 = compute_pw_descriptor(scene, y0, x0, cfg)
patch0 = extract_patch(scene, y0, x0, 32)
pd0_0, pd1_0 = compute_persistence_diagrams(patch0)

raw0 = raw_patch_descriptor(scene, y0, x0, size=16)
sift0 = cv2_sift_describe(scene, np.array([[y0, x0]]))[0]

drifts = np.array([0, 1, 2, 3, 4, 5])
bottleneck_h1 = []
pwdesc_dist = []
raw_dist = []
sift_dist = []

for delta in drifts:
    y, x = y0 + delta, x0  # drift along one axis, matches the corollary's Euclidean epsilon
    d = compute_pw_descriptor(scene, y, x, cfg)
    patch = extract_patch(scene, y, x, 32)
    _, pd1 = compute_persistence_diagrams(patch)

    bd = bottleneck_distance(_significant_points(pd1_0.finite()), _significant_points(pd1.finite()))
    bottleneck_h1.append(bd)
    pwdesc_dist.append(np.linalg.norm(d - d0))

    raw = raw_patch_descriptor(scene, y, x, size=16)
    raw_dist.append(np.linalg.norm(raw - raw0))

    sift = cv2_sift_describe(scene, np.array([[y, x]]))
    sift_dist.append(np.linalg.norm(sift[0] - sift0) if len(sift) else np.nan)

fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.3))

ax = axes[0]
ax.plot(drifts, bottleneck_h1, "o-", color="#8e44ad", linewidth=1.8, label="$d_B(D_1, D_1')$ (bottleneck, $H_1$)")
ax.plot(drifts, drifts, "k--", linewidth=1, label="$y = \\varepsilon$ (identity reference)")
ax.set_xlabel("Keypoint offset $\\varepsilon$ (pixels)")
ax.set_ylabel("Bottleneck distance $d_B(D_1(P), D_1(P'))$")
ax.set_title("(a) Diagram-level drift sensitivity, real measured\n(Corollary 1's $d_B \\leq L\\varepsilon$ bound, implicit via Prop. 1)", fontsize=9.5)
ax.legend(fontsize=8)
ax.grid(alpha=0.3)

ax2 = axes[1]
ax2.plot(drifts, pwdesc_dist, "o-", color="#2c6fbb", label="PW-Desc")
ax2.plot(drifts, raw_dist, "^-", color="#e07b39", label="RawPatch")
ax2.plot(drifts, sift_dist, "D-", color="#c0392b", label="SIFT (OpenCV, real)")
ax2.set_xlabel("Keypoint offset $\\varepsilon$ (pixels)")
ax2.set_ylabel("Descriptor Euclidean distance")
ax2.set_title("(b) Descriptor-level drift sensitivity, real measured", fontsize=9.5)
ax2.legend(fontsize=8)
ax2.grid(alpha=0.3)

fig.suptitle("Keypoint drift: theoretical bound (Corollary 1) vs.\\ empirical measurement, "
             "real computed data (single patch location, one direction of drift)", fontsize=10.5, y=1.04)
plt.tight_layout()
out = "/home/claude/phdesc_project/paper/figure_drift.pdf"
plt.savefig(out, bbox_inches="tight")
print("saved", out)
print("bottleneck H1:", bottleneck_h1)
print("PW-Desc dist:", pwdesc_dist)
print("Raw dist:", raw_dist)
print("SIFT dist:", sift_dist)
