"""
sharpness.py -- numerical check of Proposition 5 (the count of diagram points
in the bound cannot be removed). Patches of side 32 with m isolated minima of
value alpha on a background beta; the perturbation lowers every minimum by
delta. For each m the script computes the diagrams with the released engine,
the persistence-image change of the H0 block and the bound of Lemmas 1-2,
and also the same ratio on real Harris patches (Experiment A, eps = 0.02).
Usage: python sharpness.py /path/to/oxford out_dir
"""
import sys, os, json
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "..")); sys.path.insert(0, HERE)
import numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from phdesc.fastph import diagrams
from phdesc.descriptor import persistence_image, extract_patch
from phdesc.persistence import PersistenceDiagram
from phdesc import harris_keypoints
from mc_measurement import load_resized
plt.rcParams.update({"font.family": "STIXGeneral", "mathtext.fontset": "stix", "font.size": 8, "axes.linewidth": 0.5,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "pdf.fonttype": 42, "savefig.dpi": 600})
R = 8; SIG = 1 / R
K = 2 + np.sqrt(5) / (SIG * np.sqrt(np.e))
A, B, DEL, S = 0.2, 0.6, 0.01, 32
pi = lambda D: persistence_image(PersistenceDiagram(0, D), (0, 1), (0, 1), R)

def construct(m):
    P = np.full((S, S), B)
    pos = [(2 * i + 1, 2 * j + 1) for i in range(S // 2) for j in range(S // 2)][:m]
    for (i, j) in pos:
        P[i, j] = A
    Q = P.copy()
    for (i, j) in pos:
        Q[i, j] = A - DEL
    return P, Q

grid = np.linspace(0, 1, R)
G = np.stack(np.meshgrid(grid, grid, indexing="ij"), -1)
p = B - A
term = lambda b, pp: min(pp, 1.0) * np.exp(-((G[..., 0] - pp) ** 2 + (G[..., 1] - b) ** 2) / (2 * SIG ** 2))
Gamma = float(np.abs(term(A - DEL, p + DEL) - term(A, p)).max())
rows = []
for m in (2, 4, 8, 16, 32, 64, 128, 256):
    P, Q = construct(m)
    (d0, d1), (e0, e1) = diagrams(P), diagrams(Q)
    assert len(d1) == 0 and len(e1) == 0 and len(d0) == m - 1 and len(e0) == m - 1
    assert np.allclose(d0, [[A, B]]) and np.allclose(e0, [[A - DEL, B]])
    ch = pi(d0) - pi(e0)
    sup, l2 = float(np.abs(ch).max()), float(np.linalg.norm(ch))
    bound_sup = K * (len(d0) + len(e0)) * DEL
    rows.append(dict(m=m, n_points=len(d0) + len(e0), sup=sup, l2=l2, bound_sup=bound_sup, bound_l2=R * bound_sup,
                     ratio_sup=sup / bound_sup, predicted_sup=(m - 1) * Gamma))
    print(rows[-1])
# real patches (s = 32 H0 block), eps = 0.02
real = []
rng = np.random.default_rng(11)
root = sys.argv[1]
for sc in sorted(os.listdir(root)):
    im = load_resized(os.path.join(root, sc, "img1.png"))
    J = np.clip(im + rng.uniform(-0.02, 0.02, im.shape), 0, 1)
    for (y, x) in harris_keypoints(im, max_keypoints=50, min_distance=8):
        Pc, Pn = extract_patch(im, y, x, 32), extract_patch(J, y, x, 32)
        dl = float(np.abs(Pc - Pn).max())
        (a0, _), (b0, _) = diagrams(Pc), diagrams(Pn)
        sup = float(np.abs(pi(a0) - pi(b0)).max())
        real.append(dict(n_points=len(a0) + len(b0), ratio_sup=sup / (K * (len(a0) + len(b0)) * dl)))
out = dict(alpha=A, beta=B, delta=DEL, s=S, K=K, Gamma=Gamma, ratio_limit=Gamma / (2 * K * DEL), construction=rows,
           real_median_ratio=float(np.median([r["ratio_sup"] for r in real])), real_max_ratio=float(np.max([r["ratio_sup"] for r in real])),
           real_n=len(real))
print({k: v for k, v in out.items() if k != "construction"})
json.dump(out, open(os.path.join(sys.argv[2], "sharpness.json"), "w"), indent=1)
# figure: change of the H0 persistence image (sup norm, in units of delta) against the number of points
fig, ax = plt.subplots(figsize=(8.4 / 2.54, 5.2 / 2.54))
n = np.array([r["n_points"] for r in rows]); sup = np.array([r["sup"] for r in rows])
ax.loglog(n, K * n, color="black", lw=0.8, ls=(0, (4, 2)), label=r"bound of Lemmas 1--2, $K(|D|+|D'|)$")
ax.loglog(n, sup / DEL, color="black", lw=0.8, marker="s", ms=3, mfc="white", label=r"construction of Prop. 5 (exact)")
rn = np.array([r["n_points"] for r in real]); rr = np.array([r["ratio_sup"] for r in real])
ax.scatter(rn, rr * K * rn, s=4, marker="o", facecolor="0.55", edgecolor="none", label="real patches, $s=32$, $\\varepsilon=2\\times10^{-2}$")
ax.set_xlabel(r"number of points $|D_0|+|D'_0|$")
ax.set_ylabel(r"$\|\rho(D_0)-\rho(D'_0)\|_\infty/\delta$")
ax.legend(frameon=False, fontsize=6.3, loc="upper left", handlelength=2.2)
ax.set_xlim(1.5, 800)
fig.tight_layout(pad=0.2)
fig.savefig(os.path.join(sys.argv[3] if len(sys.argv) > 3 else sys.argv[2], "fig5_sharpness.pdf"))
